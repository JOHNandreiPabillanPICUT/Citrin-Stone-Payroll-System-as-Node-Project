'use strict';

// Optional shared helper for pages that use the QR scanner. The scanner page
// also has a fallback manual-entry flow, so scanning remains usable if camera
// permission or the CDN library is unavailable.
async function handleQRCodeScanned(qrCodeValue) {
  const value = String(qrCodeValue || '').trim();
  if (!value) return { success: false, message: 'The QR code is empty.' };

  try {
    const response = await fetch('/attendance/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ employee_code: value })
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to record attendance.');
    }
    return data;
  } catch (error) {
    console.error('QR attendance error:', error);
    return { success: false, message: error.message || 'Could not connect to the attendance server.' };
  }
}

if (typeof window !== 'undefined') window.handleQRCodeScanned = handleQRCodeScanned;
