/* Live updates: reloads the current page (when it is safe) after something changes anywhere in the system. */
(function () {
  'use strict';
  if (!window.EventSource) return;

  // Never auto-refresh the login pages or the camera scanner.
  if (/^\/(auth|attendance\/scanner)(\/|$)/.test(location.pathname)) return;

  var pending = false, timer = null, lastReload = 0, submitting = false, hadError = false;
  var SCROLL_KEY = 'liveScroll:' + location.pathname;

  // Restore scroll position and show a small "updated" note after a live refresh.
  try {
    var y = sessionStorage.getItem(SCROLL_KEY);
    if (y !== null) { sessionStorage.removeItem(SCROLL_KEY); window.scrollTo(0, parseInt(y, 10) || 0); showToast(); }
  } catch (e) {}

  function showToast() {
    var t = document.createElement('div');
    t.textContent = 'Updated just now';
    t.setAttribute('role', 'status');
    t.style.cssText = 'position:fixed;right:20px;bottom:20px;z-index:99999;background:#111;color:#fff;padding:8px 14px;border-radius:999px;font:600 12px system-ui,sans-serif;opacity:.92;transition:opacity .6s';
    document.body.appendChild(t);
    setTimeout(function () { t.style.opacity = '0'; }, 1800);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 2500);
  }

  function visible(el) { return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length); }

  // Don't refresh while someone is typing, has unsaved input, or has a dialog open.
  function busy() {
    var a = document.activeElement;
    if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && !/^(button|submit|checkbox|radio)$/i.test(a.type || '')) return true;
    var dialogs = document.querySelectorAll('.modal.show, dialog[open], [role="dialog"], [aria-modal="true"]');
    for (var i = 0; i < dialogs.length; i++) if (visible(dialogs[i])) return true;
    var fields = document.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]), textarea');
    for (var j = 0; j < fields.length; j++) if (fields[j].value !== fields[j].defaultValue) return true;
    return false;
  }

  function refresh() {
    pending = false;
    lastReload = Date.now();
    try { sessionStorage.setItem(SCROLL_KEY, String(window.scrollY || 0)); } catch (e) {}
    location.replace(location.href); // GET request, so a page that came from a POST never asks to "resubmit"
  }

  function tick() {
    if (!pending) return;
    if (document.hidden) return;                        // resumes on visibilitychange
    if (submitting || busy()) { timer = setTimeout(tick, 3000); return; }
    var wait = 2000 - (Date.now() - lastReload);
    if (wait > 0) { timer = setTimeout(tick, wait); return; }
    refresh();
  }

  function schedule() {
    pending = true;
    clearTimeout(timer);
    timer = setTimeout(tick, 600);                      // groups bursts of events into one refresh
  }

  // The person's own form submit navigates away by itself; don't interrupt it.
  document.addEventListener('submit', function () {
    submitting = true;
    setTimeout(function () { submitting = false; }, 5000);
  }, true);

  document.addEventListener('visibilitychange', function () { if (!document.hidden && pending) tick(); });

  var es = new EventSource('/events');
  es.addEventListener('change', schedule);
  es.onerror = function () { hadError = true; };        // the browser reconnects on its own
  es.onopen = function () { if (hadError) { hadError = false; schedule(); } }; // catch up on anything missed
})();