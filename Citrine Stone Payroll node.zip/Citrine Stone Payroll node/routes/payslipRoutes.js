const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const P = require('../lib/payrollPeriod');
const C = require('../lib/payrollCalc');
const H = require('../lib/payrollHelpers');
const { ensurePayrollSchema } = require('../lib/payrollSchema');

const num = (v) => Number(v) || 0;
const r2 = (v) => Math.round((num(v) + Number.EPSILON) * 100) / 100;
const money = (v) => '₱' + r2(v).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const longDate = (v) => {
  const ymd = P.toYmd(v);
  const d = ymd && P.parseYmd(ymd);
  return d ? d.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: '2-digit', year: 'numeric', timeZone: 'UTC' }) : 'N/A';
};
const dayLabel = (v) => {
  const d = P.parseYmd(P.toYmd(v));
  return d ? d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: '2-digit', timeZone: 'UTC' }) : '—';
};
const timeLabel = (t) => {
  const m = /^(\d{2}):(\d{2})/.exec(String(t || ''));
  if (!m) return '—';
  const h = +m[1];
  return String(h % 12 || 12).padStart(2, '0') + ':' + m[2] + ' ' + (h >= 12 ? 'PM' : 'AM');
};

const DEFAULT_COMPANY_TYPES = ['Water Bill', 'Cafeteria / Canteen', 'Health Insurance Premium'];

/* company deduction types shown on the payslip (non-government deduction types), same list as the PHP payslip */
async function companyTypes(conn) {
  try {
    if (await H.tableExists(conn, 'deduction_type')) {
      const [rows] = await conn.query('SELECT deduction_type_id, type_name FROM deduction_type WHERE is_government_mandated = 0 ORDER BY deduction_type_id');
      if (rows.length) return rows.map((r) => ({ id: Number(r.deduction_type_id), name: String(r.type_name) }));
    }
  } catch (e) { /* fall back to the default list */ }
  return DEFAULT_COMPANY_TYPES.map((name, i) => ({ id: -(i + 1), name }));
}

/* a Posted payslip shows the installments that were really recorded for that run */
async function postedLoanLines(conn, runId, employeeId) {
  try {
    if (!(await H.tableExists(conn, 'loan_repayment')) || !(await H.tableExists(conn, 'loan_request')) || !(await H.tableExists(conn, 'loan_schedule'))) return null;
    const [rows] = await conn.query(
      `SELECT lr.loan_type, r.amount, s.installment_no, s.due_date
       FROM loan_repayment r JOIN loan_request lr ON lr.loan_id = r.loan_id JOIN loan_schedule s ON s.schedule_id = r.schedule_id
       WHERE r.payroll_run_id = ? AND r.employee_id = ? ORDER BY lr.loan_type, s.installment_no`, [Number(runId), Number(employeeId)]);
    return rows;
  } catch (e) { return null; }
}

// View All Generated Payslips
router.get('/', isAuth, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT p.payroll_id AS id, p.gross_pay, p.net_pay, pr.period_start, pr.period_end, pr.pay_frequency,
             pr.status AS payroll_status, e.first_name, e.last_name
      FROM payroll p
      JOIN payroll_run pr ON p.payroll_run_id = pr.payroll_run_id
      JOIN employee e ON p.employee_id = e.employee_id
      ORDER BY p.payroll_id DESC
    `);
    const payslips = rows.map((r) => ({
      ...r,
      employee_name: `${r.first_name || ''} ${r.last_name || ''}`.trim(),
      period_label: `${P.formatDate(r.period_start)} - ${P.formatDate(r.period_end)}`,
    }));
    res.render('payslips/index', { payslips, user: req.session });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database Error');
  }
});

// Print/View Individual Payslip (same layout as the Gaisano PHP payslip)
router.get('/print/:id', isAuth, async (req, res) => {
  const payslipId = parseInt(req.params.id, 10);
  if (!(payslipId > 0)) return res.status(400).send('Invalid request. No payslip ID provided.');
  try {
    await ensurePayrollSchema(db);
    await C.syncOpenRuns(db); /* open runs show the live calculation; Posted runs keep what was paid */

    const [rows] = await db.query(`
      SELECT p.*, e.first_name, e.last_name, e.employee_id AS emp_id, dept.name AS department_name,
             pr.period_start, pr.period_end, pr.pay_frequency, pr.pay_factor, pr.pay_date, pr.cutoff_date, pr.coverage_end,
             pr.status AS payroll_status
      FROM payroll p
      INNER JOIN employee e ON p.employee_id = e.employee_id
      LEFT JOIN department dept ON e.department_id = dept.department_id
      INNER JOIN payroll_run pr ON p.payroll_run_id = pr.payroll_run_id
      WHERE p.payroll_id = ? LIMIT 1`, [payslipId]);
    if (!rows.length) return res.status(404).send('Payslip record not found.');
    const ps = rows[0];

    const isPosted = ps.payroll_status === 'Posted';
    const calc = await C.calculateEmployeePayroll(db, Number(ps.employee_id), ps);
    const att = await C.payslipAttendance(db, Number(ps.employee_id), ps);

    const pick = (stored, live) => (isPosted ? r2(stored) : live);
    const basicPay = pick(ps.basic_pay, calc.basic_pay);
    const overtimePay = pick(ps.overtime_pay, calc.overtime_pay);
    const holidayPay = pick(ps.holiday_pay, calc.holiday_pay);
    const grossPay = pick(ps.gross_pay, calc.gross_pay);
    const totalDeductions = pick(ps.total_deductions, calc.total_deductions);
    const netPay = pick(ps.net_pay, calc.net_pay);

    let loanLines = calc.loan_lines || [];
    let loanDeductions = num(calc.loan_deductions);
    if (isPosted) {
      const posted = await postedLoanLines(db, ps.payroll_run_id, ps.employee_id);
      if (posted) { loanLines = posted; loanDeductions = r2(posted.reduce((s, l) => s + num(l.amount), 0)); }
    }

    const types = await companyTypes(db);
    const companyLines = (calc.company_lines || []).map((l) => ({ ...l, deduction_type_id: Number(l.deduction_type_id) }));
    const timing = C.deductionTiming({ ...ps, payroll_status: ps.payroll_status });

    res.render('payslips/print', {
      p: ps,
      employeeName: `${ps.first_name || ''} ${ps.last_name || ''}`.trim(),
      periodLabel: `${P.formatDate(ps.period_start)} - ${P.formatDate(ps.period_end)}`,
      payDateLabel: longDate(ps.pay_date),
      isPosted, timing,
      attSummary: att.summary, attDays: att.days,
      basicPay, overtimePay, holidayPay, grossPay,
      sss: calc.sss, philhealth: calc.philhealth, pagibig: calc.pagibig, bir: calc.bir,
      governmentDeductions: calc.government_deductions,
      calc, attendanceDeductions: calc.attendance_deductions,
      loanLines, loanDeductions,
      companyTypes: types, companyLines, companyDeferred: calc.company_deferred || [],
      companyDeductions: calc.company_deductions,
      totalDeductions, netPay,
      taxableCompensation: Math.max(0, r2(grossPay - calc.attendance_deductions - calc.sss - calc.philhealth - calc.pagibig)),
      money, dayLabel, timeLabel,
      user: req.session,
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database Error');
  }
});

module.exports = router;
