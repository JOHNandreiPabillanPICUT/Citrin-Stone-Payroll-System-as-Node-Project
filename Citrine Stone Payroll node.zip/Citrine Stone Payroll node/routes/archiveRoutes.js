'use strict';
const express = require('express');
const { stripIds } = require('../lib/displayText');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const { ensureArchiveTable, actor } = require('./archiveStore');

router.get('/', isAuth, async (req, res) => {
  try {
    await ensureArchiveTable();
    const filters = {
      search: String(req.query.search || '').trim(),
      module: String(req.query.module || '').trim(),
      action: String(req.query.action || '').trim(),
      outcome: String(req.query.outcome || '').trim(),
      date_from: String(req.query.date_from || '').trim(),
      date_to: String(req.query.date_to || '').trim(),
      status: String(req.query.status || 'archived').trim()
    };
    const where = [], params = [];
    if (filters.status === 'restored') where.push('restored_at IS NOT NULL');
    else if (filters.status !== 'all') where.push('restored_at IS NULL');
    if (filters.search) {
      where.push('(record_label LIKE ? OR source_table LIKE ? OR archived_by LIKE ? OR CAST(record_data AS CHAR) LIKE ?)');
      for (let i = 0; i < 4; i++) params.push(`%${filters.search}%`);
    }
    if (filters.module) { where.push('module = ?'); params.push(filters.module); }
    if (filters.action) { where.push('action = ?'); params.push(filters.action); }
    if (filters.outcome) { where.push('outcome = ?'); params.push(filters.outcome); }
    if (filters.date_from) { where.push('archived_at >= ?'); params.push(`${filters.date_from} 00:00:00`); }
    if (filters.date_to) { where.push('archived_at <= ?'); params.push(`${filters.date_to} 23:59:59`); }
    const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const [records] = await db.query(`SELECT * FROM archive_records ${clause} ORDER BY archived_at DESC, archive_id DESC LIMIT 1000`, params);
    const [modules] = await db.query('SELECT DISTINCT module AS value FROM archive_records ORDER BY module');
    const [actions] = await db.query('SELECT DISTINCT action AS value FROM archive_records ORDER BY action');
    const [outcomes] = await db.query('SELECT DISTINCT outcome AS value FROM archive_records ORDER BY outcome');
    const [[stats]] = await db.query(`SELECT COUNT(*) AS total,
      SUM(restored_at IS NULL) AS archived_count, SUM(restored_at IS NOT NULL) AS restored_count FROM archive_records`);
    records.forEach(r => { r.record_label = stripIds(r.record_label || ''); });
    res.render('archive/index', { title: 'Archive', records, filters, modules: modules.map(x => x.value), actions: actions.map(x => x.value), outcomes: outcomes.map(x => x.value), stats: stats || {}, user: req.session.user || req.session, message: '' });
  } catch (err) {
    console.error('Archive page error:', err);
    res.status(500).send('Unable to load Archive. Check database permissions and the Node.js terminal for details.');
  }
});

router.post('/restore/:id', isAuth, async (req, res) => {
  const conn = await db.getConnection();
  try {
    await ensureArchiveTable();
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT * FROM archive_records WHERE archive_id = ? AND restored_at IS NULL FOR UPDATE', [req.params.id]);
    if (!rows.length) { await conn.rollback(); return res.status(404).send('Archived record not found or already restored.'); }
    const item = rows[0];
    const data = typeof item.record_data === 'string' ? JSON.parse(item.record_data) : item.record_data;
    const table = String(item.source_table);
    if (!/^[a-zA-Z0-9_]+$/.test(table)) throw new Error('Invalid source table in archive.');

    if (table === 'employee' || table === 'employees') {
      const idCol = Object.prototype.hasOwnProperty.call(data, 'employee_id') ? 'employee_id' : (Object.prototype.hasOwnProperty.call(data, 'id') ? 'id' : null);
      if (!idCol) throw new Error('Cannot restore employee: no employee ID in saved record.');
      if (table === 'employees' && Object.prototype.hasOwnProperty.call(data, 'archived')) {
        await conn.query(`UPDATE \`${table}\` SET archived = 0 WHERE \`${idCol}\` = ?`, [item.source_id]);
      } else {
        await conn.query(`UPDATE \`${table}\` SET status = 'Active' WHERE \`${idCol}\` = ?`, [item.source_id]);
      }
    } else if (table === 'attendance' || table === 'attendances') {
      const statusCol = Object.prototype.hasOwnProperty.call(data, 'status') ? 'status' : (Object.prototype.hasOwnProperty.call(data, 'attendance_status') ? 'attendance_status' : null);
      if (statusCol) await conn.query(`UPDATE \`${table}\` SET \`${statusCol}\` = ? WHERE \`${(Object.prototype.hasOwnProperty.call(data, 'attendance_id') ? 'attendance_id' : (Object.prototype.hasOwnProperty.call(data, 'record_id') ? 'record_id' : 'id'))}\` = ?`, [data[statusCol] || 'Present', item.source_id]);
    } else if (table === 'department') {
      const [exists] = await conn.query('SELECT department_id FROM department WHERE department_id = ? LIMIT 1', [item.source_id]);
      if (!exists.length) {
        const cols = Object.keys(data).filter(k => /^[a-zA-Z0-9_]+$/.test(k));
        if (!cols.length) throw new Error('No saved department fields available to restore.');
        await conn.query(`INSERT INTO department (${cols.map(c => `\`${c}\``).join(',')}) VALUES (${cols.map(() => '?').join(',')})`, cols.map(c => data[c]));
      }
    } else {
      throw new Error(`Restore is not configured for module '${item.module}'.`);
    }
    await conn.query(`UPDATE archive_records SET restored_at = NOW(), outcome = 'Restored', action = 'Restore', archived_by = ? WHERE archive_id = ?`, [actor(req), item.archive_id]);
    await conn.commit();
    res.redirect('/archive?status=all');
  } catch (err) {
    await conn.rollback();
    console.error('Restore archive item error:', err);
    res.status(500).send(`Unable to restore this record: ${err.message}`);
  } finally { conn.release(); }
});
module.exports = router;
