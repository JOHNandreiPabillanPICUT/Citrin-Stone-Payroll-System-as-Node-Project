'use strict';
const express = require('express');
const { stripIds } = require('../lib/displayText');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');

const safe = n => { if (!/^[a-zA-Z0-9_]+$/.test(n || '')) throw new Error('Invalid identifier'); return `\`${n}\``; };
async function tableColumns(table) {
  const [rows] = await db.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [table]);
  return rows.map(r => r.COLUMN_NAME);
}
router.get('/', requireAuth, async (req, res) => {
  try {
    const [tables] = await db.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()");
    const names = tables.map(r => r.TABLE_NAME);
    const table = ['audit_log','audit_logs','system_logs','activity_logs','activity_log'].find(n => names.includes(n));
    let logs = [], filters = { search: req.query.search || '', module: req.query.module || '', action: req.query.action || '', outcome: req.query.outcome || '', date_from: req.query.date_from || '', date_to: req.query.date_to || '' }, message = '';
    let modules = [], actions = [], outcomes = [];
    if (!table) {
      message = 'No audit log table was found in the selected database. The page is working, but it needs an audit_log or audit_logs table to display recorded activities.';
    } else {
      const cols = await tableColumns(table);
      const id = ['log_id','audit_id','id'].find(c => cols.includes(c));
      const date = ['created_at','logged_at','date_time','activity_date','timestamp'].find(c => cols.includes(c));
      const user = ['username','user_name','user_id','actor','performed_by'].find(c => cols.includes(c));
      const module = ['module','module_name','category'].find(c => cols.includes(c));
      const action = ['action','action_type','event'].find(c => cols.includes(c));
      const description = ['description','details','message','activity','remarks'].find(c => cols.includes(c));
      const outcome = ['outcome','result','status'].find(c => cols.includes(c));
      const ip = ['ip_address','ip'].find(c => cols.includes(c));
      const select = [
        id ? `${safe(id)} AS log_id` : 'NULL AS log_id',
        date ? `${safe(date)} AS log_date` : 'NULL AS log_date',
        user ? `${safe(user)} AS log_user` : "'System' AS log_user",
        module ? `${safe(module)} AS log_module` : "'General' AS log_module",
        action ? `${safe(action)} AS log_action` : "'Activity' AS log_action",
        description ? `${safe(description)} AS log_description` : "'' AS log_description",
        outcome ? `${safe(outcome)} AS log_outcome` : "'Info' AS log_outcome",
        ip ? `${safe(ip)} AS ip_address` : "'' AS ip_address"
      ].join(', ');
      const where = [], params = [];
      if (filters.search) {
        const searchable = [user,module,action,description].filter(Boolean);
        if (searchable.length) { where.push('(' + searchable.map(c => `${safe(c)} LIKE ?`).join(' OR ') + ')'); searchable.forEach(() => params.push(`%${filters.search}%`)); }
      }
      if (module && filters.module) { where.push(`${safe(module)} = ?`); params.push(filters.module); }
      if (action && filters.action) { where.push(`${safe(action)} = ?`); params.push(filters.action); }
      if (outcome && filters.outcome) { where.push(`${safe(outcome)} = ?`); params.push(filters.outcome); }
      if (date && filters.date_from) { where.push(`${safe(date)} >= ?`); params.push(`${filters.date_from} 00:00:00`); }
      if (date && filters.date_to) { where.push(`${safe(date)} <= ?`); params.push(`${filters.date_to} 23:59:59`); }
      const orderBy = date || id;
      const sql = `SELECT ${select} FROM ${safe(table)} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ${orderBy ? 'ORDER BY ' + safe(orderBy) + ' DESC' : ''} LIMIT 500`;
      const [rows] = await db.query(sql, params);
      logs = rows;
      /* no database ids on screen: strip "#12" from descriptions and show a user NAME instead of a numeric user id */
      let names = {};
      if (logs.some(r => /^\d+$/.test(String(r.log_user)))) {
        try { const [u] = await db.query('SELECT user_id, username FROM users'); u.forEach(x => { names[String(x.user_id)] = x.username; }); } catch (e) { /* no users table */ }
      }
      logs = logs.map(r => ({
        ...r,
        log_id: null,
        log_user: /^\d+$/.test(String(r.log_user)) ? (names[String(r.log_user)] || 'System') : r.log_user,
        log_description: stripIds(r.log_description || '') || '—',
      }));
      if (module) { const [r] = await db.query(`SELECT DISTINCT ${safe(module)} AS value FROM ${safe(table)} WHERE ${safe(module)} IS NOT NULL ORDER BY value LIMIT 100`); modules = r.map(x => x.value); }
      if (action) { const [r] = await db.query(`SELECT DISTINCT ${safe(action)} AS value FROM ${safe(table)} WHERE ${safe(action)} IS NOT NULL ORDER BY value LIMIT 100`); actions = r.map(x => x.value); }
      if (outcome) { const [r] = await db.query(`SELECT DISTINCT ${safe(outcome)} AS value FROM ${safe(table)} WHERE ${safe(outcome)} IS NOT NULL ORDER BY value LIMIT 100`); outcomes = r.map(x => x.value); }
      if (!date && !id) message = `Audit table '${table}' has no recognized date or ID column; records are shown in database order.`;
    }
    res.render('audit/index', { title: 'Audit Log', logs, filters, modules, actions, outcomes, message, user: req.session });
  } catch (err) {
    console.error('Audit log page error:', err);
    res.status(500).send(`Unable to load Audit Log. Check the audit table structure. Details: ${process.env.NODE_ENV === 'development' ? err.message : 'see server terminal'}`);
  }
});
module.exports = router;
