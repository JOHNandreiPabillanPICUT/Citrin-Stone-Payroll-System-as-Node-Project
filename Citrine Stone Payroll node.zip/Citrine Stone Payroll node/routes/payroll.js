'use strict';
/**
 * Payroll routes (port of Gaisano modules/payroll: index, create_run, department_period, process, view).
 * Mounted in server.js as  app.use('/payroll', require('./routes/payroll'));
 * Role access (Admin / HR only) is enforced by middleware/rbac.js for every /payroll path.
 */
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const { ensurePayrollSchema } = require('../lib/payrollSchema');

const express = require('express');
const P = require('../lib/payrollPeriod');
const C = require('../lib/payrollCalc');
const H = require('../lib/payrollHelpers');

const router = express.Router();
router.use(requireAuth);

/* adds only the columns / tables the payroll module needs and the database does not have yet (runs once) */
router.use(async (req, res, next) => {
  try { await ensurePayrollSchema(db); next(); } catch (e) { next(e); }
});

const FREQUENCIES = P.PAY_FREQUENCIES;
const CREATE_FREQUENCY = 'Semi-monthly'; /* the only frequency offered when creating a run */
const pastMessage = (today) => `Payroll dates cannot be in the past. Today is ${P.formatDate(today)}; choose today or a later date.`;
/* real calendar window for a new run: today .. one year ahead (stops typed years like 20266 or 1999) */
const maxDateFrom = (today) => P.fmt(P.addDays(P.parseYmd(today), 366));
const tooFarMessage = (max) => `Payroll dates cannot be later than ${P.formatDate(max)} (one year from today).`;
const STATUSES = ['Draft', 'Processing', 'Submitted', 'Rejected', 'Posted'];
/* writes to whichever audit table the project has (same approach as the leave module) */
async function audit(req, detail) {
  try {
    const [ts] = await db.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('audit_log','audit_logs','activity_logs','activity_log','system_logs')");
    const table = ts[0] && ts[0].TABLE_NAME;
    if (!table) return;
    const [cr] = await db.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?', [table]);
    const c = new Set(cr.map((x) => x.COLUMN_NAME));
    const data = {};
    const put = (names, v) => { const k = names.find((x) => c.has(x)); if (k) data[k] = v; };
    put(['user_id', 'performed_by'], Number((req.session && (req.session.userId || req.session.user_id)) || 0));
    put(['username', 'user_name', 'actor'], String((req.session && req.session.username) || ''));
    put(['module', 'module_name', 'category'], 'Payroll');
    put(['action', 'action_type', 'event'], String(detail).split(' ')[0]);
    put(['description', 'details', 'message', 'activity'], detail);
    put(['created_at', 'logged_at', 'timestamp'], new Date());
    put(['outcome', 'result'], 'Success');
    const keys = Object.keys(data);
    if (keys.length) await db.query(`INSERT INTO \`${table}\` (${keys.map((k) => `\`${k}\``).join(',')}) VALUES (${keys.map(() => '?').join(',')})`, keys.map((k) => data[k]));
  } catch (e) { console.warn('Payroll audit logging:', e.message); }
}
const ownEmployeeId = (req) => Number((req.session && (req.session.employeeId || req.session.employee_id)) || 0);
const userId = (req) => Number((req.session && (req.session.userId || req.session.user_id)) || 0) || null;
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

/* relative pay-date hint for runs that are not posted yet */
function dueHint(payDate, status) {
  if (status === 'Posted') return ['', ''];
  const due = P.parseYmd(payDate);
  if (!due) return ['', ''];
  const diff = P.diffDays(due, P.parseYmd(P.toYmd(new Date())));
  const s = (n) => `${n} day${n === 1 ? '' : 's'}`;
  if (diff < 0) return [`Overdue by ${s(-diff)}`, 'late'];
  if (diff === 0) return ['Due today', 'soon'];
  if (diff <= 3) return [`Due in ${s(diff)}`, 'soon'];
  return [`In ${diff} days`, 'ok'];
}

/* ---------- list ---------- */

router.get('/', wrap(async (req, res) => {
  await C.syncOpenRuns(db);

  const departmentFilter = parseInt(req.query.department_id, 10) || 0;
  let frequencyFilter = String(req.query.frequency || '').trim();
  let statusFilter = String(req.query.status || '').trim();
  if (!FREQUENCIES.includes(frequencyFilter)) frequencyFilter = '';

  const [all] = await db.query(
    `SELECT pr.*, d.name AS department_name, COUNT(p.payroll_id) AS total_employees, COALESCE(SUM(p.net_pay), 0) AS total_net_pay
     FROM payroll_run pr
     LEFT JOIN department d ON d.department_id = pr.department_id
     LEFT JOIN payroll p ON pr.payroll_run_id = p.payroll_run_id
     GROUP BY pr.payroll_run_id, d.name
     ORDER BY pr.period_end DESC`);   /* add your archive filter here (gp_notArchivedSql) once Archive is ported */

  const [departments] = await db.query('SELECT department_id, name FROM department ORDER BY name');

  let runs = all;
  if (departmentFilter > 0) runs = runs.filter((r) => Number(r.department_id || 0) === departmentFilter);
  if (frequencyFilter) runs = runs.filter((r) => String(r.pay_frequency || '').trim().toLowerCase() === frequencyFilter.toLowerCase());

  /* stats are counted before the status filter so the cards / tabs always show the full picture */
  const stats = { total: runs.length, draft: 0, processing: 0, posted: 0, disbursed: 0 };
  for (const r of runs) {
    const st = r.status || 'Draft';
    if (st === 'Draft') stats.draft++;
    if (st === 'Processing') stats.processing++;
    if (st === 'Posted') { stats.posted++; stats.disbursed += Number(r.total_net_pay || 0); }
  }

  if (STATUSES.includes(statusFilter)) runs = runs.filter((r) => (r.status || 'Draft') === statusFilter);
  else statusFilter = '';

  const rows = runs.map((r) => {
    const status = r.status || 'Draft';
    const ps = P.parseYmd(r.period_start);
    const pe = P.parseYmd(r.period_end);
    const [dueText, dueClass] = dueHint(P.toYmd(r.pay_date), status);
    return {
      ...r, status,
      statusClass: status.toLowerCase(),
      stepsOn: status === 'Posted' ? 3 : status === 'Processing' ? 2 : 1,
      periodDays: ps && pe ? P.diffDays(pe, ps) + 1 : 0,
      sameYear: !!(ps && pe && ps.getUTCFullYear() === pe.getUTCFullYear()),
      period_start_f: P.formatDate(r.period_start), period_end_f: P.formatDate(r.period_end), pay_date_f: P.formatDate(r.pay_date),
      dueText, dueClass,
    };
  });

  res.render('payroll/index', {
    pageTitle: 'Payroll Management',
    runs: rows, departments, departmentFilter, frequencyFilter, statusFilter,
    frequencyOptions: FREQUENCIES, stats,
    hasActiveFilters: departmentFilter > 0 || !!frequencyFilter || !!statusFilter,
    shownEmployees: rows.reduce((a, r) => a + Number(r.total_employees || 0), 0),
    shownNet: rows.reduce((a, r) => a + Number(r.total_net_pay || 0), 0),
    error: req.query.error || '', updated: req.query.updated !== undefined,
  });
}));

router.post('/', wrap(async (req, res) => {
  const runId = parseInt(req.body.payroll_run_id, 10) || 0;
  const action = req.body.action || '';

  if (runId > 0 && action === 'process') return res.redirect(`/payroll/process/${runId}`);

  if (runId > 0 && action === 'post') {
    try {
      const n = await C.postRun(db, runId, userId(req));
      await audit(req, `Posted (finalized) payroll run #${runId} (${n} employees)`);
    } catch (e) {
      const msg = e instanceof C.UserError ? e.message : 'Unable to post the payroll run.';
      if (!(e instanceof C.UserError)) console.error('[post run]', e);
      return res.redirect('/payroll?error=' + encodeURIComponent(msg));
    }
    return res.redirect('/payroll?updated=1');
  }
  res.redirect('/payroll');
}));

/* ---------- create run ---------- */

/* JSON used by the create page: live validation + pay date (department_period.php) */
router.get('/department-period', wrap(async (req, res) => {
  const departmentId = parseInt(req.query.department_id, 10) || 0;
  const date = String(req.query.date || '').trim();
  const end = String(req.query.end || '').trim();
  let frequency = String(req.query.frequency || '').trim();

  try {
    const schedule = departmentId > 0 ? await P.departmentSchedule(db, departmentId) : null;
    if (!schedule) return res.json({ ok: false, message: 'Select a department.' });

    frequency = CREATE_FREQUENCY;
    const today = P.todayYmd();

    const out = {
      ok: true, today, frequency, period_start: '', period_end: '', valid: false, error: '', warning: '', segments: [],
      hint: '', pay_date: '', pay_weekday: '', cutoff_date: '', employees: 0, attendance: 0,
    };

    if (!P.isValidDate(date)) {                       /* no start yet: only suggest a START date */
      const s = await P.suggestedPeriod(db, departmentId);
      out.period_start = s ? s.period_start : '';
      if (out.period_start && out.period_start < today) out.period_start = today; /* never suggest a past start */
      return res.json(out);
    }
    out.period_start = date;
    out.max = maxDateFrom(today);
    if (date < today) { out.error = pastMessage(today); return res.json(out); }
    if (date > out.max) { out.error = tooFarMessage(out.max); return res.json(out); }

    if (!P.isValidDate(end)) {                        /* start only: show what a valid period looks like */
      out.hint = P.validatePeriodRange(frequency, date, date, schedule).hint;
      return res.json(out);
    }

    const check = P.validatePeriodRange(frequency, date, end, schedule);
    out.period_end = end;
    out.hint = check.hint;
    if (end < today) { out.error = pastMessage(today); return res.json(out); }
    if (end > out.max) { out.error = tooFarMessage(out.max); return res.json(out); }
    if (!check.ok) { out.error = check.error; return res.json(out); }

    out.warning = check.warning;
    const notice = C.departmentStaffingMessage(await C.departmentStaffing(db, departmentId), 'processed');
    if (notice) out.warning = `${out.warning} ${notice}`.trim();

    out.segments = check.segments.map((s) => ({ ...s, share_pct: Math.round(s.share * 10000) / 100 }));
    const first = check.segments[0];
    const probe = { payroll_run_id: 0, department_id: departmentId, period_start: date, period_end: end };
    const ids = (await C.runEmployees(db, probe)).eligible.map((e) => Number(e.employee_id));

    out.valid = true;
    out.cutoff_date = first.period_end;
    out.pay_date = first.pay_date;
    out.pay_weekday = first.pay_weekday;
    out.employees = ids.length;
    out.attendance = await C.runAttendanceCount(db, probe, ids);
    res.json(out);
  } catch (e) {
    console.error('[department-period]', e);
    res.status(500).json({ ok: false, message: 'Unable to load the department schedule.' });
  }
}));

/* the server's real date, polled by the create page so its calendar never relies on the browser clock */
router.get('/today', (req, res) => { res.set('Cache-Control', 'no-store'); const t = P.todayYmd(); res.json({ today: t, max: maxDateFrom(t) }); });

async function createForm(req, res, error = '') {
  const [departments] = await db.query('SELECT department_id, name FROM department ORDER BY name');
  res.render('payroll/create', {
    pageTitle: 'Create Payroll Run', departments, error, today: P.todayYmd(), maxDate: maxDateFrom(P.todayYmd()),
    form: {
      department_id: parseInt(req.body && req.body.department_id, 10) || 0,
      period_start: (req.body && req.body.period_start) || '',
      period_end: (req.body && req.body.period_end) || '',
      pay_frequency: CREATE_FREQUENCY,
      pay_date: (req.body && req.body.pay_date) || '',
    },
  });
}

router.get('/create', wrap((req, res) => createForm(req, res)));

router.post('/create', wrap(async (req, res) => {
  const periodStart = String(req.body.period_start || '').trim();
  const periodEnd = String(req.body.period_end || '').trim();
  const frequency = req.body.pay_frequency || CREATE_FREQUENCY;
  const departmentId = parseInt(req.body.department_id, 10) || 0;
  const fail = (m) => createForm(req, res, m);

  if (!periodStart || !periodEnd || departmentId <= 0) return fail('Please select a department and enter the payroll start and end dates.');
  if (!P.isValidDate(periodStart)) return fail('Please enter a valid payroll start date.');
  if (!P.isValidDate(periodEnd)) return fail('Please enter a valid payroll end date.');
  if (frequency !== CREATE_FREQUENCY) return fail('Only the Semi-monthly pay frequency is available.');
  const today = P.todayYmd();
  if (periodStart < today || periodEnd < today) return fail(pastMessage(today));
  const maxDate = maxDateFrom(today);
  if (periodStart > maxDate || periodEnd > maxDate) return fail(tooFarMessage(maxDate));

  const schedule = await P.departmentSchedule(db, departmentId);
  if (!schedule) return fail('The selected department does not exist.');

  const range = P.validatePeriodRange(frequency, periodStart, periodEnd, schedule);
  if (!range.ok) return fail(range.error);
  if (!range.segments.length) return fail('Unable to build the payroll periods from those dates.');

  try {
    const createdIds = await C.withTx(db, async (tx) => {
      const [dep] = await tx.query('SELECT department_id FROM department WHERE department_id = ? FOR UPDATE', [departmentId]);
      if (!dep.length) throw new C.UserError('The selected department does not exist.');

      /* RULE 1: only ONE open batch of runs per department; a new run only after the old ones are processed AND posted */
      const [open] = await tx.query(
        "SELECT payroll_run_id, period_start, period_end, status FROM payroll_run WHERE department_id = ? AND status <> 'Posted' ORDER BY payroll_run_id DESC LIMIT 1", [departmentId]);
      if (open.length) {
        const o = open[0];
        throw new C.UserError(`This department still has an unfinished payroll run (${P.toYmd(o.period_start)} to ${P.toYmd(o.period_end)}, status: ${o.status}). Process and post it first before adding another run.`);
      }

      /* RULE 2: the same day / week / month / year can never be paid twice for the same department */
      const [ov] = await tx.query(
        'SELECT payroll_run_id, period_start, period_end FROM payroll_run WHERE department_id = ? AND period_start <= ? AND period_end >= ? LIMIT 1',
        [departmentId, periodEnd, periodStart]);
      if (ov.length) {
        throw new C.UserError(`A payroll run (${P.toYmd(ov[0].period_start)} to ${P.toYmd(ov[0].period_end)}) already covers part of this period for the selected department.`);
      }

      /* RULE 3: an empty payroll run is never created (checked for every payroll of the coverage) */
      for (const seg of range.segments) {
        const probe = { payroll_run_id: 0, department_id: departmentId, period_start: seg.period_start, period_end: seg.period_end };
        if (!(await C.runEmployees(tx, probe)).eligible.length) {
          throw new C.UserError(`No eligible active employees were found for the selected department and the period ${seg.period_start} to ${seg.period_end}.`);
        }
      }

      const hasCutoff = await H.columnExists(tx, 'payroll_run', 'cutoff_date');
      const hasFactor = await H.columnExists(tx, 'payroll_run', 'pay_factor');
      const hasCoverage = (await H.columnExists(tx, 'payroll_run', 'coverage_start')) && (await H.columnExists(tx, 'payroll_run', 'coverage_end'));

      const ids = [];
      for (const seg of range.segments) {
        /* only the pay date is calculated (period end + 5 days, never a Sunday); start / end are what the user typed */
        const cols = ['department_id', 'period_start', 'period_end', 'pay_frequency', 'pay_date'];
        const vals = [departmentId, seg.period_start, seg.period_end, frequency, seg.pay_date];
        if (hasCutoff) { cols.push('cutoff_date'); vals.push(seg.period_end); }
        if (hasFactor) { cols.push('pay_factor'); vals.push(seg.factor); }
        if (hasCoverage && range.segments.length > 1) { cols.push('coverage_start', 'coverage_end'); vals.push(periodStart, periodEnd); }
        cols.push('status'); vals.push('Draft');

        const [ins] = await tx.query(`INSERT INTO payroll_run (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, vals);
        ids.push(ins.insertId);
        await C.syncRun(tx, ins.insertId, true); /* one payroll record per eligible employee, visible immediately */
      }
      return ids;
    });

    /* runs now exist: days of their periods that are already over with no attendance are Absent */
    await H.autoMarkAbsent(db);
    for (const id of createdIds) await C.syncRun(db, id);

    await audit(req, `Created ${createdIds.length} ${frequency} payroll run(s) #${createdIds.join(', #')} (department #${departmentId}, coverage ${periodStart} to ${periodEnd})`);
    return createdIds.length === 1 ? res.redirect(`/payroll/view/${createdIds[0]}`) : res.redirect('/payroll?updated=1');
  } catch (e) {
    if (e instanceof C.UserError) return fail(e.message);
    console.error('[create run]', e);
    return fail('Unable to create payroll run. Please try again.');
  }
}));

/* ---------- process ---------- */

router.get('/process/:id', wrap(async (req, res) => renderProcess(req, res)));

router.post('/process/:id', wrap(async (req, res) => {
  const runId = parseInt(req.params.id, 10) || 0;
  try {
    const [rr] = await db.query('SELECT * FROM payroll_run WHERE payroll_run_id = ? LIMIT 1', [runId]);
    if (!rr.length) throw new C.UserError('Payroll run not found.');
    const staffingError = C.departmentStaffingMessage(await C.departmentStaffing(db, Number(rr[0].department_id || 0)), 'processed');
    if (staffingError) return renderProcess(req, res, staffingError);

    const n = await C.processRun(db, runId);
    await audit(req, `Processed payroll run #${runId} (${n} employees)`);
    return res.redirect(`/payroll/view/${runId}`);
  } catch (e) {
    if (!(e instanceof C.UserError)) console.error('[process run]', e);
    return renderProcess(req, res, e instanceof C.UserError ? e.message : 'Unable to process the payroll run.');
  }
}));

async function renderProcess(req, res, error = '') {
  const runId = parseInt(req.params.id, 10) || 0;
  if (runId <= 0) return res.redirect('/payroll');

  const [rr] = await db.query('SELECT * FROM payroll_run WHERE payroll_run_id = ? LIMIT 1', [runId]);
  const run = rr[0];
  if (!run) return res.redirect('/payroll?error=' + encodeURIComponent('Payroll run not found.'));

  /* payroll can only be processed when the department has BOTH an assigned HR / Timekeeper and Supervisor */
  const staffingError = C.departmentStaffingMessage(await C.departmentStaffing(db, Number(run.department_id || 0)), 'processed');

  const [rows] = await db.query(
    `SELECT p.*, e.first_name, e.last_name FROM payroll p INNER JOIN employee e ON e.employee_id = p.employee_id
     WHERE p.payroll_run_id = ? ORDER BY e.last_name, e.first_name`, [runId]);

  res.render('payroll/process', {
    pageTitle: 'Process Payroll', runId,
    run: { ...run, period_start_f: P.formatDate(run.period_start), period_end_f: P.formatDate(run.period_end) },
    payrollRows: rows, staffingError, error: error || staffingError,
  });
}

/* ---------- view ---------- */

const PRIVATE_FIELDS = ['basic_pay', 'overtime_pay', 'holiday_pay', 'gross_pay', 'total_deductions', 'net_pay', 'sss', 'philhealth', 'pagibig', 'bir',
  'absence_deduction', 'late_deduction', 'undertime_deduction', 'unpaid_leave_deduction', 'government_deductions', 'attendance_deductions',
  'company_deductions', 'company_lines'];

router.get('/view/:id', wrap(async (req, res) => {
  const runId = parseInt(req.params.id, 10) || 0;
  if (runId <= 0) return res.redirect('/payroll');

  /* Draft and Processing runs are recalculated from the current attendance; a Posted run is never touched */
  await C.syncRun(db, runId);

  const [rr] = await db.query('SELECT * FROM payroll_run WHERE payroll_run_id = ? LIMIT 1', [runId]);
  const run = rr[0];
  if (!run) return res.redirect('/payroll');

  const [employees] = await db.query(
    `SELECT p.payroll_id, p.employee_id, p.basic_pay, p.overtime_pay, p.holiday_pay, p.gross_pay, p.total_deductions, p.net_pay,
            e.first_name, e.last_name, d.name AS department
     FROM payroll p INNER JOIN employee e ON e.employee_id = p.employee_id LEFT JOIN department d ON d.department_id = e.department_id
     WHERE p.payroll_run_id = ? ORDER BY e.last_name, e.first_name`, [runId]);

  const isPosted = run.status === 'Posted';
  const excluded = !isPosted && Number(run.department_id || 0) > 0 ? (await C.runEmployees(db, run)).excluded : [];

  const totals = { gross: 0, government: 0, attendance: 0, company: 0, deductions: 0, net: 0 };
  for (const e of employees) {
    const c = await C.calculateEmployeePayroll(db, Number(e.employee_id), run);
    /* posted payroll keeps exactly what was paid; open payroll shows the live calculation */
    const gross = isPosted ? P.round(Number(e.gross_pay), 2) : c.gross_pay;
    const ded = isPosted ? P.round(Number(e.total_deductions), 2) : c.total_deductions;
    const net = isPosted ? P.round(Number(e.net_pay), 2) : c.net_pay;

    Object.assign(e, {
      sss: c.sss, philhealth: c.philhealth, pagibig: c.pagibig, bir: c.bir,
      absent_days: c.absent_days, late_minutes: c.late_minutes, undertime_hours: c.undertime_hours,
      unpaid_leave_days: c.unpaid_leave_days, paid_leave_days: c.paid_leave_days, overtime_hours: c.overtime_hours,
      absence_deduction: c.absence_deduction, late_deduction: c.late_deduction,
      undertime_deduction: c.undertime_deduction, unpaid_leave_deduction: c.unpaid_leave_deduction,
      government_deductions: c.government_deductions, attendance_deductions: c.attendance_deductions,
      company_deductions: c.company_deductions, company_lines: c.company_lines,
      gross_pay: gross, total_deductions: ded, net_pay: net,
    });
    totals.gross += gross; totals.government += c.government_deductions; totals.attendance += c.attendance_deductions;
    totals.company += c.company_deductions; totals.deductions += ded; totals.net += net;
  }

  /* payroll is private: everyone only sees THEIR OWN pay figures. Others' amounts are removed here, so they never reach the browser. */
  const own = ownEmployeeId(req);
  for (const e of employees) {
    e.is_own = own > 0 && Number(e.employee_id) === own;
    if (!e.is_own) for (const f of PRIVATE_FIELDS) e[f] = null;
  }
  for (const k of Object.keys(totals)) totals[k] = P.round(totals[k], 2);

  res.render('payroll/view', {
    pageTitle: 'Payroll Run Details', runId, isPosted, employees, excluded, totals,
    run: { ...run, period_start_f: P.formatDate(run.period_start), period_end_f: P.formatDate(run.period_end), pay_date_f: P.formatDate(run.pay_date) },
  });
}));


/* ---------- re-edit and re-submit payroll run ---------- */

router.get('/resubmit/:id', wrap(async (req, res) => res.redirect('/payroll/process/' + (parseInt(req.params.id, 10) || 0)))); /* re-editing is done on the Process / Recalculate page */

router.post('/resubmit/:id', wrap(async (req, res) => {
  const runId = parseInt(req.params.id, 10) || 0;
  if (runId <= 0) return res.redirect('/payroll');

  try {
    const result = await C.withTx(db, async (tx) => {
      // 1. Fetch & lock payroll run
      const [rr] = await tx.query(
        'SELECT * FROM payroll_run WHERE payroll_run_id = ? FOR UPDATE',
        [runId]
      );
      const run = rr[0];
      if (!run) throw new C.UserError('Payroll run not found.');

      // 2. Security Check: Block if already finalized/posted
      if (run.status === 'Posted') {
        throw new C.UserError('Posted payroll runs are finalized and cannot be re-edited or resubmitted.');
      }

      // 3. Rollback any loan schedules tied to this run back to 'Pending'[cite: 3]
      await tx.query(
        `UPDATE loan_schedule 
         SET status = 'Pending', paid_run_id = NULL 
         WHERE paid_run_id = ?`,
        [runId]
      );

      // 4. Reset linked deductions for this run[cite: 3]
      await tx.query(`DELETE FROM payroll_deduction WHERE payroll_run_id = ?`, [runId]);

      // 5. Trigger live calculation and re-sync employee line items
      await C.syncRun(tx, runId, true);

      // 6. Update run status to 'Processing' or 'Submitted'[cite: 3]
      await tx.query(
        `UPDATE payroll_run 
         SET status = 'Processing'
         WHERE payroll_run_id = ?`,
        [runId]
      );

      return runId;
    });

    // 7. Auto-mark absent days and record audit log
    await H.autoMarkAbsent(db);
    await audit(req, `Re-edited and resubmitted payroll run #${runId}`);

    return res.redirect(`/payroll/view/${runId}?updated=1`);
  } catch (e) {
    if (e instanceof C.UserError) {
      return renderResubmitForm(req, res, e.message);
    }
    console.error('[resubmit run]', e);
    return renderResubmitForm(req, res, 'Unable to resubmit payroll run. Please try again.');
  }
}));

async function renderResubmitForm(req, res, error = '') {
  const runId = parseInt(req.params.id, 10) || 0;
  if (runId <= 0) return res.redirect('/payroll');

  const [rr] = await db.query('SELECT * FROM payroll_run WHERE payroll_run_id = ? LIMIT 1', [runId]);
  const run = rr[0];
  if (!run) return res.redirect('/payroll?error=' + encodeURIComponent('Payroll run not found.'));

  if (run.status === 'Posted') {
    return res.redirect('/payroll?error=' + encodeURIComponent('Cannot edit a posted run.'));
  }

  // Fetch employees and current calculated state
  const [employees] = await db.query(
    `SELECT p.*, e.first_name, e.last_name, d.name AS department
     FROM payroll p 
     INNER JOIN employee e ON e.employee_id = p.employee_id 
     LEFT JOIN department d ON d.department_id = e.department_id
     WHERE p.payroll_run_id = ? 
     ORDER BY e.last_name, e.first_name`,
    [runId]
  );

  res.render('payroll/resubmit', {
    pageTitle: 'Re-Edit Payroll Run',
    runId,
    error,
    run: { 
      ...run, 
      period_start_f: P.formatDate(run.period_start), 
      period_end_f: P.formatDate(run.period_end), 
      pay_date_f: P.formatDate(run.pay_date) 
    },
    employees
  });
}

module.exports = router;