const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { archiveRecord } = require('./archiveStore'); // Assuming standard MySQL connection pool

// Middleware to ensure authentication
function isAuthenticated(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    }
    res.redirect('/auth/login');
}

// 1. List all employees (Index)
router.get('/', isAuthenticated, async (req, res) => {
    try {
        const [employees] = await db.query(`
            SELECT e.*, d.department_name 
            FROM employees e 
            LEFT JOIN departments d ON e.department_id = d.id 
            WHERE e.archived = 0 
            ORDER BY e.created_at DESC
        `);
        res.render('employees/index', { title: 'Employee Management', employees, user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// 2. Render Create Employee Form
router.get('/create', isAuthenticated, async (req, res) => {
    try {
        const [departments] = await db.query('SELECT * FROM departments ORDER BY department_name ASC');
        res.render('employees/create', { title: 'Add Employee', departments, user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// 3. Handle Create Employee Submission
router.post('/create', isAuthenticated, async (req, res) => {
    const { employee_code, first_name, last_name, department_id, position, basic_salary, sss, philhealth, pagibig, tin } = req.body;
    try {
        await db.query(`
            INSERT INTO employees (employee_code, first_name, last_name, department_id, position, basic_salary, sss, philhealth, pagibig, tin, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        `, [employee_code, first_name, last_name, department_id, position, basic_salary, sss, philhealth, pagibig, tin]);
        
        res.redirect('/employees');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error saving employee');
    }
});

// 4. View Employee Details
router.get('/view/:id', isAuthenticated, async (req, res) => {
    try {
        const [employee] = await db.query(`
            SELECT e.*, d.department_name 
            FROM employees e 
            LEFT JOIN departments d ON e.department_id = d.id 
            WHERE e.id = ?
        `, [req.params.id]);

        if (employee.length === 0) {
            return res.status(404).send('Employee not found');
        }

        res.render('employees/view', { title: 'Employee Profile', employee: employee[0], user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// 5. Render Edit Employee Form
router.get('/edit/:id', isAuthenticated, async (req, res) => {
    try {
        const [employee] = await db.query('SELECT * FROM employees WHERE id = ?', [req.params.id]);
        const [departments] = await db.query('SELECT * FROM departments ORDER BY department_name ASC');

        if (employee.length === 0) {
            return res.status(404).send('Employee not found');
        }

        res.render('employees/edit', { title: 'Edit Employee', employee: employee[0], departments, user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// 6. Handle Update Employee
router.post('/edit/:id', isAuthenticated, async (req, res) => {
    const { employee_code, first_name, last_name, department_id, position, basic_salary, sss, philhealth, pagibig, tin } = req.body;
    try {
        await db.query(`
            UPDATE employees 
            SET employee_code = ?, first_name = ?, last_name = ?, department_id = ?, position = ?, basic_salary = ?, sss = ?, philhealth = ?, pagibig = ?, tin = ?
            WHERE id = ?
        `, [employee_code, first_name, last_name, department_id, position, basic_salary, sss, philhealth, pagibig, tin, req.params.id]);

        res.redirect('/employees');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error updating employee');
    }
});

// 7. Archive Employee (never permanently delete from this route)
router.post('/archive/:id', isAuthenticated, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM employees WHERE id = ? LIMIT 1', [req.params.id]);
        if (!rows.length) return res.status(404).send('Employee not found');
        await archiveRecord({ sourceTable: 'employees', sourceId: rows[0].id, label: `Employee: ${rows[0].first_name || ''} ${rows[0].last_name || ''}`.trim(), data: rows[0], module: 'Employees', req });
        await db.query('UPDATE employees SET archived = 1 WHERE id = ?', [req.params.id]);
        res.redirect('/employees');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error archiving employee');
    }
});

module.exports = router;