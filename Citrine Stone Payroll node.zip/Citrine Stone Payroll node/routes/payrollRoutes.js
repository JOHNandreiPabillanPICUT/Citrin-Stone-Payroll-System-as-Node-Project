const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');

// View Payroll Runs
router.get('/', isAuth, async (req, res) => {
  try {
    const [payrolls] = await db.query('SELECT * FROM payroll_run ORDER BY payroll_run_id DESC');
    res.render('payroll/index', { payrolls, user: req.session });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database Error');
  }
});

// Process New Payroll Run
router.post('/process', isAuth, async (req, res) => {
  const { period_start, period_end } = req.body;
  try {
    // Insert a draft payroll run matching your payroll_run schema columns
    await db.query(
      `INSERT INTO payroll_run (period_start, period_end, pay_frequency, pay_date, status) VALUES (?, ?, 'Weekly', CURDATE(), 'Draft')`,
      [period_start, period_end]
    );
    res.redirect('/payroll');
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to process payroll');
  }
});

module.exports = router;