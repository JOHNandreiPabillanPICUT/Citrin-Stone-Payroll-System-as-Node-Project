'use strict';
// Compatibility alias: the server and any older imports use the same fixed
// attendance routes, avoiding two different QR scan implementations.
module.exports = require('./attendance');
