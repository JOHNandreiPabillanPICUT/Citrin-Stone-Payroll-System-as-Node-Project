'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const { archiveRecord } = require('./archiveStore');
const { ensureApprovalSchema, ensureStageColumns, HR_VISIBLE } = require('../lib/approvalFlow');

let schemaPromise;
const qid = s => '`' + String(s).replace(/`/g, '``') + '`';

async function columns(table) {
  const [rows] = await db.query('SELECT COLUMN_NAME AS name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [table]);
  return new Set(rows.map(r => r.name));
}

async function ensureSchema() {
  if (!schemaPromise) schemaPromise = (async () => {
    await db.query(`CREATE TABLE IF NOT EXISTS overtime_request (
      overtime_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
      employee_id INT NOT NULL,
      department_id INT NULL,
      work_date DATE NOT NULL,
      start_time TIME NOT NULL,
      end_time TIME NOT NULL,
      total_hours DECIMAL(5,2) NOT NULL,
      reason TEXT NOT NULL,
      status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
      created_by INT NULL,
      decided_by INT NULL,
      decided_at DATETIME NULL,
      remarks TEXT NULL,
      payroll_status ENUM('Not Processed','Processed') NOT NULL DEFAULT 'Not Processed',
      payroll_run_id INT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_ot_employee_date (employee_id, work_date),
      INDEX idx_ot_status_payroll (status, payroll_status),
      INDEX idx_ot_department (department_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    const cols = await columns('overtime_request');
    const additions = {
      department_id: 'INT NULL', created_by: 'INT NULL', decided_by: 'INT NULL', decided_at: 'DATETIME NULL',
      remarks: 'TEXT NULL', payroll_status: "ENUM('Not Processed','Processed') NOT NULL DEFAULT 'Not Processed'",
      payroll_run_id: 'INT NULL', created_at: 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
      updated_at: 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
    };
    for (const [name, definition] of Object.entries(additions)) if (!cols.has(name)) await db.query(`ALTER TABLE overtime_request ADD COLUMN ${qid(name)} ${definition}`);
    const refreshed = await columns('overtime_request');
    const required = ['overtime_id','employee_id','work_date','start_time','end_time','reason','status'];
    const missing = required.filter(name => !refreshed.has(name));
    if (!refreshed.has('total_hours') && !refreshed.has('hours')) missing.push('hours (or total_hours)');
    if (missing.length) {
      throw new Error(`The existing overtime_request table is missing required column(s): ${missing.join(', ')}. Back up the database, then migrate/repair that table before using Overtime.`);
    }
    await ensureStageColumns(db, 'overtime_request');
    const employeeCols = await columns('employee');
    if (employeeCols.has('employee_id') && employeeCols.has('department_id') && refreshed.has('department_id')) {
      await db.query(`UPDATE overtime_request o JOIN employee e ON e.employee_id=o.employee_id SET o.department_id=e.department_id WHERE o.department_id IS NULL`);
    }
  })();
  try { await schemaPromise; } catch (e) { schemaPromise = null; throw e; }
}

function roleOf(req) { return String(req.session?.role || req.session?.role_name || req.session?.user?.role || '').trim().toLowerCase(); }
function userId(req) { const n = Number(req.session?.userId || req.session?.user_id || req.session?.user?.user_id); return Number.isFinite(n) && n > 0 ? n : null; }
function employeeId(req) { const n = Number(req.session?.employee_id || req.session?.employeeId || req.session?.user?.employee_id); return Number.isFinite(n) && n > 0 ? n : null; }
function canManage(role) { return role === 'admin' || role === 'administrator' || role === 'supervisor'; }
function requireRole(allowed) { return (req,res,next) => allowed.includes(roleOf(req)) ? next() : res.status(403).send('You do not have permission to perform this action.'); }

async function employeeForSession(req) {
  if (employeeId(req)) return employeeId(req);
  const uid = userId(req);
  if (uid) { const [u] = await db.query('SELECT employee_id FROM users WHERE user_id=? LIMIT 1', [uid]); if (u[0]?.employee_id) return Number(u[0].employee_id); }
  const username = req.session?.username || req.session?.user?.username;
  if (!username) return null;
  const cols = await columns('employee');
  if (!cols.has('username')) return null;
  const [rows] = await db.query('SELECT employee_id FROM employee WHERE username = ? LIMIT 1', [username]);
  return rows[0]?.employee_id || null;
}

async function supervisorDepartments(uid) {
  const [rows] = await db.query('SELECT department_id FROM department WHERE supervisor_user_id=?', [uid]);
  return rows.map(r => Number(r.department_id));
}

function dateOk(v) { return /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) && !Number.isNaN(Date.parse(`${v}T00:00:00`)); }
function timeMinutes(v) { const m = /^(\d{2}):(\d{2})(?::\d{2})?$/.exec(String(v || '')); if (!m || +m[1]>23 || +m[2]>59) return null; return +m[1]*60 + +m[2]; }
function calculateHours(start,end) { const s=timeMinutes(start), e=timeMinutes(end); if(s===null||e===null) return null; let diff=e-s; if(diff<=0) diff+=1440; return Math.round(diff/60*100)/100; }

async function requestScope(req) {
  const role=roleOf(req), empId=await employeeForSession(req), uid=userId(req);
  if (role==='admin'||role==='administrator') return {role,empId,uid,where:'1=1',params:[]};
  
  // Employees can VIEW overtime filed for them by HR/Supervisors, but cannot file requests
  if (role==='employee') { 
    if(!empId) return {role,empId,uid,where:'1=0',params:[]}; 
    return {role,empId,uid,where:'o.employee_id=?',params:[empId]}; 
  }
  
  if (!uid) return {role,empId,uid,where:'1=0',params:[]};
  if (role==='hr') return {role,empId,uid,where:`o.department_id IN (SELECT d.department_id FROM department d WHERE d.hr_user_id=?) AND ${HR_VISIBLE('o')}`,params:[uid]};
  if (role==='supervisor') return {role,empId,uid,where:'o.department_id IN (SELECT d.department_id FROM department d WHERE d.supervisor_user_id=?)',params:[uid]};
  return {role,empId,uid,where:'1=0',params:[]};
}

async function buildSelectSql() {
  const ec = await columns('employee');
  const oc = await columns('overtime_request');
  const uc = await columns('users');
  const dc = await columns('department');
  const empDept = ec.has('department_id') ? 'e.department_id' : 'NULL';
  const reqDept = oc.has('department_id') ? 'o.department_id' : 'NULL';
  const deptJoin = dc.has('department_id') && dc.has('name') ? `LEFT JOIN department d ON d.department_id=COALESCE(${reqDept},${empDept})` : '';
  const deptName = deptJoin ? 'd.name AS department_name' : `'' AS department_name`;
  const creatorJoin = uc.has('user_id') && uc.has('username') && oc.has('created_by') ? 'LEFT JOIN users creator ON creator.user_id=o.created_by' : '';
  const deciderCol = oc.has('decided_by') ? 'o.decided_by' : (oc.has('approved_by') ? 'o.approved_by' : 'NULL');
  const deciderJoin = uc.has('user_id') && uc.has('username') ? `LEFT JOIN users decider ON decider.user_id=${deciderCol}` : '';
  const supervisorJoin = uc.has('user_id') && uc.has('username') && oc.has('supervisor_id') ? 'LEFT JOIN users sup ON sup.user_id=o.supervisor_id' : '';
  const supervisorName = supervisorJoin ? 'sup.username AS supervisor_name' : `'' AS supervisor_name`;
  const creatorName = creatorJoin ? 'creator.username AS created_by_name' : `'' AS created_by_name`;
  const deciderName = deciderJoin ? 'decider.username AS decided_by_name' : `'' AS decided_by_name`;
  const hourCol = oc.has('total_hours') ? 'o.total_hours' : 'o.hours';
  return { sql: `SELECT o.*, ${hourCol} AS total_hours, e.first_name, e.last_name, ${empDept} AS employee_department_id, ${deptName}, ${creatorName}, ${deciderName}, ${supervisorName} FROM overtime_request o JOIN employee e ON e.employee_id=o.employee_id ${deptJoin} ${creatorJoin} ${deciderJoin} ${supervisorJoin}`, hourCol };
}

router.get('/', isAuth, async (req,res) => {
  try {
    await ensureSchema(); const scope=await requestScope(req);
    const search=String(req.query.search||'').trim().slice(0,100); const status=String(req.query.status||'').trim();
    let where=`(${scope.where})`; const params=[...scope.params];
    if(search){ where += ` AND CONCAT_WS(' ',e.first_name,e.last_name) LIKE ?`; params.push(`%${search}%`); }
    if(['Pending','Approved','Rejected'].includes(status)){where+=' AND o.status=?';params.push(status);}
    const select = await buildSelectSql();
    const orderCol = (await columns('overtime_request')).has('created_at') ? 'o.created_at' : 'o.overtime_id';
    const [requests]=await db.query(`${select.sql} WHERE ${where} ORDER BY ${orderCol} DESC, o.overtime_id DESC`,params);
    const [[metrics]]=await db.query(`SELECT SUM(o.status='Pending') AS pending_count, SUM(o.status='Approved') AS approved_count, SUM(o.status='Rejected') AS rejected_count, COALESCE(SUM(CASE WHEN o.status='Approved' THEN ${select.hourCol} ELSE 0 END),0) AS approved_hours FROM overtime_request o JOIN employee e ON e.employee_id=o.employee_id WHERE ${scope.where}`,scope.params);
    let canCreate=scope.role==='admin'||scope.role==='administrator'||scope.role==='hr'; // only Admin and HR file overtime
    let employees=[];
    if(canCreate){
      if(scope.role==='supervisor'){
        const ids=await supervisorDepartments(scope.uid);
        if(ids.length){const marks=ids.map(()=>'?').join(',');[employees]=await db.query(`SELECT employee_id, first_name,last_name,department_id FROM employee WHERE department_id IN (${marks}) AND COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated') ORDER BY last_name,first_name`,ids);}
      } else [employees]=await db.query(`SELECT employee_id, first_name,last_name,department_id FROM employee WHERE COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated') ORDER BY last_name,first_name`);
    }
    const normalized= requests.map(r=>({...r, employee_name:[r.first_name,r.last_name].filter(Boolean).join(' ')}));
    res.render('overtime/index',{title:'Overtime Requests',requests:normalized,metrics:metrics||{},employees,role:scope.role,sessionEmployeeId:scope.empId,search,statusFilter:status,user:req.session.user||req.session});
  } catch(err){console.error('Overtime list error:',err);res.status(500).send('Unable to load overtime requests. Check the Node.js terminal for the exact database error. Confirm DB_NAME in your .env file and verify the employee, department, users, and overtime_request tables.');}
});

router.post('/create', isAuth, requireRole(['admin','administrator','hr']), async (req,res)=>{
  try {
    // Explicitly reject requests if employee role attempts to call this route directly
    if (roleOf(req) === 'employee') {
      return res.status(403).send('Employees are not allowed to request overtime. Overtime is filed by HR or an Admin.');
    }

    await ensureSchema(); const scope=await requestScope(req); const empId=Number(req.body.employee_id); const workDate=String(req.body.work_date||''); const start=String(req.body.start_time||''); const end=String(req.body.end_time||''); const reason=String(req.body.reason||'').trim(); const hours=calculateHours(start,end);
    if(!Number.isInteger(empId)||empId<1||!dateOk(workDate)||hours===null||hours<0.25||hours>16||!reason||reason.length>2000) return res.status(400).send('Invalid overtime request. Enter a valid employee, work date, time range (0.25–16 hours), and reason.');
    const [employees]=await db.query(`SELECT employee_id,department_id FROM employee WHERE employee_id=? AND COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated') LIMIT 1`,[empId]);
    if(!employees.length) return res.status(400).send('Selected employee is not active.'); const deptId=employees[0].department_id;
    if(scope.role==='supervisor'){
      const ids=await supervisorDepartments(scope.uid);
      if(empId===scope.empId || !deptId || !ids.includes(Number(deptId))) return res.status(403).send('Supervisors can only create requests for other employees in their assigned department.');
    }
    const [dupes]=await db.query(`SELECT overtime_id FROM overtime_request WHERE employee_id=? AND work_date=? AND status='Pending' AND payroll_status='Not Processed' LIMIT 1`,[empId,workDate]);
    if(dupes.length) return res.status(409).send('An active overtime request already exists for this employee and work date.');
    const overtimeCols = await columns('overtime_request'); const hourColumn = overtimeCols.has('total_hours') ? 'total_hours' : 'hours';
    const createColumns = ['employee_id','department_id','work_date','start_time','end_time',hourColumn,'reason','status','created_by','payroll_status','supervisor_status','supervisor_id','supervisor_at','supervisor_remarks'].filter(c => overtimeCols.has(c));
    const createValues = {employee_id:empId,department_id:deptId,work_date:workDate,start_time:start,end_time:end,[hourColumn]:hours,reason,status:'Pending',created_by:userId(req),payroll_status:'Not Processed',supervisor_status:'Endorsed',supervisor_id:userId(req),supervisor_at:new Date(),supervisor_remarks:'Filed by '+scope.role+' on behalf of the employee'};
    await db.query(`INSERT INTO overtime_request (${createColumns.map(qid).join(',')}) VALUES (${createColumns.map(()=>'?').join(',')})`,createColumns.map(c=>createValues[c]));
    res.redirect('/overtime');
  }catch(err){console.error('Overtime create error:',err);res.status(500).send('Failed to create overtime request.');}
});

router.post('/action/:id', isAuth, requireRole(['admin','administrator','supervisor','hr']), async (req,res)=>{
  try {
    await ensureSchema(); const scope=await requestScope(req); const id=Number(req.params.id); const action=String(req.body.status||''); const remarks=String(req.body.remarks||'').trim();
    const allowed = scope.role==='supervisor' ? ['Endorsed','Rejected'] : ['Approved','Rejected'];
    if(!Number.isInteger(id)||id<1||!allowed.includes(action)||remarks.length>2000) return res.status(400).send('Invalid overtime decision.');
    const [rows]=await db.query(`SELECT * FROM overtime_request WHERE overtime_id=? LIMIT 1`,[id]); if(!rows.length) return res.status(404).send('Overtime request not found.'); const ot=rows[0];
    if(ot.status!=='Pending') return res.status(409).send('Only pending overtime requests can be approved or rejected.');
    if(ot.payroll_status==='Processed') return res.status(409).send('This overtime request has already been processed for payroll.');
    if(scope.role==='supervisor'){
      const ids=await supervisorDepartments(scope.uid);
      if(!scope.empId || Number(ot.employee_id)===Number(scope.empId)) return res.status(403).send('Supervisors cannot approve or reject their own overtime.');
      if(!ids.includes(Number(ot.department_id))) return res.status(403).send('You may only review overtime requests from your assigned department.');
      if(ot.supervisor_status!=='Pending') return res.status(409).send('This request has already been reviewed by the supervisor.');
      if(action==='Endorsed'){
        await db.query(`UPDATE overtime_request SET supervisor_status='Endorsed',supervisor_id=?,supervisor_at=NOW(),supervisor_remarks=? WHERE overtime_id=? AND status='Pending' AND supervisor_status='Pending'`,[scope.uid,remarks||null,id]);
      } else {
        await db.query(`UPDATE overtime_request SET status='Rejected',supervisor_status='Rejected',supervisor_id=?,supervisor_at=NOW(),supervisor_remarks=?,decided_by=?,decided_at=NOW(),remarks=? WHERE overtime_id=? AND status='Pending' AND supervisor_status='Pending'`,[scope.uid,remarks||null,scope.uid,remarks||null,id]);
      }
      return res.redirect('/overtime');
    }
    if(scope.role==='hr'){
      const [dept]=await db.query('SELECT 1 FROM department WHERE department_id=? AND hr_user_id=?',[ot.department_id,scope.uid]);
      if(!dept.length) return res.status(403).send('You may only decide overtime requests from your assigned department.');
      if(ot.supervisor_status!=='Endorsed') return res.status(409).send('This request has not been endorsed by the supervisor yet.');
    }
    await db.query(`UPDATE overtime_request SET status=?,decided_by=?,decided_at=NOW(),remarks=? WHERE overtime_id=? AND status='Pending'`,[action,userId(req),remarks||null,id]);
    res.redirect('/overtime');
  }catch(err){console.error('Overtime decision error:',err);res.status(500).send('Failed to update overtime request.');}
});

router.post('/payroll/process', isAuth, requireRole(['admin','administrator','hr']), async (req,res)=>{
  const start=String(req.body.period_start||''); const end=String(req.body.period_end||''); const runId=req.body.payroll_run_id ? Number(req.body.payroll_run_id) : null;
  if(!dateOk(start)||!dateOk(end)||start>end) return res.status(400).send('Select a valid payroll date range.');
  if(req.body.confirm !== 'yes') return res.status(400).send('Confirm payroll processing before marking overtime as processed.');
  let conn;
  try{
    await ensureSchema(); conn=await db.getConnection(); await conn.beginTransaction();
    const scope=await requestScope(req); const otCols = await columns('overtime_request'); const hourCol = otCols.has('total_hours') ? 'o.total_hours' : 'o.hours';
    const [rows]=await conn.query(`SELECT o.overtime_id,${hourCol} AS total_hours FROM overtime_request o JOIN employee e ON e.employee_id=o.employee_id WHERE o.status='Approved' AND o.payroll_status='Not Processed' AND o.work_date BETWEEN ? AND ? AND (${scope.where}) FOR UPDATE`,[start,end,...scope.params]);
    if(rows.length){const ids=rows.map(r=>r.overtime_id);const marks=ids.map(()=>'?').join(',');await conn.query(`UPDATE overtime_request SET payroll_status='Processed', payroll_run_id=? WHERE overtime_id IN (${marks}) AND status='Approved' AND payroll_status='Not Processed'`,[runId,...ids]);}
    await conn.commit();
    const hours=rows.reduce((sum,r)=>sum+Number(r.total_hours||0),0);
    return res.send(`<html><head><meta charset="utf-8"><title>Overtime payroll selection</title></head><body style="font-family:Arial,sans-serif;padding:40px"><h2>Approved overtime marked as processed</h2><p>Payroll period: ${start} to ${end}</p><p>Requests marked processed: ${rows.length}</p><p>Total eligible overtime hours: ${hours.toFixed(2)}</p><p>Only previously approved, unprocessed requests were included. This endpoint marks records to prevent duplicate processing; connect the returned eligible hours to your payroll calculation before using it as a payment total.</p><p><a href="/overtime">Return to Overtime Requests</a></p></body></html>`);
  }catch(err){if(conn)await conn.rollback();console.error('Overtime payroll processing error:',err);res.status(500).send('Unable to process approved overtime.');}finally{if(conn)conn.release();}
});

router.post('/archive/:id', isAuth, requireRole(['admin','administrator']), async (req,res)=>{
  try{
    await ensureSchema(); const id=Number(req.params.id); if(!Number.isInteger(id)||id<1) return res.status(400).send('Invalid overtime request.');
    const [rows]=await db.query('SELECT * FROM overtime_request WHERE overtime_id=? LIMIT 1',[id]); if(!rows.length) return res.status(404).send('Overtime request not found.');
    await archiveRecord({sourceTable:'overtime_request',sourceId:rows[0].overtime_id,label:`Overtime request #${rows[0].overtime_id}`,data:rows[0],module:'Overtime',req});
    await db.query('DELETE FROM overtime_request WHERE overtime_id=?',[id]); res.redirect('/overtime');
  }catch(err){console.error('Overtime archive error:',err);res.status(500).send('Unable to archive overtime request.');}
});

module.exports=router;