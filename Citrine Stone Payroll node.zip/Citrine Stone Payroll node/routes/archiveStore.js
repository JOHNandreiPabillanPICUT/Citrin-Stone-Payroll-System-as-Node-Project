'use strict';
const { stripIds } = require('../lib/displayText');
const db = require('../config/database');

async function ensureArchiveTable() {
  await db.query(`CREATE TABLE IF NOT EXISTS archive_records (
    archive_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    source_table VARCHAR(100) NOT NULL,
    source_id VARCHAR(100) NOT NULL,
    record_label VARCHAR(255) NOT NULL,
    record_data JSON NOT NULL,
    module VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL DEFAULT 'Archive',
    outcome VARCHAR(50) NOT NULL DEFAULT 'Archived',
    archived_by VARCHAR(190) NULL,
    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    restored_at DATETIME NULL,
    INDEX idx_archive_module (module),
    INDEX idx_archive_archived_at (archived_at),
    INDEX idx_archive_restored_at (restored_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
}

function actor(req) {
  const s = req.session || {};
  return String(s.username || s.user?.username || s.name || s.userId || s.user_id || 'System');
}
async function archiveRecord({ sourceTable, sourceId, label, data, module, req, connection = db }) {
  await ensureArchiveTable();
  await connection.query(`INSERT INTO archive_records
    (source_table, source_id, record_label, record_data, module, action, outcome, archived_by)
    VALUES (?, ?, ?, ?, ?, 'Archive', 'Archived', ?)`,
    [sourceTable, String(sourceId), stripIds(label || module), JSON.stringify(data), module, actor(req)]);
}
module.exports = { ensureArchiveTable, archiveRecord, actor };
