'use strict';

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const bcrypt = require('bcryptjs');
const { homeFor } = require('../middleware/rbac');

router.get('/login', (req, res) => {
    if (req.session && (req.session.userId || req.session.user_id)) {
        return res.redirect(homeFor(req.session.role));
    }

    return res.render('auth/login', {
        error: null
    });
});

router.post('/login', async (req, res) => {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');

    if (!username || !password) {
        return res.status(400).render('auth/login', {
            error: 'Please enter your username and password.'
        });
    }

    try {
        const [rows] = await db.query(
            `SELECT
                u.*,
                r.role_name
             FROM users u
             INNER JOIN roles r
                ON r.role_id = u.role_id
             WHERE u.username = ?
               AND u.status = ?
             LIMIT 1`,
            [username, 'Active']
        );

        if (rows.length === 0) {
            return res.status(401).render('auth/login', {
                error: 'Invalid username or password.'
            });
        }

        const user = rows[0];

        if (!user.password_hash) {
            return res.status(401).render('auth/login', {
                error: 'The account has no password hash. Contact the administrator.'
            });
        }

        const passwordMatches = await bcrypt.compare(
            password,
            user.password_hash
        );

        if (!passwordMatches) {
            return res.status(401).render('auth/login', {
                error: 'Invalid username or password.'
            });
        }

        req.session.regenerate((sessionError) => {
            if (sessionError) {
                console.error('Session regeneration error:', sessionError);

                return res.status(500).render('auth/login', {
                    error: 'Unable to establish your session. Please try again.'
                });
            }

            req.session.userId = user.user_id;
            req.session.user_id = user.user_id;
            req.session.username = user.username;
            req.session.role = user.role_name;
            req.session.employee_id = user.employee_id || null;
            req.session.must_change_password = Boolean(Number(user.must_change_password));

            req.session.save((saveError) => {
                if (saveError) {
                    console.error('Session save error:', saveError);

                    return res.status(500).render('auth/login', {
                        error: 'Unable to save your login session. Please try again.'
                    });
                }

                return res.redirect(req.session.must_change_password ? '/auth/change-password' : homeFor(req.session.role));
            });
        });
    } catch (err) {
        console.error('Login error:', err);

        return res.status(500).render('auth/login', {
            error: 'A server error occurred while logging in.'
        });
    }
});

function isLoggedIn(req) {
    return Boolean(req.session && (req.session.userId || req.session.user_id));
}

router.get('/change-password', (req, res) => {
    if (!isLoggedIn(req)) return res.redirect('/auth/login');
    return res.render('auth/change_password', { error: null, forced: Boolean(req.session.must_change_password) });
});

router.post('/change-password', async (req, res) => {
    if (!isLoggedIn(req)) return res.redirect('/auth/login');
    const forced = Boolean(req.session.must_change_password);
    const current = String(req.body.current_password || '');
    const next = String(req.body.new_password || '');
    const confirm = String(req.body.confirm_password || '');
    const show = (error, status = 400) => res.status(status).render('auth/change_password', { error, forced });

    if (!current || !next || !confirm) return show('Please fill in all fields.');
    if (next.length < 8) return show('New password must be at least 8 characters.');
    if (next !== confirm) return show('New password and confirmation do not match.');
    if (next === current) return show('New password must be different from your temporary password.');

    try {
        const userId = req.session.userId || req.session.user_id;
        const [rows] = await db.query('SELECT password_hash FROM users WHERE user_id = ? LIMIT 1', [userId]);
        if (!rows.length || !(await bcrypt.compare(current, rows[0].password_hash || ''))) {
            return show('Temporary password is incorrect.', 401);
        }
        const hash = await bcrypt.hash(next, 10);
        await db.query('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE user_id = ?', [hash, userId]);
        req.session.must_change_password = false;
        return req.session.save(() => res.redirect(homeFor(req.session.role)));
    } catch (err) {
        console.error('Change password error:', err);
        return show('A server error occurred while saving your password.', 500);
    }
});

/* Forgot password: the employee files a request; an admin approves it from the Users page. */
const forgotHits = new Map();
router.post('/forgot-password', async (req, res) => {
    const ip = req.ip || 'x'; const now = Date.now();
    const hits = (forgotHits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
    if (hits.length >= 5) return res.status(429).json({ ok: false, message: 'Too many requests. Please try again in a few minutes.' });
    hits.push(now); forgotHits.set(ip, hits);
    try {
        const out = await require('../lib/passwordReset').createRequest(req.body.username, req.body.employee_code, req.body.note);
        if (out.error) return res.status(400).json({ ok: false, message: out.error });
        if (out.created) require('../lib/realtime').broadcast({ path: '/users' }); /* admin's badge updates live */
        return res.json({ ok: true, token: out.token, message: 'Your request was sent to the administrator. Once it is approved, sign in with the temporary password you were given, then choose a new password.' });
    } catch (err) {
        console.error('Forgot password request error:', err);
        return res.status(500).json({ ok: false, message: 'Unable to send your request right now. Please contact the administrator.' });
    }
});

/* The requester's login page polls this to learn the administrator's decision without reloading. */
const statusHits = new Map();
router.get('/forgot-password/status/:token', async (req, res) => {
    const ip = req.ip || 'x'; const now = Date.now();
    const hits = (statusHits.get(ip) || []).filter((t) => now - t < 60 * 1000);
    if (hits.length >= 60) return res.status(429).json({ state: 'slow' });
    hits.push(now); statusHits.set(ip, hits);
    res.set('Cache-Control', 'no-store');
    try { return res.json(await require('../lib/passwordReset').status(req.params.token)); }
    catch (err) { console.error('Forgot password status error:', err); return res.status(500).json({ state: 'error' }); }
});

/* Instant push of the decision (Server-Sent Events); the polling route above is the fallback. */
router.get('/forgot-password/stream/:token', (req, res) => {
    try { require('../lib/passwordReset').watch(req.params.token, req, res); }
    catch (err) { console.error('Forgot password stream error:', err); if (!res.headersSent) res.status(500).end(); }
});

router.get('/logout', (req, res) => {
    if (!req.session) {
        return res.redirect('/auth/login');
    }

    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
            return res.status(500).send('Unable to log out. Please try again.');
        }

        res.clearCookie('connect.sid');
        return res.redirect('/auth/login');
    });
});

module.exports = router;