/* modules/department/index.php, create.php, edit.php  (delete.php is replaced by Archive) */
'use strict';

const express = require('express');
const db = require('../config/db');
const { logAudit } = require('../lib/audit');
const { csrfValid } = require('../lib/security');
const { hasRole, requireRole } = require('../lib/rbac');
const { safe } = require('../middleware/auth');
const A = require('../lib/archive');

const router = express.Router();

const ROLE_HR = 2;
const ROLE_SUPERVISOR = 4;

/* Active accounts of one role that are linked to an active employee and not already running another department */
function assignableUsers(roleId, excludeDepartmentId) {
  const col = roleId === ROLE_HR ? 'hr_user_id' : 'supervisor_user_id';
  return db.all(
    `SELECT u.user_id, u.username, e.employee_id, e.first_name, e.last_name
     FROM users u JOIN employee e ON e.employee_id = u.employee_id
     WHERE u.role_id = ? AND u.status = 'Active' AND e.status = 'Active'
       AND NOT EXISTS (SELECT 1 FROM department d
                       WHERE d.${col} = u.user_id AND d.department_id <> ?)
     ORDER BY e.last_name, e.first_name, u.username`,
    [roleId, Number(excludeDepartmentId || 0)]);
}

/* Shared create / edit validation. Throws Error(message) for the form. HR and Supervisor are optional. */
async function validateAssignments(tx, { name, hrUserId, supervisorUserId, departmentId }) {
  const dup = Number(await tx.scalar('SELECT COUNT(*) FROM department WHERE name = ? AND department_id <> ?', [name, departmentId]));
  if (dup > 0) throw new Error(departmentId ? 'Another department already uses this name.' : 'This department already exists.');

  const check = async (userId, roleId, col, noun) => {
    if (userId <= 0) return;
    const ok = Number(await tx.scalar(
      "SELECT COUNT(*) FROM users u JOIN employee e ON e.employee_id = u.employee_id WHERE u.user_id = ? AND u.role_id = ? AND u.status = 'Active' AND e.status = 'Active'",
      [userId, roleId]));
    if (ok !== 1) throw new Error(`Select an active ${noun} account linked to an active employee.`);
    const taken = Number(await tx.scalar(`SELECT COUNT(*) FROM department WHERE ${col} = ? AND department_id <> ?`, [userId, departmentId]));
    if (taken > 0) throw new Error(`That ${noun} is already assigned to another department.`);
  };
  await check(hrUserId, ROLE_HR, 'hr_user_id', 'HR / Timekeeper');
  await check(supervisorUserId, ROLE_SUPERVISOR, 'supervisor_user_id', 'Supervisor');

  if (hrUserId > 0 && hrUserId === supervisorUserId) {
    throw new Error('The HR / Timekeeper and the Supervisor must be two different accounts.');
  }
}

const formVars = (req) => ({
  name: String(req.body.name || '').trim(),
  hrUserId: Number(req.body.hr_user_id || 0) || 0,
  supervisorUserId: Number(req.body.supervisor_user_id || 0) || 0,
});

/* ---------------------------------------------------------------- list */
router.get('/', safe(async (req, res) => {
  const departments = await db.all(`
    SELECT d.department_id, d.name, d.hr_user_id, d.supervisor_user_id,
           CONCAT(hr_emp.first_name, ' ', hr_emp.last_name) AS hr_name, hr_user.username AS hr_username,
           CONCAT(sup_emp.first_name, ' ', sup_emp.last_name) AS supervisor_name, sup_user.username AS supervisor_username,
           COUNT(e.employee_id) AS employee_count
    FROM department d
    LEFT JOIN users hr_user ON hr_user.user_id = d.hr_user_id
    LEFT JOIN employee hr_emp ON hr_emp.employee_id = hr_user.employee_id
    LEFT JOIN users sup_user ON sup_user.user_id = d.supervisor_user_id
    LEFT JOIN employee sup_emp ON sup_emp.employee_id = sup_user.employee_id
    LEFT JOIN employee e ON e.department_id = d.department_id
        AND ${A.notArchivedSql(req, 'employee', 'e.employee_id', true)}
    WHERE ${A.notArchivedSql(req, 'department', 'd.department_id')}
    GROUP BY d.department_id, d.name, d.hr_user_id, d.supervisor_user_id,
             hr_emp.first_name, hr_emp.last_name, hr_user.username,
             sup_emp.first_name, sup_emp.last_name, sup_user.username
    ORDER BY d.name ASC`);

  const canManage = hasRole(req, 'Admin');          // HR may view only
  let totalEmployees = 0; let incomplete = 0;
  for (const d of departments) {
    d.employee_count = Number(d.employee_count);
    totalEmployees += d.employee_count;
    if (!d.hr_user_id || !d.supervisor_user_id) incomplete++;
    d.archiveHtml = (canManage && d.employee_count === 0)
      ? A.archiveForm(req, 'department', d.department_id, 'Archive this department? It will be moved to the Archive page.', { cls: 'btn btn-sm btn-secondary' })
      : '';
  }

  res.render('department/index', {
    pageTitle: 'Departments', extraCss: ['/css/department.css', '/css/department-modal.css'],
    departments, canManage, totalEmployees, incomplete,
    hrUsers: canManage ? await assignableUsers(ROLE_HR, 0) : [],
    supervisors: canManage ? await assignableUsers(ROLE_SUPERVISOR, 0) : [],
    modalErrors: [], modalName: '', modalHrUserId: 0, modalSupervisorUserId: 0,
  });
}));

/* ---------------------------------------------------------------- create (Admin) */
router.get('/create', requireRole('Admin'), safe(async (req, res) => {
  res.render('department/form', {
    pageTitle: 'Add Department', mode: 'create', errors: [], employees: [], departmentId: 0,
    name: '', hrUserId: 0, supervisorUserId: 0,
    hrUsers: await assignableUsers(ROLE_HR, 0), supervisors: await assignableUsers(ROLE_SUPERVISOR, 0),
  });
}));

router.post('/create', requireRole('Admin'), safe(async (req, res) => {
  const { name, hrUserId, supervisorUserId } = formVars(req);
  const errors = [];
  if (!csrfValid(req)) errors.push('Invalid form session. Please reload the page and try again.');
  if (!errors.length && name === '') errors.push('Department name is required.');
  if (name.length > 100) errors.push('Department name must not exceed 100 characters.');

  if (!errors.length) {
    try {
      await db.transaction(async (tx) => {
        await validateAssignments(tx, { name, hrUserId, supervisorUserId, departmentId: 0 });
        await tx.run('INSERT INTO department (name, hr_user_id, supervisor_user_id) VALUES (?, ?, ?)',
          [name, hrUserId > 0 ? hrUserId : null, supervisorUserId > 0 ? supervisorUserId : null]);
      });
      const hrLog = hrUserId > 0 ? `HR user #${hrUserId}` : 'no HR';
      const supLog = supervisorUserId > 0 ? `supervisor user #${supervisorUserId}` : 'no supervisor';
      await logAudit(req, 'Department', `Added department '${name}' with ${hrLog}, ${supLog}`);
      req.session.success = 'Department added successfully.';
      return res.redirect('/department');
    } catch (e) {
      errors.push(e.message);
    }
  }

  return res.render('department/form', {
    pageTitle: 'Add Department', mode: 'create', errors, employees: [], departmentId: 0,
    name, hrUserId, supervisorUserId,
    hrUsers: await assignableUsers(ROLE_HR, 0), supervisors: await assignableUsers(ROLE_SUPERVISOR, 0),
  });
}));

/* ---------------------------------------------------------------- edit (Admin) */
async function loadEdit(req, res) {
  const departmentId = Number(req.query.id || 0);
  if (departmentId <= 0) { req.session.error = 'Invalid department.'; res.redirect('/department'); return null; }
  const department = await db.one(
    'SELECT department_id, name, hr_user_id, supervisor_user_id FROM department WHERE department_id = ? LIMIT 1', [departmentId]);
  if (!department) { req.session.error = 'Department not found.'; res.redirect('/department'); return null; }
  return department;
}

async function renderEdit(res, department, errors, values) {
  const employees = await db.all(
    'SELECT employee_id, first_name, last_name FROM employee WHERE department_id = ? ORDER BY last_name, first_name',
    [department.department_id]);
  res.render('department/form', {
    pageTitle: 'Edit Department', mode: 'edit', errors, employees, departmentId: department.department_id,
    name: values.name, hrUserId: values.hrUserId, supervisorUserId: values.supervisorUserId,
    hrUsers: await assignableUsers(ROLE_HR, department.department_id),
    supervisors: await assignableUsers(ROLE_SUPERVISOR, department.department_id),
  });
}

router.get('/edit', requireRole('Admin'), safe(async (req, res) => {
  const d = await loadEdit(req, res);
  if (!d) return undefined;
  return renderEdit(res, d, [], { name: d.name, hrUserId: Number(d.hr_user_id || 0), supervisorUserId: Number(d.supervisor_user_id || 0) });
}));

router.post('/edit', requireRole('Admin'), safe(async (req, res) => {
  const d = await loadEdit(req, res);
  if (!d) return undefined;

  const { name, hrUserId, supervisorUserId } = formVars(req);
  const errors = [];
  if (!csrfValid(req)) errors.push('Invalid form session. Please reload the page and try again.');
  if (name === '') errors.push('Department name is required.');
  if (name.length > 100) errors.push('Department name must not exceed 100 characters.');

  if (!errors.length) {
    try {
      await db.transaction(async (tx) => {
        await validateAssignments(tx, { name, hrUserId, supervisorUserId, departmentId: d.department_id });
        await tx.run('UPDATE department SET name = ?, hr_user_id = ?, supervisor_user_id = ? WHERE department_id = ?',
          [name, hrUserId > 0 ? hrUserId : null, supervisorUserId > 0 ? supervisorUserId : null, d.department_id]);
        // Employees are NOT moved here: an employee's department cannot be changed after it was set.
      });
      await logAudit(req, 'Department', `Updated department '${name}' (ID ${d.department_id}), HR / Timekeeper and Supervisor updated`);
      req.session.success = 'Department updated successfully.';
      return res.redirect('/department');
    } catch (e) {
      errors.push(e.message);
    }
  }
  return renderEdit(res, d, errors, { name, hrUserId, supervisorUserId });
}));

module.exports = router;
