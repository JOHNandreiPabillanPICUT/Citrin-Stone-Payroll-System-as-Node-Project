'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');

async function columns(table) {
  const [rows] = await db.query(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`, [table]);
  return rows.map(r => r.COLUMN_NAME);
}
async function firstTable(names) {
  const [rows] = await db.query(`SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${names.map(() => '?').join(',')})`, names);
  const found = new Set(rows.map(r => r.TABLE_NAME));
  return names.find(n => found.has(n)) || null;
}
function choose(cols, options) { return options.find(x => cols.includes(x)) || null; }
function ident(name) { if (!/^[a-zA-Z0-9_]+$/.test(name || '')) throw new Error('Invalid database identifier'); return `\`${name}\``; }

router.get('/', requireAuth, async (req, res) => {
  try {
    const employeeCols = await columns('employee');
    const employeeId = choose(employeeCols, ['employee_id','id']);
    const firstName = choose(employeeCols, ['first_name','firstname','given_name']);
    const lastName = choose(employeeCols, ['last_name','lastname','surname']);
    const code = choose(employeeCols, ['employee_code','emp_code','employee_number']);
    if (!employeeId || !firstName || !lastName) throw new Error('Employee table must contain employee ID, first name, and last name columns.');

    const [employees] = await db.query(`SELECT ${ident(employeeId)} AS employee_id, ${ident(firstName)} AS first_name, ${ident(lastName)} AS last_name, ${code ? ident(code) : "''"} AS employee_code FROM employee ORDER BY ${ident(lastName)}, ${ident(firstName)}`);
    const requestedId = String(req.query.employee_id || (employees[0] ? employees[0].employee_id : ''));
    const selected = employees.find(e => String(e.employee_id) === requestedId) || employees[0] || null;
    let attendance = [], leaves = [], stats = { present: 0, late: 0, absent: 0, approvedLeaves: 0, leaveDays: 0 };
    let attendanceMessage = '', leaveMessage = '';

    const attendanceTable = await firstTable(['attendance','attendances']);
    if (attendanceTable && selected) {
      const ac = await columns(attendanceTable);
      const aid = choose(ac, ['attendance_id','id']);
      const aeid = choose(ac, ['employee_id','emp_id']);
      const dateCol = choose(ac, ['work_date','date','attendance_date']);
      const inCol = choose(ac, ['time_in','timein','clock_in']);
      const outCol = choose(ac, ['time_out','timeout','clock_out']);
      const statusCol = choose(ac, ['status','attendance_status']);
      const lateCol = choose(ac, ['tardiness_minutes','tardiness','late_minutes']);
      const underCol = choose(ac, ['undertime_minutes','undertime']);
      if (aeid && dateCol) {
        const [rows] = await db.query(`SELECT ${ident(dateCol)} AS work_date, ${inCol ? ident(inCol) : 'NULL'} AS time_in, ${outCol ? ident(outCol) : 'NULL'} AS time_out, ${statusCol ? ident(statusCol) : "'Present'"} AS status, ${lateCol ? ident(lateCol) : '0'} AS tardiness, ${underCol ? ident(underCol) : '0'} AS undertime FROM ${ident(attendanceTable)} WHERE ${ident(aeid)} = ? ORDER BY ${ident(dateCol)} DESC LIMIT 500`, [selected.employee_id]);
        attendance = rows;
        stats.present = rows.filter(r => /present/i.test(String(r.status || ''))).length;
        stats.late = rows.filter(r => /late/i.test(String(r.status || '')) || Number(r.tardiness) > 0).length;
        stats.absent = rows.filter(r => /absent/i.test(String(r.status || ''))).length;
      } else attendanceMessage = `The ${attendanceTable} table is missing an employee ID or date column.`;
    } else attendanceMessage = 'Attendance table was not found.';

    const leaveTable = await firstTable(['leave_requests','leave_request','leave_applications','leave_application','leaves']);
    if (leaveTable && selected) {
      const lc = await columns(leaveTable);
      const leid = choose(lc, ['employee_id','emp_id']);
      const start = choose(lc, ['start_date','date_from','leave_start_date','from_date']);
      const end = choose(lc, ['end_date','date_to','leave_end_date','to_date']);
      const status = choose(lc, ['status','leave_status','approval_status']);
      const type = choose(lc, ['leave_type','type','leave_name']);
      const reason = choose(lc, ['reason','remarks','description']);
      const order = start || choose(lc, ['created_at','request_date','leave_id','id']);
      if (leid) {
        const [rows] = await db.query(`SELECT ${start ? ident(start) : 'NULL'} AS start_date, ${end ? ident(end) : 'NULL'} AS end_date, ${status ? ident(status) : "'Pending'"} AS status, ${type ? ident(type) : "'Leave'"} AS leave_type, ${reason ? ident(reason) : "''"} AS reason FROM ${ident(leaveTable)} WHERE ${ident(leid)} = ? ORDER BY ${order ? ident(order) : '1'} DESC LIMIT 200`, [selected.employee_id]);
        leaves = rows;
        const approved = rows.filter(r => /approved|accepted/i.test(String(r.status || '')));
        stats.approvedLeaves = approved.length;
        stats.leaveDays = approved.reduce((sum, r) => {
          if (!r.start_date || !r.end_date) return sum;
          const a = new Date(r.start_date), b = new Date(r.end_date);
          const days = Math.floor((b - a) / 86400000) + 1;
          return sum + (Number.isFinite(days) && days > 0 ? days : 0);
        }, 0);
      } else leaveMessage = `The ${leaveTable} table has no employee ID column.`;
    } else leaveMessage = 'Leave application table was not found.';

    res.render('ledger/index', { title: 'Attendance & Leave Ledger', selected, employees, attendance, leaves, stats, attendanceMessage, leaveMessage, user: req.session });
  } catch (err) {
    console.error('Ledger page error:', err);
    res.status(500).send(`Unable to load Attendance & Leave Ledger. Check your employee, attendance, and leave table structures. Details: ${process.env.NODE_ENV === 'development' ? err.message : 'see server terminal'}`);
  }
});
module.exports = router;
