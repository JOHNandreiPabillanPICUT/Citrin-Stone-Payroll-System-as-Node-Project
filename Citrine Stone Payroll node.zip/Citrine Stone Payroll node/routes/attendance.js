'use strict';

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const { archiveRecord } = require('./archiveStore');
const { ensureMiddleware } = require('../lib/approvalFlow');
const Sched = require('../lib/attendanceSchedule');

router.use(requireAuth);
router.use(ensureMiddleware(db));

// This route deliberately detects the column names already present in the
// user's database. It does not alter tables or require a schema migration.
const TABLE_CANDIDATES = {
  employee: ['employee', 'employees'],
  attendance: ['attendance', 'attendances']
};
const COLUMN_CANDIDATES = {
  employeeId: ['employee_id', 'id', 'emp_id'],
  employeeCode: ['employee_code', 'emp_code', 'employee_no', 'staff_code'],
  firstName: ['first_name', 'firstname', 'given_name'],
  lastName: ['last_name', 'lastname', 'surname'],
  attendanceId: ['attendance_id', 'id', 'record_id'],
  attendanceEmployeeId: ['employee_id', 'emp_id'],
  workDate: ['work_date', 'date', 'attendance_date'],
  timeIn: ['time_in', 'timein', 'clock_in'],
  timeOut: ['time_out', 'timeout', 'clock_out'],
  status: ['status', 'attendance_status']
};

const ident = (value) => `\`${String(value).replace(/`/g, '``')}\``;
const firstExisting = (columns, names) => names.find(name => columns.includes(name)) || null;

async function getTableColumns(tableName) {
  const [rows] = await db.query(
    `SELECT COLUMN_NAME AS column_name FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`,
    [tableName]
  );
  return rows.map(row => row.column_name);
}

async function getTableInfo(candidates, requiredColumnCandidates) {
  const [tables] = await db.query(
    `SELECT TABLE_NAME AS table_name FROM INFORMATION_SCHEMA.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'`
  );
  const tableNames = tables.map(row => row.table_name);
  for (const table of candidates) {
    if (!tableNames.includes(table)) continue;
    const columns = await getTableColumns(table);
    const mapped = {};
    for (const [key, names] of Object.entries(requiredColumnCandidates)) {
      mapped[key] = firstExisting(columns, names);
    }
    return { table, columns, ...mapped };
  }
  throw new Error(`Could not find a compatible table. Checked: ${candidates.join(', ')}`);
}

async function schema() {
  const employee = await getTableInfo(TABLE_CANDIDATES.employee, {
    employeeId: COLUMN_CANDIDATES.employeeId,
    employeeCode: COLUMN_CANDIDATES.employeeCode,
    firstName: COLUMN_CANDIDATES.firstName,
    lastName: COLUMN_CANDIDATES.lastName
  });
  const attendance = await getTableInfo(TABLE_CANDIDATES.attendance, {
    attendanceId: COLUMN_CANDIDATES.attendanceId,
    attendanceEmployeeId: COLUMN_CANDIDATES.attendanceEmployeeId,
    workDate: COLUMN_CANDIDATES.workDate,
    timeIn: COLUMN_CANDIDATES.timeIn,
    timeOut: COLUMN_CANDIDATES.timeOut,
    status: COLUMN_CANDIDATES.status
  });
  const missing = [];
  if (!employee.employeeId) missing.push(`${employee.table}.employee_id`);
  if (!employee.employeeCode) missing.push(`${employee.table}.employee_code`);
  if (!employee.firstName) missing.push(`${employee.table}.first_name`);
  if (!employee.lastName) missing.push(`${employee.table}.last_name`);
  if (!attendance.attendanceId) missing.push(`${attendance.table}.attendance_id`);
  if (!attendance.attendanceEmployeeId) missing.push(`${attendance.table}.employee_id`);
  if (!attendance.workDate) missing.push(`${attendance.table}.work_date/date`);
  if (!attendance.timeIn) missing.push(`${attendance.table}.time_in`);
  if (!attendance.timeOut) missing.push(`${attendance.table}.time_out`);
  if (!attendance.status) missing.push(`${attendance.table}.status`);
  if (missing.length) throw new Error(`Missing required attendance columns: ${missing.join(', ')}`);
  return { employee, attendance };
}

function localDate() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}
function localTime() {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
}
function localMinutes() { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); }
function ymd(v) {
  if (v instanceof Date) return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  return String(v || '').slice(0, 10);
}
function tv(v) {
  if (v instanceof Date) return `${String(v.getHours()).padStart(2, '0')}:${String(v.getMinutes()).padStart(2, '0')}:${String(v.getSeconds()).padStart(2, '0')}`;
  return String(v).slice(-8);
}
function timeValue(value) {
  if (!value) return null;
  const text = String(value).trim();
  return /^\d{2}:\d{2}$/.test(text) ? `${text}:00` : text;
}
function parseEmployeeCode(value) {
  let code = String(value || '').trim();
  if (!code) return '';
  // Accept raw employee codes or QR payloads such as {"employee_code":"GAI-HR-0001"}.
  try {
    const parsed = JSON.parse(code);
    if (parsed && typeof parsed === 'object') {
      code = String(parsed.employee_code || parsed.employeeCode || parsed.code || parsed.employee_id || '').trim();
    }
  } catch (_) {
    // A plain string QR payload is expected and needs no parsing.
  }
  // Some QR badges encode a URL with employee_code=...
  if (/^https?:\/\//i.test(code)) {
    try {
      const url = new URL(code);
      code = url.searchParams.get('employee_code') || url.searchParams.get('code') || code;
    } catch (_) {}
  }
  return code;
}

async function getEmployees(s) {
  const e = s.employee;
  return db.query(
    `SELECT ${ident(e.employeeId)} AS employee_id,
            ${ident(e.employeeCode)} AS employee_code,
            ${ident(e.firstName)} AS first_name,
            ${ident(e.lastName)} AS last_name
     FROM ${ident(e.table)}
     ORDER BY ${ident(e.lastName)}, ${ident(e.firstName)}`
  ).then(([rows]) => rows);
}

function renderError(res, message, status = 500) {
  return res.status(status).send(`
    <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Attendance error</title><link rel="stylesheet" href="/css/citrine-theme.css"></head>
    <body style="margin:0;padding:32px;background:#f4f4f4;color:#414141;font-family:Arial,sans-serif">
      <main style="max-width:760px;margin:5vh auto;background:#fff;padding:28px;border-radius:14px;box-shadow:0 8px 24px #0001">
        <h1 style="margin-top:0;color:#d62828">Attendance could not be loaded</h1>
        <p>${String(message).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}</p>
        <p>Check that the selected MySQL database contains an employee table and an attendance table with employee IDs, a work date, time-in, time-out, and status columns.</p>
        <a href="/attendance" style="color:#d62828">Try again</a>
      </main></body></html>`);
}

// Attendance directory, filters, and counts.
router.get('/', requireAuth, async (req, res) => {
  try {
    const s = await schema();
    const e = s.employee, a = s.attendance;
    const filters = {
      date: String(req.query.date || '').trim(),
      employee_id: String(req.query.employee_id || '').trim()
    };
    const where = [`COALESCE(a.${ident(a.status)}, '') <> 'Archived'`];
    const params = [];
    if (filters.date) { where.push(`a.${ident(a.workDate)} = ?`); params.push(filters.date); }
    if (filters.employee_id) { where.push(`a.${ident(a.attendanceEmployeeId)} = ?`); params.push(filters.employee_id); }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const [attendanceRecords] = await db.query(
      `SELECT a.${ident(a.attendanceId)} AS attendance_id,
              a.${ident(a.attendanceEmployeeId)} AS employee_id,
              a.${ident(a.workDate)} AS work_date,
              a.${ident(a.timeIn)} AS time_in,
              a.${ident(a.timeOut)} AS time_out,
              a.${ident(a.status)} AS status,
              e.${ident(e.employeeCode)} AS employee_code,
              e.${ident(e.firstName)} AS first_name,
              e.${ident(e.lastName)} AS last_name
       FROM ${ident(a.table)} a
       INNER JOIN ${ident(e.table)} e ON e.${ident(e.employeeId)} = a.${ident(a.attendanceEmployeeId)}
       ${whereSql}
       ORDER BY a.${ident(a.workDate)} DESC, a.${ident(a.attendanceId)} DESC LIMIT 1000`, params
    );
    // --- monitoring: break / lunch / time-out checks against the work schedule ---
    const today = localDate(), nowMin = localMinutes();
    const scansByDay = new Map();
    if (attendanceRecords.length) {
      const dates = attendanceRecords.map(r => ymd(r.work_date)).sort();
      const [scanRows] = await db.query(
        `SELECT employee_id, work_date, scan_type, scan_time FROM attendance_scan WHERE work_date BETWEEN ? AND ? ORDER BY scan_id`,
        [dates[0], dates[dates.length - 1]]
      );
      for (const r of scanRows) {
        const key = `${r.employee_id}|${ymd(r.work_date)}`;
        if (!scansByDay.has(key)) scansByDay.set(key, []);
        scansByDay.get(key).push(r);
      }
    }
    let records = attendanceRecords.map(r => {
      const date = ymd(r.work_date);
      const scans = scansByDay.get(`${r.employee_id}|${date}`) || [];
      const monitor = Sched.evaluateDay(scans, { isToday: date === today, nowMin });
      const t = {};
      scans.forEach(x => { if (!t[x.scan_type]) t[x.scan_type] = String(x.scan_time).slice(0, 5); });
      return { ...r, work_date: date, monitor, scanTimes: t };
    });
    const summary = {
      monitored: records.filter(r => r.monitor.monitored).length,
      flagged: records.filter(r => r.monitor.flags.some(f => f.level !== 'info')).length,
      abandoned: records.filter(r => r.monitor.abandoned).length,
      missedBreak: records.filter(r => r.monitor.flags.some(f => f.code === 'MISSED_AM_BREAK' || f.code === 'MISSED_PM_BREAK')).length,
      lunch: records.filter(r => r.monitor.flags.some(f => ['NO_LUNCH_OUT', 'LATE_LUNCH_OUT', 'NOT_BACK_FROM_LUNCH', 'LATE_LUNCH_IN'].includes(f.code))).length
    };
    filters.flagged = String(req.query.flagged || '') === '1' ? '1' : '';
    if (filters.flagged) records = records.filter(r => r.monitor.flags.some(f => f.level !== 'info'));
    const employees = await getEmployees(s);
    // Employee QR badges are displayed inside the Attendance page modal.
    // Department is joined from the existing Citrine Stone employee/department tables.
    const isBadgeManager = ['admin', 'hr'].includes(String(req.session.role || '').toLowerCase());
    const [badgeEmployees] = isBadgeManager ? await db.query(
      `SELECT e.employee_id, e.employee_code, e.first_name, e.last_name,
              COALESCE(d.name, 'Unassigned') AS department_name
       FROM employee e
       LEFT JOIN department d ON d.department_id = e.department_id
       WHERE COALESCE(e.status, 'Active') <> 'Archived'
       ORDER BY e.last_name, e.first_name`
    ) : [[]];
    return res.render('attendance/index', {
      title: 'Attendance Directory', user: req.session, attendanceRecords: records, employees, filters, summary, schedule: Sched.SCHEDULE, scanLabels: Sched.LABELS,
      badgeEmployees, isBadgeManager, error: null
    });
  } catch (err) {
    console.error('Attendance list error:', err);
    return renderError(res, err.message || 'Unable to load attendance records.');
  }
});

router.get('/scanner', requireAuth, (req, res) => {
  return res.render('attendance/scanner', { title: 'QR Attendance Scanner', user: req.session });
});

// QR scan or manual employee-code entry. What a scan means depends on the work schedule
// (lib/attendanceSchedule.js): time-in, AM break, lunch out, lunch in, PM break, time-out.
router.post('/scan', async (req, res) => {
  let conn;
  try {
    const code = parseEmployeeCode(req.body.employee_code || req.body.qr_code || req.body.code || req.body.text);
    if (!code) return res.status(400).json({ success: false, message: 'QR code or employee code is required.' });

    const s = await schema();
    const e = s.employee, a = s.attendance;
    const [employees] = await db.query(
      `SELECT ${ident(e.employeeId)} AS employee_id, ${ident(e.employeeCode)} AS employee_code,
              ${ident(e.firstName)} AS first_name, ${ident(e.lastName)} AS last_name
       FROM ${ident(e.table)} WHERE ${ident(e.employeeCode)} = ? LIMIT 1`, [code]
    );
    if (!employees.length) return res.status(404).json({ success: false, message: `No employee found for code "${code}".` });
    const employee = employees[0];
    const name = `${employee.first_name} ${employee.last_name}`.trim();
    const today = localDate(), nowTime = localTime(), nowMin = localMinutes();
    const uid = Number(req.session.userId || req.session.user_id || 0) || null;

    conn = await db.getConnection();
    await conn.beginTransaction();
    const [existing] = await conn.query(
      `SELECT ${ident(a.attendanceId)} AS attendance_id, ${ident(a.timeIn)} AS time_in, ${ident(a.timeOut)} AS time_out
       FROM ${ident(a.table)}
       WHERE ${ident(a.attendanceEmployeeId)} = ? AND ${ident(a.workDate)} = ? AND COALESCE(${ident(a.status)}, '') <> 'Archived'
       ORDER BY ${ident(a.attendanceId)} DESC LIMIT 1 FOR UPDATE`, [employee.employee_id, today]
    );
    const record = existing[0] || null;
    let [scans] = await conn.query(
      'SELECT scan_type, scan_time FROM attendance_scan WHERE employee_id = ? AND work_date = ? ORDER BY scan_id', [employee.employee_id, today]
    );

    // A row created by manual entry (or before scan logging existed) counts as the day's time-in / time-out.
    if (record && !scans.length) {
      if (record.time_in) await conn.query('INSERT IGNORE INTO attendance_scan (employee_id, work_date, scan_type, scan_time) VALUES (?, ?, ?, ?)', [employee.employee_id, today, 'IN', tv(record.time_in)]);
      if (record.time_out) await conn.query('INSERT IGNORE INTO attendance_scan (employee_id, work_date, scan_type, scan_time) VALUES (?, ?, ?, ?)', [employee.employee_id, today, 'OUT', tv(record.time_out)]);
      [scans] = await conn.query('SELECT scan_type, scan_time FROM attendance_scan WHERE employee_id = ? AND work_date = ? ORDER BY scan_id', [employee.employee_id, today]);
    }

    // Guard against the same badge being read twice in a row.
    const lastMin = scans.length ? Sched.minutesOf(scans[scans.length - 1].scan_time) : null;
    if (lastMin !== null && nowMin - lastMin < 1 && scans[scans.length - 1].scan_type !== 'OUT') {
      await conn.rollback();
      return res.status(409).json({ success: false, message: `${name} was just scanned. Please wait a moment before scanning again.` });
    }

    const next = Sched.nextScan(scans, nowMin);
    if (next.error) { await conn.rollback(); return res.status(409).json({ success: false, message: `${name}: ${next.error}` }); }

    await conn.query(
      'INSERT INTO attendance_scan (employee_id, work_date, scan_type, scan_time, is_late, scanned_by) VALUES (?, ?, ?, ?, ?, ?)',
      [employee.employee_id, today, next.type, nowTime, next.late ? 1 : 0, uid]
    );
    if (next.type === 'IN' && !record) {
      await conn.query(
        `INSERT INTO ${ident(a.table)} (${ident(a.attendanceEmployeeId)}, ${ident(a.workDate)}, ${ident(a.timeIn)}, ${ident(a.status)}) VALUES (?, ?, ?, ?)`,
        [employee.employee_id, today, nowTime, next.late ? 'Late' : 'Present']
      );
    } else if (next.type === 'OUT' && record) {
      await conn.query(`UPDATE ${ident(a.table)} SET ${ident(a.timeOut)} = ? WHERE ${ident(a.attendanceId)} = ?`, [nowTime, record.attendance_id]);
    }
    await conn.commit();

    const notes = [];
    if (next.type === 'IN' && next.late) notes.push('Late arrival (after 7:00 AM).');
    if (next.type === 'LUNCH_OUT' && next.late) notes.push('Lunch time-out should be before 12:00 PM.');
    if (next.type === 'LUNCH_IN' && next.late) notes.push('Lunch time-in was due before 1:00 PM.');
    if (next.type === 'OUT' && next.early) notes.push('Early time-out (before 4:00 PM).');
    return res.json({
      success: true, type: next.type, label: Sched.LABELS[next.type], time: nowTime, late: !!next.late, early: !!next.early,
      employee_name: name, employee_code: employee.employee_code,
      message: `${Sched.LABELS[next.type]} recorded successfully.${notes.length ? ' ' + notes.join(' ') : ''}`
    });
  } catch (err) {
    if (conn) { try { await conn.rollback(); } catch (_) {} }
    if (err && err.code === 'ER_DUP_ENTRY') return res.status(409).json({ success: false, message: 'That scan was already recorded.' });
    console.error('Attendance scan error:', err);
    return res.status(500).json({ success: false, message: `Could not record attendance. ${err.message || 'Check the database configuration and attendance columns.'}` });
  } finally {
    if (conn) conn.release();
  }
});

router.get('/add', requireAuth, async (req, res) => {
  try {
    const s = await schema();
    const employees = await getEmployees(s);
    return res.render('attendance/add', { title: 'Add Attendance', user: req.session, employees, error: null });
  } catch (err) {
    console.error('Attendance add page error:', err);
    return renderError(res, err.message || 'Unable to open the add attendance form.');
  }
});

router.post('/add', requireAuth, async (req, res) => {
  try {
    const s = await schema();
    const a = s.attendance;
    const employeeId = String(req.body.employee_id || '').trim();
    const workDate = String(req.body.work_date || '').trim();
    const timeIn = timeValue(req.body.time_in);
    const timeOut = timeValue(req.body.time_out);
    const status = String(req.body.status || 'Present').trim();
    if (!employeeId || !workDate) return res.status(400).send('Employee and work date are required.');
    const [employee] = await db.query(`SELECT ${ident(s.employee.employeeId)} AS employee_id FROM ${ident(s.employee.table)} WHERE ${ident(s.employee.employeeId)} = ? LIMIT 1`, [employeeId]);
    if (!employee.length) return res.status(400).send('Selected employee does not exist.');
    await db.query(
      `INSERT INTO ${ident(a.table)} (${ident(a.attendanceEmployeeId)}, ${ident(a.workDate)}, ${ident(a.timeIn)}, ${ident(a.timeOut)}, ${ident(a.status)}) VALUES (?, ?, ?, ?, ?)`,
      [employeeId, workDate, timeIn, timeOut, status]
    );
    return res.redirect('/attendance');
  } catch (err) {
    console.error('Create attendance error:', err);
    return renderError(res, err.message || 'Unable to save attendance.');
  }
});

// Attendance records are read-only for everyone (including Admin and HR): no editing after the fact.
router.get('/edit/:id', (req, res) => res.redirect(`/attendance/view/${encodeURIComponent(req.params.id)}`));
router.post('/edit/:id', (req, res) => res.status(403).send('Attendance records cannot be edited. They are view-only.'));

router.get('/view/:id', async (req, res) => {
  try {
    const s = await schema();
    const a = s.attendance, e = s.employee;
    const [rows] = await db.query(
      `SELECT a.${ident(a.attendanceId)} AS attendance_id, a.${ident(a.attendanceEmployeeId)} AS employee_id,
              a.${ident(a.workDate)} AS work_date, a.${ident(a.timeIn)} AS time_in,
              a.${ident(a.timeOut)} AS time_out, a.${ident(a.status)} AS status,
              e.${ident(e.employeeCode)} AS employee_code, e.${ident(e.firstName)} AS first_name, e.${ident(e.lastName)} AS last_name
       FROM ${ident(a.table)} a JOIN ${ident(e.table)} e ON e.${ident(e.employeeId)} = a.${ident(a.attendanceEmployeeId)}
       WHERE a.${ident(a.attendanceId)} = ? LIMIT 1`, [req.params.id]
    );
    if (!rows.length) return res.status(404).send('Attendance record not found.');
    const record = { ...rows[0], work_date: ymd(rows[0].work_date) };
    const [scans] = await db.query(
      'SELECT scan_type, scan_time, is_late FROM attendance_scan WHERE employee_id = ? AND work_date = ? ORDER BY scan_id', [record.employee_id, record.work_date]
    );
    const monitor = Sched.evaluateDay(scans, { isToday: record.work_date === localDate(), nowMin: localMinutes() });
    return res.render('attendance/view', { title: 'View Attendance', user: req.session, record, scans, monitor, scanLabels: Sched.LABELS });
  } catch (err) {
    console.error('View attendance error:', err);
    return renderError(res, err.message || 'Unable to load attendance record.');
  }
});

router.post('/archive/:id', requireAuth, async (req, res) => {
  try {
    const s = await schema();
    const a = s.attendance, e = s.employee;
    const [rows] = await db.query(
      `SELECT a.*, e.${ident(e.employeeCode)} AS employee_code, e.${ident(e.firstName)} AS first_name, e.${ident(e.lastName)} AS last_name
       FROM ${ident(a.table)} a JOIN ${ident(e.table)} e ON e.${ident(e.employeeId)} = a.${ident(a.attendanceEmployeeId)}
       WHERE a.${ident(a.attendanceId)} = ? LIMIT 1`, [req.params.id]);
    if (!rows.length) return res.status(404).send('Attendance record not found.');
    const row = rows[0];
    if (String(row.status || '').toLowerCase() === 'archived') return res.redirect('/archive');
    await archiveRecord({ sourceTable: a.table, sourceId: row[a.attendanceId], label: `Attendance: ${row.last_name}, ${row.first_name} — ${row[a.workDate]}`, data: row, module: 'Attendance', req });
    await db.query(`UPDATE ${ident(a.table)} SET ${ident(a.status)} = 'Archived' WHERE ${ident(a.attendanceId)} = ?`, [req.params.id]);
    return res.redirect('/attendance');
  } catch (err) {
    console.error('Archive attendance error:', err);
    return renderError(res, err.message || 'Unable to archive attendance.');
  }
});

module.exports = router;
