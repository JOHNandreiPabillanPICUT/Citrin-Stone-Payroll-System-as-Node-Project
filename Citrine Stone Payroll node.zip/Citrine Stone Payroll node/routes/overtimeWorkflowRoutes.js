'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const qid = s => '`' + String(s).replace(/`/g, '``') + '`';

const roleOf = req => String(req.session?.role || req.session?.role_name || req.session?.user?.role || '').trim().toLowerCase();
const uidOf = req => Number(req.session?.userId || req.session?.user_id || req.session?.user?.user_id) || null;
const empOf = req => Number(req.session?.employee_id || req.session?.employeeId || req.session?.user?.employee_id) || null;
const dateOk = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) && !Number.isNaN(Date.parse(`${v}T00:00:00`));
const mins = v => { const m=/^(\d{2}):(\d{2})(?::\d{2})?$/.exec(String(v||'')); return !m||+m[1]>23||+m[2]>59?null:+m[1]*60 + +m[2]; };
const hours = (a,b) => { const s=mins(a),e=mins(b); if(s===null||e===null)return null;let d=e-s;if(d<=0)d+=1440;return Math.round(d/60*100)/100; };
const deny = (res) => res.status(403).send('You do not have permission to access this overtime workflow.');
const roleGuard = roles => (req,res,next) => roles.includes(roleOf(req)) ? next() : deny(res);

async function loadPageData(req) {
  const role=roleOf(req), uid=uidOf(req);
  let departments=[], employees=[], requests=[];
  if(role==='hr') {
    [departments]=await db.query('SELECT department_id,name FROM department WHERE hr_user_id=? ORDER BY name',[uid]);
    [requests]=await db.query(`SELECT r.*,d.name department_name, u.username created_by_name
      FROM overtime_department_request r JOIN department d ON d.department_id=r.department_id
      LEFT JOIN users u ON u.user_id=r.created_by WHERE d.hr_user_id=? ORDER BY r.request_id DESC`,[uid]);
  } else if(role==='supervisor') {
    [departments]=await db.query('SELECT department_id,name FROM department WHERE supervisor_user_id=? ORDER BY name',[uid]);
    [requests]=await db.query(`SELECT r.*,d.name department_name,u.username created_by_name
      FROM overtime_department_request r JOIN department d ON d.department_id=r.department_id
      LEFT JOIN users u ON u.user_id=r.created_by WHERE d.supervisor_user_id=? ORDER BY r.request_id DESC`,[uid]);
    if(departments.length) {
      const ids=departments.map(d=>Number(d.department_id)), marks=ids.map(()=>'?').join(',');
      [employees]=await db.query(`SELECT employee_id,first_name,last_name,department_id FROM employee
        WHERE department_id IN (${marks}) AND COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated')
        ORDER BY last_name,first_name`,ids);
    }
  } else if(role==='admin'||role==='administrator') {
    [departments]=await db.query('SELECT department_id,name FROM department ORDER BY name');
    [requests]=await db.query(`SELECT r.*,d.name department_name,u.username created_by_name
      FROM overtime_department_request r JOIN department d ON d.department_id=r.department_id
      LEFT JOIN users u ON u.user_id=r.created_by ORDER BY r.request_id DESC`);
    [employees]=await db.query(`SELECT employee_id,first_name,last_name,department_id FROM employee
      WHERE COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated') ORDER BY last_name,first_name`);
  }
  for(const r of requests) {
    const [a]=await db.query(`SELECT a.assignment_id,a.employee_id,a.seen_at,e.first_name,e.last_name
      FROM overtime_department_assignment a JOIN employee e ON e.employee_id=a.employee_id
      WHERE a.request_id=? ORDER BY e.last_name,e.first_name`,[r.request_id]);
    r.assignments=a;
    r.acknowledged_count=a.filter(x=>x.seen_at).length;
  }
  return {role,departments,employees,requests,user:req.session.user||req.session};
}
router.get('/',isAuth,roleGuard(['hr','supervisor','admin','administrator']),async(req,res)=>{
  try { res.render('overtime/workflow',{...(await loadPageData(req)),notice:req.query.notice||null,error:null}); }
  catch(e){console.error('Overtime workflow page:',e);res.status(500).send('Could not load department overtime workflow. Check Node.js terminal.');}
});

// HR creates a department-wide overtime need, specifying how many staff are required.
router.post('/create',isAuth,roleGuard(['hr','admin','administrator']),async(req,res)=>{
  try {
    const role=roleOf(req),uid=uidOf(req),departmentId=Number(req.body.department_id);
    const workDate=String(req.body.work_date||''),start=String(req.body.start_time||''),end=String(req.body.end_time||'');
    const reason=String(req.body.reason||'').trim(),slots=Number(req.body.slots_needed),total=hours(start,end);
    if(!Number.isInteger(departmentId)||departmentId<1||!dateOk(workDate)||total===null||total<.25||total>16||!Number.isInteger(slots)||slots<1||slots>100||!reason||reason.length>2000)
      return res.status(400).send('Invalid request. Check department, date, time range, required slots (1–100), and reason.');
    const [dept]= role==='hr'
      ? await db.query('SELECT department_id FROM department WHERE department_id=? AND hr_user_id=?',[departmentId,uid])
      : await db.query('SELECT department_id FROM department WHERE department_id=?',[departmentId]);
    if(!dept.length)return deny(res);
    await db.query(`INSERT INTO overtime_department_request
      (department_id,work_date,start_time,end_time,total_hours,reason,slots_needed,status,created_by)
      VALUES (?,?,?,?,?,?,?,'pending_assignment',?)`,
      [departmentId,workDate,start,end,total,reason,slots,uid]);
    res.redirect('/overtime/workflow?notice='+encodeURIComponent('Department overtime request created.'));
  }catch(e){console.error('Create department OT:',e);res.status(500).send('Unable to create department overtime request.');}
});

// Supervisor assigns eligible employees from their own department, up to slots_needed.
router.post('/:id/assign',isAuth,roleGuard(['supervisor','admin','administrator']),async(req,res)=>{
  const id=Number(req.params.id),uid=uidOf(req),role=roleOf(req);
  const raw=req.body.employee_ids;
  const selected=[...new Set((Array.isArray(raw)?raw:[raw]).map(Number).filter(n=>Number.isInteger(n)&&n>0))];
  try{
    const [rr]=await db.query('SELECT * FROM overtime_department_request WHERE request_id=? LIMIT 1',[id]);
    if(!rr.length)return res.status(404).send('Department overtime request not found.');
    const r=rr[0];
    const [d]=role==='supervisor'
      ? await db.query('SELECT department_id FROM department WHERE department_id=? AND supervisor_user_id=?',[r.department_id,uid])
      : await db.query('SELECT department_id FROM department WHERE department_id=?',[r.department_id]);
    if(!d.length)return deny(res);
    if(r.status!=='pending_assignment'&&r.status!=='assigned')return res.status(409).send('This request is no longer open for assignment.');
    if(selected.length!==Number(r.slots_needed))return res.status(400).send(`Select exactly ${r.slots_needed} employees for this request.`);
    const marks=selected.map(()=>'?').join(',');
    const [eligible]=await db.query(`SELECT employee_id FROM employee WHERE department_id=? AND employee_id IN (${marks})
      AND COALESCE(status,'Active') NOT IN ('Archived','Inactive','Terminated')`,[r.department_id,...selected]);
    if(eligible.length!==selected.length)return res.status(400).send('Every selected employee must be active and belong to the request department.');
    const conn=await db.getConnection();
    try{
      await conn.beginTransaction();
      await conn.query('DELETE FROM overtime_department_assignment WHERE request_id=?',[id]);
      for(const empId of selected) await conn.query('INSERT INTO overtime_department_assignment(request_id,employee_id,assigned_by) VALUES(?,?,?)',[id,empId,uid]);
      await conn.query(`UPDATE overtime_department_request SET status='assigned',assigned_by=?,assigned_at=NOW() WHERE request_id=?`,[uid,id]);
      await conn.commit();
    }catch(e){await conn.rollback();throw e;}finally{conn.release();}
    res.redirect('/overtime/workflow?notice='+encodeURIComponent('Employees assigned. They must acknowledge in My Overtime.'));
  }catch(e){console.error('Assign OT:',e);res.status(500).send(e.message||'Unable to assign employees.');}
});

// Supervisor confirms only after every assigned employee has acknowledged.
router.post('/:id/confirm',isAuth,roleGuard(['supervisor','admin','administrator']),async(req,res)=>{
  const id=Number(req.params.id),uid=uidOf(req),role=roleOf(req);
  try{
    const [rr]=await db.query('SELECT * FROM overtime_department_request WHERE request_id=? LIMIT 1',[id]);
    if(!rr.length)return res.status(404).send('Request not found.');
    const r=rr[0];
    const [d]=role==='supervisor'?await db.query('SELECT department_id FROM department WHERE department_id=? AND supervisor_user_id=?',[r.department_id,uid]):await db.query('SELECT department_id FROM department WHERE department_id=?',[r.department_id]);
    if(!d.length)return deny(res);
    if(r.status!=='assigned')return res.status(409).send('This request must be assigned before confirmation.');
    const [counts]=await db.query(`SELECT COUNT(*) total, SUM(seen_at IS NOT NULL) acknowledged FROM overtime_department_assignment WHERE request_id=?`,[id]);
    if(!Number(counts[0].total)||Number(counts[0].total)!==Number(r.slots_needed)||Number(counts[0].acknowledged)!==Number(counts[0].total))
      return res.status(409).send('Cannot confirm: all assigned employees must acknowledge first.');
    const oc=await columns('overtime_request');
    const hourCol=oc.has('total_hours')?'total_hours':(oc.has('hours')?'hours':null);
    if(!hourCol)return res.status(500).send('overtime_request has no total_hours/hours field.');
    const conn=await db.getConnection();
    try{
      await conn.beginTransaction();
      const [as]=await conn.query('SELECT employee_id FROM overtime_department_assignment WHERE request_id=? FOR UPDATE',[id]);
      for(const a of as){
        const fields=['employee_id','department_id','work_date','start_time','end_time',hourCol,'reason','status','created_by','payroll_status'];
        const vals=[a.employee_id,r.department_id,r.work_date,r.start_time,r.end_time,r.total_hours,r.reason,'Approved',r.created_by,'Not Processed'];
        const cols=fields.filter(f=>oc.has(f));
        await conn.query(`INSERT INTO overtime_request (${cols.map(qid).join(',')}) VALUES (${cols.map(()=>'?').join(',')})`,cols.map(f=>vals[fields.indexOf(f)]));
      }
      await conn.query(`UPDATE overtime_department_request SET status='confirmed',confirmed_by=?,confirmed_at=NOW(),payroll_status='Not Processed' WHERE request_id=? AND status='assigned'`,[uid,id]);
      await conn.commit();
    }catch(e){await conn.rollback();throw e;}finally{conn.release();}
    res.redirect('/overtime/workflow?notice='+encodeURIComponent('Confirmed. Approved overtime entries were added for payroll.'));
  }catch(e){console.error('Confirm OT:',e);res.status(500).send(e.message||'Unable to confirm overtime request.');}
});
async function columns(table){const [rows]=await db.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?',[table]);return new Set(rows.map(x=>x.COLUMN_NAME));}

// Supervisor rejects if unable to fill the required slots.
router.post('/:id/reject',isAuth,roleGuard(['supervisor','admin','administrator']),async(req,res)=>{
  const id=Number(req.params.id),uid=uidOf(req),role=roleOf(req),reason=String(req.body.reason||'').trim();
  if(!reason||reason.length>2000)return res.status(400).send('Enter a rejection reason (up to 2000 characters).');
  try{
    const [rr]=await db.query('SELECT * FROM overtime_department_request WHERE request_id=? LIMIT 1',[id]);
    if(!rr.length)return res.status(404).send('Request not found.');
    const r=rr[0];
    const [d]=role==='supervisor'?await db.query('SELECT department_id FROM department WHERE department_id=? AND supervisor_user_id=?',[r.department_id,uid]):await db.query('SELECT department_id FROM department WHERE department_id=?',[r.department_id]);
    if(!d.length)return deny(res);
    if(!['pending_assignment','assigned'].includes(r.status))return res.status(409).send('Request already completed.');
    await db.query(`UPDATE overtime_department_request SET status='rejected',rejected_by=?,rejected_at=NOW(),rejection_reason=? WHERE request_id=?`,[uid,reason,id]);
    res.redirect('/overtime/workflow?notice='+encodeURIComponent('Department overtime request rejected.'));
  }catch(e){console.error('Reject OT:',e);res.status(500).send('Unable to reject request.');}
});
module.exports=router;
