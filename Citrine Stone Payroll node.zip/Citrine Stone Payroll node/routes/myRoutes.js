'use strict';
/*
 * Employee self-service portal (/my/*). Every query is scoped to the employee
 * linked to the logged-in user, so an employee can only see/submit their own data.
 */
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const { ensureMiddleware, stageLabel } = require('../lib/approvalFlow');
const C = require('../lib/payrollCalc');
const H = require('../lib/payrollHelpers');

const qid = s => '`' + String(s).replace(/`/g, '``') + '`';
const pick = (set, names) => names.find(n => set.has(n)) || null;
async function columnsOf(table) {
  const [rows] = await db.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [table]);
  return new Set(rows.map(r => r.COLUMN_NAME));
}
const dateOk = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) && !Number.isNaN(Date.parse(`${v}T00:00:00`));
const timeMinutes = v => { const m = /^(\d{2}):(\d{2})(?::\d{2})?$/.exec(String(v || '')); return !m || +m[1] > 23 || +m[2] > 59 ? null : +m[1] * 60 + +m[2]; };
function hoursBetween(start, end) { const s = timeMinutes(start), e = timeMinutes(end); if (s === null || e === null) return null; let d = e - s; if (d <= 0) d += 1440; return Math.round(d / 60 * 100) / 100; }
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

router.use(requireAuth);
router.use(ensureMiddleware(db));

// Resolve the employee record linked to this login.
router.use(async (req, res, next) => {
  try {
    let empId = Number(req.session.employee_id) || null;
    if (!empId) {
      const [r] = await db.query('SELECT employee_id FROM users WHERE user_id = ? LIMIT 1', [req.session.userId || req.session.user_id]);
      empId = Number(r[0] && r[0].employee_id) || null;
      if (empId) req.session.employee_id = empId;
    }
    let me = null;
    if (empId) {
      const [r] = await db.query(`SELECT e.employee_id, e.employee_code, e.first_name, e.last_name, e.department_id, d.name AS department_name
        FROM employee e LEFT JOIN department d ON d.department_id = e.department_id WHERE e.employee_id = ? LIMIT 1`, [empId]);
      me = r[0] || null;
    }
    res.locals.me = me;
    res.locals.user = req.session;
    res.locals.today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    res.locals.meName = me ? [me.first_name, me.last_name].filter(Boolean).join(' ') : (req.session.username || 'Employee');
    if (!me) return res.status(200).render('my/unlinked', { heading: 'My Account', path: req.path });
    next();
  } catch (err) { next(err); }
});

const fail = (res, view, status, data) => res.status(status).render(view, data);

router.get('/', (req, res) => res.redirect('/my/payslip'));

// ---- My Payslip -----------------------------------------------------------
router.get('/payslip', async (req, res, next) => {
  try {
    let payslips = [];
    try {
      [payslips] = await db.query(`SELECT p.payroll_id AS id, p.gross_pay, p.net_pay, pr.period_start, pr.period_end
        FROM payroll p JOIN payroll_run pr ON p.payroll_run_id = pr.payroll_run_id
        WHERE p.employee_id = ? ORDER BY p.payroll_id DESC`, [res.locals.me.employee_id]);
    } catch (e) { console.warn('My payslips unavailable:', e.message); }
    res.render('my/payslip', { heading: 'My Payslip', path: '/my/payslip', payslips });
  } catch (err) { next(err); }
});

router.get('/payslip/:id', async (req, res, next) => {
  try {
    const [rows] = await db.query(`SELECT p.payroll_id AS id, p.gross_pay, p.net_pay, (p.gross_pay - p.net_pay) AS deductions, pr.period_start, pr.period_end, bs.rate_value
      FROM payroll p JOIN payroll_run pr ON p.payroll_run_id = pr.payroll_run_id
      LEFT JOIN basic_salary bs ON bs.employee_id = p.employee_id
      WHERE p.payroll_id = ? AND p.employee_id = ? LIMIT 1`, [Number(req.params.id) || 0, res.locals.me.employee_id]);
    if (!rows.length) return res.status(404).send('Payslip not found.');

    /* itemised deductions (same calculation as the admin payslip) so the printed payslip shows where the deductions come from */
    let detail = null;
    try {
      const empId = res.locals.me.employee_id;
      const [runRows] = await db.query(`SELECT p.*, pr.period_start, pr.period_end, pr.pay_frequency, pr.pay_factor, pr.pay_date, pr.cutoff_date,
          pr.coverage_end, pr.status AS payroll_status
        FROM payroll p JOIN payroll_run pr ON p.payroll_run_id = pr.payroll_run_id
        WHERE p.payroll_id = ? AND p.employee_id = ? LIMIT 1`, [Number(req.params.id) || 0, empId]);
      const ps = runRows[0];
      if (ps) {
        const calc = await C.calculateEmployeePayroll(db, Number(empId), ps);
        let loanLines = calc.loan_lines || [];
        if (ps.payroll_status === 'Posted') {
          try {
            if ((await H.tableExists(db, 'loan_repayment')) && (await H.tableExists(db, 'loan_request')) && (await H.tableExists(db, 'loan_schedule'))) {
              const [posted] = await db.query(`SELECT lr.loan_type, r.amount, s.installment_no, s.due_date
                FROM loan_repayment r JOIN loan_request lr ON lr.loan_id = r.loan_id JOIN loan_schedule s ON s.schedule_id = r.schedule_id
                WHERE r.payroll_run_id = ? AND r.employee_id = ? ORDER BY lr.loan_type, s.installment_no`, [Number(ps.payroll_run_id), Number(empId)]);
              loanLines = posted;
            }
          } catch (e) { /* keep the calculated loan lines */ }
        }
        const timing = C.deductionTiming(ps);
        detail = {
          basic_pay: ps.basic_pay, overtime_pay: ps.overtime_pay, holiday_pay: ps.holiday_pay,
          sss: calc.sss, philhealth: calc.philhealth, pagibig: calc.pagibig, bir: calc.bir, government: calc.government_deductions,
          absence: calc.absence_deduction, unpaid_leave: calc.unpaid_leave_deduction, tardiness: calc.late_deduction,
          undertime: calc.undertime_deduction, attendance: calc.attendance_deductions,
          loan_lines: loanLines, loans: loanLines.reduce((t, l) => t + (Number(l.amount != null ? l.amount : l.amount_due) || 0), 0),
          company_lines: calc.company_lines || [], company: calc.company_deductions,
          cutoff: timing.cutoff,
        };
      }
    } catch (e) { console.warn('My payslip breakdown unavailable:', e.message); }

    res.render('my/payslip_view', { heading: 'Payslip', path: '/my/payslip', payslip: rows[0], detail });
  } catch (err) { next(err); }
});

// ---- My QR Code -----------------------------------------------------------
router.get('/qr', (req, res) => res.render('my/qr', { heading: 'My QR Code', path: '/my/qr' }));

// ---- My Attendance --------------------------------------------------------
router.get('/attendance', async (req, res, next) => {
  try {
    let records = [], note = null;
    const [tbls] = await db.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('attendance','attendances')");
    if (!tbls.length) note = 'Attendance records are not available yet.';
    else {
      const table = tbls[0].TABLE_NAME, c = await columnsOf(table);
      const key = pick(c, ['employee_id', 'emp_id']), date = pick(c, ['work_date', 'date', 'attendance_date']);
      const tin = pick(c, ['time_in', 'timein', 'clock_in']), tout = pick(c, ['time_out', 'timeout', 'clock_out']), st = pick(c, ['status', 'attendance_status']);
      if (!key || !date) note = 'Attendance records are not available yet.';
      else [records] = await db.query(`SELECT ${qid(date)} AS work_date, ${tin ? qid(tin) : 'NULL'} AS time_in, ${tout ? qid(tout) : 'NULL'} AS time_out, ${st ? qid(st) : "'Recorded'"} AS status
        FROM ${qid(table)} WHERE ${qid(key)} = ? ORDER BY ${qid(date)} DESC LIMIT 90`, [res.locals.me.employee_id]);
    }
    res.render('my/attendance', { heading: 'My Attendance', path: '/my/attendance', records, note });
  } catch (err) { next(err); }
});

// ---- Leave Requests -------------------------------------------------------
const LEAVE_TYPES = ['Sick', 'Vacation', 'Emergency', 'Maternity/Paternity', 'Other'];
async function leaveData(me) {
  const [rows] = await db.query('SELECT *, leave_id AS id FROM leave_request WHERE employee_id = ? ORDER BY leave_id DESC', [me.employee_id]);
  const leaves = rows.map(r => ({ ...r, stage: stageLabel(r) }));
  return { leaves, leaveTypes: LEAVE_TYPES, today: todayStr() };
}
router.get('/leave', async (req, res, next) => {
  try { res.render('my/leave', { heading: 'Leave Requests', path: '/my/leave', ...(await leaveData(res.locals.me)), error: null, form: {}, submitted: req.query.submitted === '1' }); } catch (err) { next(err); }
});
router.post('/leave', async (req, res, next) => {
  try {
    const f = { leave_type: String(req.body.leave_type || ''), start_date: String(req.body.start_date || ''), end_date: String(req.body.end_date || ''), reason: String(req.body.reason || '').trim() };
    let error = null;
    if (!LEAVE_TYPES.includes(f.leave_type)) error = 'Choose a leave type.';
    else if (!dateOk(f.start_date) || !dateOk(f.end_date)) error = 'Enter valid start and end dates.';
    else if (f.end_date < f.start_date) error = 'End date cannot be before the start date.';
    else if (f.start_date < new Date(Date.now() + 7 * 86400000).toISOString().slice(0,10)) error = 'Leave applications must be submitted at least 7 days before the start date.';
    else if (!f.reason || f.reason.length > 1000) error = 'Enter a reason (up to 1000 characters).';
    if (error) return fail(res, 'my/leave', 400, { heading: 'Leave Requests', path: '/my/leave', ...(await leaveData(res.locals.me)), error, form: f, submitted: false });
    const [conflict] = await db.query("SELECT leave_id FROM leave_request WHERE employee_id=? AND status IN ('Pending','Approved') AND start_date<=? AND end_date>=? LIMIT 1", [res.locals.me.employee_id, f.end_date, f.start_date]);
    if (conflict.length) return fail(res, 'my/leave', 409, { heading: 'Leave Requests', path: '/my/leave', ...(await leaveData(res.locals.me)), error: 'You already have a pending or approved leave request that overlaps these dates.', form: f, submitted: false });
    const [leaveCols] = await db.query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='leave_request'");
    const available = new Set(leaveCols.map(x => x.COLUMN_NAME));
    const fields = ['employee_id','start_date','end_date','leave_type','reason','status'];
    const values = [res.locals.me.employee_id,f.start_date,f.end_date,f.leave_type,f.reason,'Pending'];
    if (available.has('date_submitted')) { fields.push('date_submitted'); values.push(todayStr()); }
    else if (available.has('created_at')) { fields.push('created_at'); values.push(new Date()); }
    await db.query(`INSERT INTO leave_request (${fields.map(x=>'`'+x+'`').join(',')}) VALUES (${fields.map(()=>'?').join(',')})`, values);
    res.redirect('/my/leave?submitted=1');
  } catch (err) { next(err); }
});

// ---- My Overtime ----------------------------------------------------------
async function overtimeData(me) {
  const c = await columnsOf('overtime_request');
  if (!c.size) return { enabled: false, requests: [], today: todayStr() };
  const hourCol = pick(c, ['total_hours', 'hours']);
  const [rows] = await db.query('SELECT * FROM overtime_request WHERE employee_id = ? ORDER BY overtime_id DESC', [me.employee_id]);
  return { enabled: true, today: todayStr(), requests: rows.map(r => ({ id: r.overtime_id, work_date: r.work_date, start_time: r.start_time, end_time: r.end_time, hours: hourCol ? r[hourCol] : null, reason: r.reason, status: r.status, remarks: r.remarks || '', stage: stageLabel(r), supervisor_remarks: r.supervisor_remarks || '' })) };
}
router.get('/overtime', async (req, res, next) => {
  try { res.render('my/overtime', { heading: 'My Overtime', path: '/my/overtime', ...(await overtimeData(res.locals.me)) }); } catch (err) { next(err); }
});
// Employees cannot file overtime. Overtime is initiated by Admin/HR/Supervisor from /overtime;
// this page is read-only so employees can only track the requests filed for them.

// ---- Loans & Cash Advances ------------------------------------------------
// Same tables, limits and approval flow as the staff page (/loans); an employee only ever files for themselves.
const loans = require('../lib/loans');
const loanPolicy = require('../lib/loanPolicy');
async function loanData(me) {
  await loans.ensureSchema(db);
  const emp = await loans.getEmployee(db, me.employee_id);
  const [requests, limits] = await Promise.all([loans.listForEmployee(db, me.employee_id), emp ? loans.limitsFor(db, emp) : null]);
  return { requests, limits, loanTypes: loanPolicy.TYPES, maxInstallments: loanPolicy.MAX_INSTALLMENTS };
}
router.get('/loans', async (req, res, next) => {
  try { res.render('my/loans', { heading: 'Loans & Cash Advances', path: '/my/loans', ...(await loanData(res.locals.me)), error: null, form: {}, submitted: req.query.submitted === '1' }); } catch (err) { next(err); }
});
router.post('/loans', async (req, res, next) => {
  try {
    const f = { request_type: String(req.body.request_type || ''), amount: String(req.body.amount || '').replace(/,/g, ''), installments: String(req.body.installments || ''), purpose: String(req.body.purpose || '').trim() };
    await loans.ensureSchema(db);
    const out = await loans.createRequest(db, { employeeId: res.locals.me.employee_id, type: f.request_type, amount: f.amount, installments: f.installments, purpose: f.purpose, filedBy: Number(req.session.userId || req.session.user_id) || null });
    if (!out.ok) return fail(res, 'my/loans', 422, { heading: 'Loans & Cash Advances', path: '/my/loans', ...(await loanData(res.locals.me)), error: out.errors.join(' '), form: f, submitted: false });
    res.redirect('/my/loans?submitted=1');
  } catch (err) { next(err); }
});

// ---- My Employment (probationary / regular status) -------------------------
const Emp = require('../lib/employment');
const Transfers = require('../lib/transfers');
router.get('/employment', async (req, res, next) => {
  try {
    await Emp.syncRegularization();
    const [r] = await db.query(`SELECT e.date_hired, e.status, d.name AS department_name FROM employee e LEFT JOIN department d ON d.department_id = e.department_id WHERE e.employee_id = ? LIMIT 1`, [res.locals.me.employee_id]);
    const row = r[0] || {};
    res.render('my/employment', { heading: 'My Employment', path: '/my/employment', emp: Emp.describeEmployment(row), department: row.department_name || 'Unassigned', accountStatus: row.status || 'Active', statusBadge: Emp.statusBadge });
  } catch (err) { next(err); }
});

// ---- Department transfer request -----------------------------------------------
async function transferPage(res, extra = {}) {
  const me = res.locals.me;
  const [departments] = await db.query('SELECT department_id, name FROM department WHERE department_id <> ? ORDER BY name', [Number(me.department_id) || 0]);
  const requests = await Transfers.listForEmployee(me.employee_id);
  return { heading: 'Transfer Request', path: '/my/transfer', departments, requests, open: requests.find((t) => Transfers.OPEN.includes(t.status)) || null, error: null, notice: null, form: {}, ...extra };
}
router.get('/transfer', async (req, res, next) => {
  try { res.render('my/transfer', await transferPage(res, { notice: req.query.submitted === '1' ? 'Transfer request submitted. Your supervisor will review it first, then HR.' : (req.query.cancelled === '1' ? 'Transfer request cancelled.' : null) })); } catch (err) { next(err); }
});
router.post('/transfer', async (req, res, next) => {
  try {
    const out = await Transfers.createRequest(res.locals.me.employee_id, req.body.to_department_id, req.body.reason);
    if (out.error) return res.status(400).render('my/transfer', await transferPage(res, { error: out.error, form: { to_department_id: req.body.to_department_id, reason: req.body.reason } }));
    await require('../lib/audit').logAudit(req, 'Department Transfer', `${res.locals.meName} requested a transfer from ${out.fromName} to ${out.toName} (request #${out.id})`, 'Request');
    res.redirect('/my/transfer?submitted=1');
  } catch (err) { next(err); }
});
router.post('/transfer/cancel/:id', async (req, res, next) => {
  try {
    const ok = await Transfers.cancelRequest(res.locals.me.employee_id, parseInt(req.params.id, 10));
    if (ok) await require('../lib/audit').logAudit(req, 'Department Transfer', `${res.locals.meName} cancelled transfer request #${req.params.id}`, 'Cancel');
    res.redirect('/my/transfer' + (ok ? '?cancelled=1' : ''));
  } catch (err) { next(err); }
});

module.exports = router;