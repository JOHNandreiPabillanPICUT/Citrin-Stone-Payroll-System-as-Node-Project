'use strict';
/*
 * Departments (list, add, edit page, archive). HR / Timekeeper and Supervisor are USER ACCOUNTS
 * (department.hr_user_id / supervisor_user_id), the same columns payroll, leave and the PHP system use.
 * hr_employee_id / supervisor_employee_id are kept in sync for the modules that still read them.
 */
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const { archiveRecord } = require('./archiveStore');
const { isPreset, seedPresetDepartments } = require('../lib/departmentPresets');

let schemaReady;
async function ensureSchema() {
  if (schemaReady) return schemaReady;
  schemaReady = (async () => {
    const [cols] = await db.query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'department'");
    const have = new Set(cols.map((c) => c.COLUMN_NAME));
    for (const c of ['hr_user_id', 'supervisor_user_id', 'hr_employee_id', 'supervisor_employee_id']) {
      if (!have.has(c)) await db.query(`ALTER TABLE department ADD COLUMN ${c} INT NULL`);
    }
    await seedPresetDepartments(db); // the prefixed departments (Finished Goods, Corn Mill, ...)
  })();
  try { await schemaReady; } catch (e) { schemaReady = null; throw e; }
}

const ACTIVE_EMP = "COALESCE(e.status, 'Active') <> 'Archived'";

/* Active accounts of one role, linked to an active employee, not already running ANOTHER department */
async function assignableUsers(roleName, col, excludeDepartmentId) {
  const [rows] = await db.query(
    `SELECT u.user_id, u.username, u.employee_id, e.first_name, e.last_name
     FROM users u
     JOIN roles r ON r.role_id = u.role_id
     JOIN employee e ON e.employee_id = u.employee_id
     WHERE LOWER(r.role_name) = LOWER(?) AND u.status = 'Active' AND e.status = 'Active'
       AND NOT EXISTS (SELECT 1 FROM department d WHERE d.${col} = u.user_id AND d.department_id <> ?)
     ORDER BY e.last_name, e.first_name, u.username`, [roleName, Number(excludeDepartmentId || 0)]);
  return rows.map((u) => ({ ...u, label: `${u.last_name || ''}, ${u.first_name || ''} (@${u.username})` }));
}
const hrOptions = (deptId) => assignableUsers('HR', 'hr_user_id', deptId);
const supervisorOptions = (deptId) => assignableUsers('Supervisor', 'supervisor_user_id', deptId);

async function validate({ name, hrUserId, supervisorUserId, departmentId }) {
  const errors = [];
  if (!name) errors.push('Department name is required.');
  if (name.length > 100) errors.push('Department name must not exceed 100 characters.');
  if (errors.length) return errors;

  const [[dup]] = await db.query('SELECT COUNT(*) AS n FROM department WHERE name = ? AND department_id <> ?', [name, departmentId]);
  if (Number(dup.n) > 0) errors.push(departmentId ? 'Another department already uses this name.' : 'This department already exists.');

  const check = async (userId, roleName, col, noun) => {
    if (userId <= 0) return;
    const [[ok]] = await db.query(
      `SELECT COUNT(*) AS n FROM users u JOIN roles r ON r.role_id = u.role_id JOIN employee e ON e.employee_id = u.employee_id
       WHERE u.user_id = ? AND LOWER(r.role_name) = LOWER(?) AND u.status = 'Active' AND e.status = 'Active'`, [userId, roleName]);
    if (Number(ok.n) !== 1) { errors.push(`Select an active ${noun} account linked to an active employee.`); return; }
    const [[taken]] = await db.query(`SELECT COUNT(*) AS n FROM department WHERE ${col} = ? AND department_id <> ?`, [userId, departmentId]);
    if (Number(taken.n) > 0) errors.push(`That ${noun} is already assigned to another department.`);
  };
  await check(hrUserId, 'HR', 'hr_user_id', 'HR / Timekeeper');
  await check(supervisorUserId, 'Supervisor', 'supervisor_user_id', 'Supervisor');
  if (hrUserId > 0 && hrUserId === supervisorUserId) errors.push('The HR / Timekeeper and the Supervisor must be two different accounts.');
  return errors;
}

const formVars = (req) => ({
  name: String(req.body.name || '').trim(),
  hrUserId: Number(req.body.hr_user_id || 0) || 0,
  supervisorUserId: Number(req.body.supervisor_user_id || 0) || 0,
});

async function employeeIdOf(userId) {
  if (!(userId > 0)) return null;
  const [r] = await db.query('SELECT employee_id FROM users WHERE user_id = ? LIMIT 1', [userId]);
  return r[0] ? r[0].employee_id : null;
}

async function listPageData(extra = {}) {
  await ensureSchema();
  const [departments] = await db.query(`
    SELECT d.department_id AS id, d.name, d.hr_user_id, d.supervisor_user_id,
           TRIM(CONCAT_WS(' ', hr_emp.first_name, hr_emp.last_name)) AS hr_name, hr_user.username AS hr_username,
           TRIM(CONCAT_WS(' ', sup_emp.first_name, sup_emp.last_name)) AS supervisor_name, sup_user.username AS supervisor_username,
           COUNT(e.employee_id) AS employee_count
    FROM department d
    LEFT JOIN users hr_user ON hr_user.user_id = d.hr_user_id
    LEFT JOIN employee hr_emp ON hr_emp.employee_id = hr_user.employee_id
    LEFT JOIN users sup_user ON sup_user.user_id = d.supervisor_user_id
    LEFT JOIN employee sup_emp ON sup_emp.employee_id = sup_user.employee_id
    LEFT JOIN employee e ON e.department_id = d.department_id AND ${ACTIVE_EMP}
    GROUP BY d.department_id, d.name, d.hr_user_id, d.supervisor_user_id,
             hr_emp.first_name, hr_emp.last_name, hr_user.username, sup_emp.first_name, sup_emp.last_name, sup_user.username
    ORDER BY d.name ASC`);
  let assigned = 0; let incomplete = 0;
  for (const d of departments) {
    d.employee_count = Number(d.employee_count);
    d.is_preset = isPreset(d.name);
    assigned += d.employee_count;
    if (!d.hr_user_id || !d.supervisor_user_id) incomplete++;
  }
  let pendingTransfers = 0;
  try {
    await require('../lib/employment').ensureSchema();
    const [[pt]] = await db.query("SELECT COUNT(*) AS n FROM employee_transfer_request WHERE status IN ('Pending Supervisor','Pending HR')");
    pendingTransfers = Number(pt.n);
  } catch (e) { console.warn('Transfer count unavailable:', e.message); }
  return {
    title: 'Departments', pendingTransfers, departments, assignedEmployees: assigned, missingCount: incomplete,
    hrUsers: await hrOptions(0), supervisors: await supervisorOptions(0),
    modalErrors: [], modalName: '', ...extra,
  };
}

/* ---------------------------------------------------------------- list */
router.get('/', isAuth, async (req, res) => {
  try {
    res.render('department/index', { ...(await listPageData()), user: req.session.user || req.session });
  } catch (err) {
    console.error('Department list error:', err);
    res.status(500).send('Unable to load departments. See the Node.js terminal for details.');
  }
});

/* ---------------------------------------------------------------- create */
router.post('/create', isAuth, async (req, res) => {
  try {
    await ensureSchema();
    const v = formVars(req);
    const errors = await validate({ ...v, departmentId: 0 });
    if (errors.length) {
      return res.status(400).render('department/index', { ...(await listPageData({ modalErrors: errors, modalName: v.name })), user: req.session.user || req.session });
    }
    await db.query(
      'INSERT INTO department (name, hr_user_id, supervisor_user_id, hr_employee_id, supervisor_employee_id) VALUES (?, ?, ?, ?, ?)',
      [v.name, v.hrUserId || null, v.supervisorUserId || null, await employeeIdOf(v.hrUserId), await employeeIdOf(v.supervisorUserId)]);
    res.redirect('/departments');
  } catch (err) { console.error('Department create error:', err); res.status(500).send('Failed to add department. See the Node.js terminal for details.'); }
});

/* ---------------------------------------------------------------- edit page */
async function renderEdit(req, res, id, over = {}) {
  await ensureSchema();
  const [rows] = await db.query('SELECT department_id, name, hr_user_id, supervisor_user_id FROM department WHERE department_id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).send('Department not found.');
  const [employees] = await db.query(
    `SELECT e.employee_id, e.first_name, e.last_name FROM employee e WHERE e.department_id = ? AND ${ACTIVE_EMP} ORDER BY e.last_name, e.first_name`, [id]);
  res.status(over.status || 200).render('department/edit', {
    title: 'Edit Department', departmentId: id,
    name: over.name !== undefined ? over.name : rows[0].name,
    hrUserId: over.hrUserId !== undefined ? over.hrUserId : Number(rows[0].hr_user_id || 0),
    supervisorUserId: over.supervisorUserId !== undefined ? over.supervisorUserId : Number(rows[0].supervisor_user_id || 0),
    errors: over.errors || [], employees,
    hrUsers: await hrOptions(id), supervisors: await supervisorOptions(id),
    user: req.session.user || req.session,
  });
}

router.get('/edit/:id', isAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!(id > 0)) return res.status(400).send('Invalid department.');
  try { await renderEdit(req, res, id); } catch (err) { console.error('Department edit page error:', err); res.status(500).send('Unable to load the department. See the Node.js terminal for details.'); }
});

router.post('/edit/:id', isAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!(id > 0)) return res.status(400).send('Invalid department.');
  try {
    await ensureSchema();
    const v = formVars(req);
    const errors = await validate({ ...v, departmentId: id });
    if (errors.length) return renderEdit(req, res, id, { errors, name: v.name, hrUserId: v.hrUserId, supervisorUserId: v.supervisorUserId, status: 400 });
    const [result] = await db.query(
      'UPDATE department SET name = ?, hr_user_id = ?, supervisor_user_id = ?, hr_employee_id = ?, supervisor_employee_id = ? WHERE department_id = ?',
      [v.name, v.hrUserId || null, v.supervisorUserId || null, await employeeIdOf(v.hrUserId), await employeeIdOf(v.supervisorUserId), id]);
    if (!result.affectedRows) return res.status(404).send('Department not found.');
    res.redirect('/departments');
  } catch (err) { console.error('Department update error:', err); res.status(500).send('Failed to update the department. See the Node.js terminal for details.'); }
});

/* ---------------------------------------------------------------- archive */
router.post('/archive/:id', isAuth, async (req, res) => {
  try {
    const [employees] = await db.query("SELECT COUNT(*) AS count FROM employee e WHERE e.department_id = ? AND COALESCE(e.status, 'Active') <> 'Archived'", [req.params.id]);
    if (Number(employees[0].count) > 0) return res.status(409).send('This department still has active employees assigned. Reassign or archive those employees first.');
    const [rows] = await db.query('SELECT * FROM department WHERE department_id = ? LIMIT 1', [req.params.id]);
    if (!rows.length) return res.status(404).send('Department not found.');
    await archiveRecord({ sourceTable: 'department', sourceId: rows[0].department_id, label: `Department: ${rows[0].name}`, data: rows[0], module: 'Departments', req });
    await db.query('DELETE FROM department WHERE department_id = ?', [req.params.id]);
    res.redirect('/departments');
  } catch (err) { console.error('Department archive error:', err); res.status(500).send('Failed to archive department. See the Node.js terminal for details.'); }
});

module.exports = router;
