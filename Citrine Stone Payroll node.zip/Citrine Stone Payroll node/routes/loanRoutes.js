'use strict';
/*
 * Loans & Cash Advances (admin / HR / supervisor side).
 *   GET  /loans                 list + summary cards
 *   GET  /loans/create          new request form (limits shown live)
 *   POST /loans/create          file a request
 *   GET  /loans/limits/:id      JSON: limit / used / available for one employee (drives the form)
 *   GET  /loans/view/:id        request details, schedule, approve / reject / release
 *   POST /loans/action/:id      approve | reject | release
 *
 * Admin and HR decide. HR only for the departments they handle. Nobody decides a request they filed
 * or one that is for them. Supervisors can file for their department and watch, but not decide.
 * Employees file their own from /my/loans.
 */
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const { normalizeRole } = require('../middleware/rbac');
const loans = require('../lib/loans');
const policy = require('../lib/loanPolicy');

router.use(isAuth);

async function scopeOf(req) {
  const s = req.session || {};
  const uid = Number(s.userId || s.user_id || (s.user && s.user.user_id)) || 0;
  let empId = Number(s.employee_id || s.employeeId || (s.user && s.user.employee_id)) || 0;
  if (!empId && uid) {
    const [r] = await db.query('SELECT employee_id FROM users WHERE user_id = ? LIMIT 1', [uid]);
    empId = Number(r[0] && r[0].employee_id) || 0;
    if (empId) s.employee_id = empId;
  }
  return { role: normalizeRole(s.role || s.role_name || (s.user && s.user.role)), uid, empId };
}

const fail = (res, err, what) => { console.error(`Loans ${what} error:`, err); return res.status(500).send(`Unable to ${what}. See the Node.js terminal for details.`); };
const page = (req, extra) => ({ user: req.session.user || req.session, limitTable: policy.CATEGORY_LIST, ...extra });

router.use(async (req, res, next) => { try { await loans.ensureSchema(db); next(); } catch (e) { fail(res, e, 'prepare the loans module'); } });

/* ---------------------------------------------------------------- list */
router.get('/', async (req, res) => {
  try {
    const scope = await scopeOf(req);
    const filters = { search: String(req.query.search || '').trim().slice(0, 100), type: String(req.query.type || ''), status: String(req.query.status || '') };
    const [requests, stats] = await Promise.all([loans.list(db, scope, filters), loans.stats(db, scope)]);
    res.render('loans/index', page(req, {
      title: 'Loans & Cash Advances', requests, stats, filters, role: scope.role,
      types: policy.TYPES, statuses: ['Pending', 'Approved', 'Released', 'Completed', 'Rejected'],
      saved: req.query.saved === '1', notice: String(req.query.notice || '').slice(0, 200),
    }));
  } catch (e) { fail(res, e, 'load loans'); }
});

/* ---------------------------------------------------------------- new request */
async function renderCreate(req, res, over = {}) {
  const scope = await scopeOf(req);
  const employees = await loans.fileableEmployees(db, scope);
  const form = { employee_id: String(req.query.employee_id || ''), request_type: 'Cash Advance', amount: '', installments: '1', purpose: '', ...(over.form || {}) };
  const current = employees.find((e) => String(e.employee_id) === String(form.employee_id));
  const limits = current ? await loans.limitsFor(db, current) : null;
  res.status(over.status || 200).render('loans/create', page(req, {
    title: 'New Loan / Cash Advance Request', employees, form, limits, errors: over.errors || [],
    types: policy.TYPES, maxInstallments: policy.MAX_INSTALLMENTS, role: scope.role, ownEmployeeId: scope.empId,
  }));
}
router.get('/create', async (req, res) => { try { await renderCreate(req, res); } catch (e) { fail(res, e, 'open the request form'); } });

router.post('/create', async (req, res) => {
  try {
    const scope = await scopeOf(req);
    const b = req.body || {};
    const form = { employee_id: String(b.employee_id || ''), request_type: String(b.request_type || ''), amount: String(b.amount || ''), installments: String(b.installments || ''), purpose: String(b.purpose || '') };
    // The filer may only pick people they are allowed to file for.
    const allowed = await loans.fileableEmployees(db, scope);
    if (!allowed.some((e) => String(e.employee_id) === form.employee_id)) return renderCreate(req, res, { form, errors: ['Select an employee you are allowed to file for.'], status: 400 });
    const out = await loans.createRequest(db, { employeeId: Number(form.employee_id), type: form.request_type, amount: form.amount, installments: form.installments, purpose: form.purpose, filedBy: scope.uid });
    if (!out.ok) return renderCreate(req, res, { form, errors: out.errors, status: 422 });
    res.redirect('/loans?saved=1');
  } catch (e) { fail(res, e, 'save the request'); }
});

router.get('/limits/:id', async (req, res) => {
  try {
    const scope = await scopeOf(req);
    const allowed = await loans.fileableEmployees(db, scope);
    const emp = allowed.find((e) => String(e.employee_id) === String(req.params.id));
    if (!emp) return res.status(404).json({ ok: false, message: 'Employee not available.' });
    res.json({ ok: true, ...(await loans.limitsFor(db, emp)) });
  } catch (e) { console.error('Loans limits error:', e); res.status(500).json({ ok: false, message: 'Could not load limits.' }); }
});

/* ---------------------------------------------------------------- view + decisions */
router.get('/view/:id', async (req, res) => {
  try {
    const scope = await scopeOf(req);
    const data = await loans.getOne(db, req.params.id, scope);
    if (!data) return res.status(404).send('Loan request not found, or you do not have access to it.');
    const { loan } = data;
    let canAct = false; let actReason = '';
    if (['Pending', 'Approved'].includes(loan.status)) {
      const can = loans.canDecide(scope, loan);
      if (!can.ok) actReason = can.reason;
      else if (scope.role === 'hr' && !(await loans.hrOwnsDepartment(db, scope.uid, loan.department_id))) actReason = 'Only the HR of this employee\'s department (or an admin) can decide this request.';
      else canAct = true;
    }
    res.render('loans/view', page(req, {
      title: 'Loan Request', ...data, canAct, actReason, role: scope.role,
      maxInstallments: policy.MAX_INSTALLMENTS[loan.loan_type], errors: req.query.error ? [String(req.query.error).slice(0, 300)] : [],
    }));
  } catch (e) { fail(res, e, 'load the request'); }
});

router.post('/action/:id', async (req, res) => {
  try {
    const scope = await scopeOf(req);
    const id = Number(req.params.id);
    if (!(id > 0)) return res.status(400).send('Invalid request.');
    const action = String(req.body.action || '');
    const out = action === 'release'
      ? await loans.release(db, scope, id)
      : await loans.decide(db, scope, id, { action, installments: req.body.installments, remarks: req.body.remarks });
    if (!out.ok) return res.redirect(`/loans/view/${id}?error=${encodeURIComponent(out.errors.join(' '))}`);
    res.redirect(`/loans?notice=${encodeURIComponent(action === 'approve' ? 'Request approved. Release it when the money is handed over.' : action === 'release' ? 'Released. Installments will be deducted on the first payroll cutoff.' : 'Request rejected.')}`);
  } catch (e) { fail(res, e, 'update the request'); }
});

module.exports = router;
