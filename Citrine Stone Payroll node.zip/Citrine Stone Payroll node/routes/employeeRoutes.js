'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const bcrypt = require('bcryptjs');
const { archiveRecord } = require('./archiveStore');
const loans = require('../lib/loans');
const { EMPLOYMENT_STATUSES } = require('../lib/loanPolicy');
const Emp = require('../lib/employment');
const { normalizeRole } = require('../middleware/rbac');
const { validatePersonName } = require('../lib/nameValidation');
const { logAudit } = require('../lib/audit');
const todayYmd = Emp.todayYmd;
const validPastOrToday = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)) && v >= '2000-01-01' && v <= todayYmd();
const canEditHireDate = (req) => ['admin', 'hr'].includes(normalizeRole((req.session && req.session.role) || ''));

function pageError(res, message, err) {
  console.error(message, err);
  return res.status(500).send(`${message} Check the employee, department, and basic_salary table structures. See the Node.js terminal for details.`);
}

// ---------------------------------------------------------------------------
// Add-employee modal helpers (ported from the Gaisano payroll "Add Employee"
// flow: full profile + auto-created login account with a temporary password).
// ---------------------------------------------------------------------------
const DEFAULT_TEMP_PASSWORD = process.env.DEFAULT_TEMP_PASSWORD || '123456';
const CODE_PREFIX = (process.env.EMPLOYEE_CODE_PREFIX || 'LIM').toUpperCase();
const MIN_MONTHLY_SALARY = 15000;
/* Monthly basic salary is fixed by role (published salary reference). The form can not set it. */
const ROLE_SALARY = { employee: 18000, hr: 19494, supervisor: 30001 };
const salaryForRole = (role) => ROLE_SALARY[String(role || '').trim().toLowerCase()] || MIN_MONTHLY_SALARY;
const SUFFIXES = ['Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];
const STATUSES = ['Active', 'Inactive'];

// Employee columns the modal writes. The first existing alias is used; if none
// exists the canonical (first) name is added to the table on first use.
const EMPLOYEE_COLUMN_ALIASES = {
  suffix: ['suffix', 'name_suffix'],
  tin: ['tin', 'tin_number'],
  sss: ['sss', 'sss_number'],
  philhealth: ['philhealth', 'philhealth_number'],
  pagibig: ['pagibig', 'pagibig_number', 'pag_ibig', 'pag_ibig_number']
};
const EMPLOYEE_COLUMN_DDL = {
  suffix: 'VARCHAR(10) NULL', tin: 'VARCHAR(20) NULL', sss: 'VARCHAR(20) NULL',
  philhealth: 'VARCHAR(20) NULL', pagibig: 'VARCHAR(20) NULL'
};

async function columnsOf(conn, table) {
  const [rows] = await conn.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [table]);
  return new Set(rows.map(r => r.COLUMN_NAME));
}

async function resolveEmployeeColumns() {
  let cols = await columnsOf(db, 'employee');
  const map = {};
  for (const [field, aliases] of Object.entries(EMPLOYEE_COLUMN_ALIASES)) {
    let found = aliases.find(a => cols.has(a));
    if (!found) {
      found = aliases[0];
      await db.query(`ALTER TABLE employee ADD COLUMN \`${found}\` ${EMPLOYEE_COLUMN_DDL[field]}`);
      console.log(`employee modal: added missing column employee.${found}`);
    }
    map[field] = found;
  }
  return map;
}

const digits = v => String(v || '').replace(/\D/g, '');
const GOV_IDS = {
  tin: { label: 'TIN', lengths: [9, 12], fmt: d => d.length === 9 ? d.replace(/(\d{3})(\d{3})(\d{3})/, '$1-$2-$3') : d.replace(/(\d{3})(\d{3})(\d{3})(\d{3})/, '$1-$2-$3-$4'), hint: '123-456-789-000' },
  sss: { label: 'SSS number', lengths: [10], fmt: d => d.replace(/(\d{2})(\d{7})(\d{1})/, '$1-$2-$3'), hint: '00-1234567-8' },
  philhealth: { label: 'PhilHealth number', lengths: [12], fmt: d => d.replace(/(\d{2})(\d{9})(\d{1})/, '$1-$2-$3'), hint: '12-345678901-2' },
  pagibig: { label: 'Pag-IBIG number', lengths: [12], fmt: d => d.replace(/(\d{4})(\d{4})(\d{4})/, '$1-$2-$3'), hint: '1234-5678-9012' }
};
const NAME_RE = /^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ .'\-]*$/;
const dailyRate = monthly => Math.round(((monthly * 12) / 313) * 100) / 100;

function validateEmployeeInput(body, deptIds, roleNames) {
  const errors = {}; const v = {};
  v.first_name = String(body.first_name || '').trim().replace(/\s+/g, ' ');
  v.last_name = String(body.last_name || '').trim().replace(/\s+/g, ' ');
  for (const [k, label, req] of [['first_name', 'First name', true], ['last_name', 'Last name', true]]) {
    if (!v[k]) { if (req) errors[k] = `${label} is required.`; }
    else if (v[k].length < 2 || v[k].length > 60 || !NAME_RE.test(v[k])) errors[k] = `${label} may only contain letters, spaces, hyphens, apostrophes and periods (no numbers).`;
  }
  /* Real-person name rules: no fictional/anime/fantasy names, placeholders, ordinary words
     ("the", "happy", "dog", "tree"), profanity or slurs, and no blocked names (see lib/nameBlocklist.js). */
  const nameCheck = validatePersonName(v.first_name, v.last_name);
  for (const [k, msg] of Object.entries(nameCheck.errors)) if (!errors[k]) errors[k] = msg;
  v.suffix = String(body.suffix || '').trim();
  if (v.suffix && !SUFFIXES.includes(v.suffix)) errors.suffix = 'Choose a valid suffix.';
  v.department_id = String(body.department_id || '').trim();
  if (!v.department_id) errors.department_id = 'Select a department.';
  else if (!deptIds.has(v.department_id)) errors.department_id = 'That department does not exist.';
  for (const [k, def] of Object.entries(GOV_IDS)) {
    const d = digits(body[k]);
    if (!d) errors[k] = `${def.label} is required.`;
    else if (!def.lengths.includes(d.length)) errors[k] = `${def.label} must be ${def.lengths.join(' or ')} digits (e.g. ${def.hint}).`;
    else v[k] = def.fmt(d);
  }
  /* salary comes from the role only: any basic_salary sent by the browser is ignored */
  v.effective_date = String(body.effective_date || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v.effective_date) || Number.isNaN(Date.parse(v.effective_date))) errors.effective_date = 'Enter a valid salary effective date.';
  v.status = String(body.status || 'Active').trim();
  if (!STATUSES.includes(v.status)) errors.status = 'Choose a valid status.';
  /* Probationary until six months after the date hired, then Regular (this also decides the loan limit tier) */
  v.date_hired = String(body.date_hired || '').trim();
  if (!validPastOrToday(v.date_hired)) errors.date_hired = 'Enter the date hired (today or earlier).';
  else v.employment_status = Emp.describeEmployment({ date_hired: v.date_hired }).status;
  v.role = String(body.role || 'Employee').trim();
  if (!roleNames.has(v.role)) errors.role = 'Choose a valid role.';
  else v.basic_salary = salaryForRole(v.role);
  return { errors, values: v, nameViolations: nameCheck.violations };
}

const { departmentCode, nextEmployeeCode, ensureSchema: ensureEmployeeCodes } = require('../lib/employeeCode');

async function uniqueUsername(conn, first, last) {
  const clean = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const base = `${clean(first)}.${clean(last)}`.replace(/^\.|\.$/g, '') || 'employee';
  for (let i = 0; i < 500; i++) {
    const candidate = i === 0 ? base : `${base}${i + 1}`;
    const [rows] = await conn.query('SELECT 1 FROM users WHERE username = ? LIMIT 1', [candidate]);
    if (!rows.length) return candidate;
  }
  throw new Error('Unable to generate a unique username.');
}

// Employee directory
router.get('/', isAuth, async (req, res) => {
  try {
    try { await Emp.syncRegularization(); } catch (e) { console.warn('Regularization sync:', e.message); }
    const search = String(req.query.search || '').trim();
    const params = [];
    let searchSql = '';
    if (search) {
      searchSql = ` AND (e.first_name LIKE ? OR e.last_name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }
    // Filters: department, and employee-code group (the code without its trailing number, e.g. LIM-FG, LIM-MAN)
    const departmentId = String(req.query.department_id || '').trim();
    const codePrefix = String(req.query.code_prefix || '').trim();
    if (/^\d+$/.test(departmentId)) { searchSql += ' AND e.department_id = ?'; params.push(Number(departmentId)); }
    if (codePrefix) { searchSql += ' AND e.employee_code LIKE ?'; params.push(codePrefix.replace(/[\\%_]/g, '\\$&') + '-%'); }
    const [[employees], [departments], [roles], [codeRows]] = await Promise.all([
      db.query(`
        SELECT e.*, e.employee_id AS id,
               d.name AS department_name,
               bs.rate_value AS basic_salary
        FROM employee e
        LEFT JOIN department d ON e.department_id = d.department_id
        LEFT JOIN basic_salary bs ON e.employee_id = bs.employee_id
        WHERE COALESCE(e.status, 'Active') <> 'Archived' ${searchSql}
        ORDER BY e.last_name ASC, e.first_name ASC
      `, params),
      db.query('SELECT department_id AS id, name AS department_name FROM department ORDER BY name'),
      db.query('SELECT role_id, role_name FROM roles ORDER BY role_id'),
      db.query("SELECT employee_code FROM employee WHERE employee_code IS NOT NULL AND employee_code <> '' AND COALESCE(status, 'Active') <> 'Archived'")
    ]);
    employees.forEach((e) => { e.employment = Emp.describeEmployment(e); });
    const codePrefixes = [...new Set(codeRows.map(r => String(r.employee_code).replace(/-\d+$/, '')))].sort();
    res.render('employees/index', {
      title: 'Employees', employees, departments, roles,
      suffixes: SUFFIXES, statuses: STATUSES, employmentStatuses: EMPLOYMENT_STATUSES,
      statusBadge: Emp.statusBadge, minSalary: MIN_MONTHLY_SALARY, roleSalaries: ROLE_SALARY, defaultTempPassword: DEFAULT_TEMP_PASSWORD,
      openAdd: req.query.add === '1',
      selectedDepartment: departmentId, codePrefixes, selectedPrefix: codePrefix,
      filters: { search }, user: req.session.user || req.session
    });
  } catch (err) { return pageError(res, 'Unable to load employees.', err); }
});

// The old full-page form now lives in a modal on the directory page.
router.get('/create', isAuth, (req, res) => {
  const dept = req.query.department_id ? `&department_id=${encodeURIComponent(req.query.department_id)}` : '';
  res.redirect(`/employees?add=1${dept}`);
});

// Create employee + salary record + login account (temporary password). JSON API for the modal.
router.post('/create', isAuth, async (req, res) => {
  const fail = (status, errors, message) => res.status(status).json({ ok: false, errors: errors || {}, message });
  let conn;
  try {
    const [[depts], [roles]] = await Promise.all([
      db.query('SELECT department_id, name FROM department'),
      db.query('SELECT role_id, role_name FROM roles')
    ]);
    const deptMap = new Map(depts.map(d => [String(d.department_id), d.name]));
    const roleMap = new Map(roles.map(r => [r.role_name, r.role_id]));
    const { errors, values: v, nameViolations } = validateEmployeeInput(req.body, new Set(deptMap.keys()), new Set(roleMap.keys()));
    if (Object.keys(errors).length) {
      /* Leave a trace when someone tries a fictional / offensive / blocked name (never blocks the response). */
      if (nameViolations.length) logAudit(req, 'Employees', `Add employee rejected by name rules (${[...new Set(nameViolations)].join(', ')}): "${`${v.first_name} ${v.last_name}`.slice(0, 120)}"`, 'Add Employee Rejected');
      return fail(422, errors, 'Please fix the highlighted fields.');
    }

    await loans.ensureSchema(db); /* makes sure employee.employment_status exists */
    await Emp.ensureSchema();
    await ensureEmployeeCodes(); /* employee.employee_code and users.employee_code exist */
    const col = await resolveEmployeeColumns();

    // Duplicate government IDs.
    for (const k of Object.keys(GOV_IDS)) {
      const [dup] = await db.query(`SELECT employee_id FROM employee WHERE \`${col[k]}\` = ? AND COALESCE(status,'Active') <> 'Archived' LIMIT 1`, [v[k]]);
      if (dup.length) errors[k] = `${GOV_IDS[k].label} is already assigned to another employee.`;
    }
    if (Object.keys(errors).length) return fail(409, errors, 'Duplicate details found.');

    conn = await db.getConnection();
    await conn.beginTransaction();

    const code = await nextEmployeeCode(conn, deptMap.get(v.department_id));
    const fields = ['employee_code', 'first_name', 'last_name', 'department_id', 'status', 'employment_status', col.suffix, col.tin, col.sss, col.philhealth, col.pagibig, 'date_hired'];
    const vals = [code, v.first_name, v.last_name, v.department_id, v.status, v.employment_status, v.suffix || null, v.tin, v.sss, v.philhealth, v.pagibig, v.date_hired];
    const [result] = await conn.query(`INSERT INTO employee (${fields.map(f => `\`${f}\``).join(', ')}) VALUES (${fields.map(() => '?').join(', ')})`, vals);
    const employeeId = result.insertId;

    // basic_salary.rate_value holds the monthly basic salary; daily/monthly helper columns are filled when present.
    const salaryCols = await columnsOf(conn, 'basic_salary');
    const sFields = ['employee_id', 'rate_value', 'effective_date'];
    const sVals = [employeeId, v.basic_salary, v.effective_date];
    for (const c of ['monthly_salary', 'monthly_rate']) if (salaryCols.has(c)) { sFields.push(c); sVals.push(v.basic_salary); }
    for (const c of ['daily_rate']) if (salaryCols.has(c)) { sFields.push(c); sVals.push(dailyRate(v.basic_salary)); }
    await conn.query(`INSERT INTO basic_salary (${sFields.map(f => `\`${f}\``).join(', ')}) VALUES (${sFields.map(() => '?').join(', ')})`, sVals);

    // Login account with a temporary password; user must change it on first login.
    const userCols = await columnsOf(conn, 'users');
    const username = await uniqueUsername(conn, v.first_name, v.last_name);
    const hash = await bcrypt.hash(DEFAULT_TEMP_PASSWORD, 10);
    const uFields = ['username', 'password_hash', 'role_id', 'status', 'must_change_password'];
    const uVals = [username, hash, roleMap.get(v.role), v.status === 'Active' ? 'Active' : 'Inactive', 1];
    if (userCols.has('employee_id')) { uFields.push('employee_id'); uVals.push(employeeId); }
    if (userCols.has('employee_code')) { uFields.push('employee_code'); uVals.push(code); }
    await conn.query(`INSERT INTO users (${uFields.map(f => `\`${f}\``).join(', ')}) VALUES (${uFields.map(() => '?').join(', ')})`, uVals);

    await conn.commit();
    return res.json({
      ok: true,
      employee: { id: employeeId, code, name: [v.first_name, v.last_name].join(' ') },
      account: { username, role: v.role, temporaryPassword: DEFAULT_TEMP_PASSWORD },
      dailyRate: dailyRate(v.basic_salary)
    });
  } catch (err) {
    if (conn) { try { await conn.rollback(); } catch (_) {} }
    console.error('Failed to create employee:', err);
    return fail(500, {}, 'Failed to create employee: ' + (err.sqlMessage || err.message || 'unknown error') + (err.code ? ' [' + err.code + ']' : ''));
  } finally { if (conn) conn.release(); }
});

// View employee details
router.get('/view/:id', isAuth, async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT e.*, e.employee_id AS id, d.name AS department_name, bs.rate_value AS basic_salary
      FROM employee e LEFT JOIN department d ON e.department_id = d.department_id
      LEFT JOIN basic_salary bs ON e.employee_id = bs.employee_id WHERE e.employee_id = ? LIMIT 1`, [req.params.id]);
    if (!rows.length) return res.status(404).send('Employee not found.');
    try { await Emp.syncRegularization(); } catch (e) { console.warn('Regularization sync:', e.message); }
    res.render('employees/view', { title: 'Employee Profile', employee: rows[0], employment: Emp.describeEmployment(rows[0]), statusBadge: Emp.statusBadge, user: req.session.user || req.session });
  } catch (err) { return pageError(res, 'Unable to load employee profile.', err); }
});

// Edit form
router.get('/edit/:id', isAuth, async (req, res) => {
  try {
    await loans.ensureSchema(db);
    const [[rows], [departments]] = await Promise.all([
      db.query(`SELECT e.*, e.employee_id AS id, bs.rate_value AS basic_salary FROM employee e LEFT JOIN basic_salary bs ON e.employee_id = bs.employee_id WHERE e.employee_id = ? LIMIT 1`, [req.params.id]),
      db.query('SELECT department_id AS id, name AS department_name FROM department ORDER BY name')
    ]);
    if (!rows.length) return res.status(404).send('Employee not found.');
    res.render('employees/edit', { title: 'Edit Employee', employee: rows[0], departments, employment: Emp.describeEmployment(rows[0]), canEditHireDate: canEditHireDate(req), todayYmd: todayYmd(), user: req.session.user || req.session });
  } catch (err) { return pageError(res, 'Unable to open employee edit form.', err); }
});

// Update employee details and salary rate
router.post('/edit/:id', isAuth, async (req, res) => {
  const { employee_code, first_name, last_name, department_id, basic_salary } = req.body;
  const conn = await db.getConnection();
  try {
    await loans.ensureSchema(db);
    await conn.beginTransaction();
    /* The department is not editable here: it only changes through an approved transfer request. */
    await Emp.ensureSchema();
    const hireDate = canEditHireDate(req) && validPastOrToday(String(req.body.date_hired || '').trim()) ? String(req.body.date_hired).trim() : null;
    const [result] = await conn.query(`UPDATE employee SET first_name = ?, last_name = ?, date_hired = COALESCE(?, date_hired) WHERE employee_id = ?`,
      [String(first_name || '').trim(), String(last_name || '').trim(), hireDate, req.params.id]);
    if (!result.affectedRows) { await conn.rollback(); return res.status(404).send('Employee not found.'); }
    if (basic_salary !== undefined && basic_salary !== '' && Number.isFinite(Number(basic_salary)) && Number(basic_salary) >= 0) {
      const [salaryRows] = await conn.query('SELECT employee_id FROM basic_salary WHERE employee_id = ? LIMIT 1', [req.params.id]);
      if (salaryRows.length) await conn.query('UPDATE basic_salary SET rate_value = ? WHERE employee_id = ?', [Number(basic_salary), req.params.id]);
      else await conn.query('INSERT INTO basic_salary (employee_id, rate_value, effective_date) VALUES (?, ?, CURDATE())', [req.params.id, Number(basic_salary)]);
    }
    await conn.commit();
    try { await Emp.syncRegularization(); } catch (e) { console.warn('Regularization sync:', e.message); }
    res.redirect('/employees');
  } catch (err) { await conn.rollback(); return pageError(res, 'Failed to update employee.', err); }
  finally { conn.release(); }
});

// Archive rather than permanently delete, preserving payroll history.
router.post('/archive/:id', isAuth, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM employee WHERE employee_id = ? LIMIT 1', [req.params.id]);
    if (!rows.length) return res.status(404).send('Employee not found.');
    if (String(rows[0].status || '').toLowerCase() !== 'archived') {
      await archiveRecord({ sourceTable: 'employee', sourceId: rows[0].employee_id, label: `Employee: ${rows[0].first_name || ''} ${rows[0].last_name || ''}`.trim(), data: rows[0], module: 'Employees', req });
      await db.query("UPDATE employee SET status = 'Archived' WHERE employee_id = ?", [req.params.id]);
    }
    res.redirect('/employees');
  } catch (err) { return pageError(res, 'Failed to archive employee.', err); }
});

module.exports = router;
