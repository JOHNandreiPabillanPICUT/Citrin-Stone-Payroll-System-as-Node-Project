const express = require('express');
const router = express.Router();
const db = require('../config/database');
const isAuth = require('../middleware/auth');
const bcrypt = require('bcryptjs');
const PR = require('../lib/passwordReset');
const { normalizeRole } = require('../middleware/rbac');
const { logAudit } = require('../lib/audit');

// View Users Administration
router.get('/', isAuth, async (req, res) => {
  try {
    const [users] = await db.query(`
      SELECT u.user_id AS id, u.username, u.status, u.last_activity, r.role_name AS role, u.must_change_password, d.name AS department
      FROM users u
      JOIN roles r ON u.role_id = r.role_id
      LEFT JOIN employee e ON e.employee_id = u.employee_id
      LEFT JOIN department d ON d.department_id = e.department_id
      ORDER BY u.user_id DESC
    `);
    let resetRequests = [];
    try { resetRequests = await PR.list(); } catch (e) { console.warn('Password reset requests unavailable:', e.message); }
    res.render('users/index', { users, user: req.session, resetRequests, tempPassword: PR.TEMP_PASSWORD, message: String(req.query.msg || ''), error: String(req.query.error || '') });
  } catch (err) {
    console.error(err);
    res.status(500).send('Database Error');
  }
});

// Account details (admin only; the whole /users area is admin-only)
router.get('/view/:id', isAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id)) return res.status(404).send('User not found.');
    const [accounts] = await db.query(
      `SELECT u.user_id, u.username, u.status, u.last_activity, u.must_change_password, u.employee_id, u.employee_code, r.role_name AS role
         FROM users u JOIN roles r ON r.role_id = u.role_id WHERE u.user_id = ? LIMIT 1`, [id]);
    if (!accounts.length) return res.status(404).send('User not found.');
    const account = accounts[0];
    let employee = null, employment = null;
    if (account.employee_id) {
      const [rows] = await db.query(
        `SELECT e.*, d.name AS department_name, bs.rate_value AS basic_salary, bs.effective_date AS salary_effective,
                d.hr_user_id, d.supervisor_user_id
           FROM employee e
           LEFT JOIN department d ON d.department_id = e.department_id
           LEFT JOIN basic_salary bs ON bs.employee_id = e.employee_id
          WHERE e.employee_id = ? LIMIT 1`, [account.employee_id]).catch(async () => db.query(
        `SELECT e.*, d.name AS department_name, bs.rate_value AS basic_salary FROM employee e
           LEFT JOIN department d ON d.department_id = e.department_id
           LEFT JOIN basic_salary bs ON bs.employee_id = e.employee_id WHERE e.employee_id = ? LIMIT 1`, [account.employee_id]));
      if (rows.length) {
        employee = rows[0];
        const pick = (names) => { const k = names.find((n) => employee[n] !== undefined); return k ? employee[k] : null; };
        employee.suffix_value = pick(['suffix', 'name_suffix']);
        employee.tin_value = pick(['tin', 'tin_number']);
        employee.sss_value = pick(['sss', 'sss_number']);
        employee.philhealth_value = pick(['philhealth', 'philhealth_number']);
        employee.pagibig_value = pick(['pagibig', 'pagibig_number', 'pag_ibig', 'pag_ibig_number']);
        const nameOf = async (userId) => {
          if (!userId) return null;
          const [r] = await db.query('SELECT e.first_name, e.last_name FROM users u JOIN employee e ON e.employee_id = u.employee_id WHERE u.user_id = ? LIMIT 1', [userId]);
          return r.length ? [r[0].first_name, r[0].last_name].filter(Boolean).join(' ') : null;
        };
        employee.dept_hr_name = await nameOf(employee.hr_user_id);
        employee.dept_supervisor_name = await nameOf(employee.supervisor_user_id);
        employment = require('../lib/employment').describeEmployment(employee);
      }
    }
    res.render('users/view', { title: 'User Details', account, employee, employment, statusBadge: require('../lib/employment').statusBadge, user: req.session });
  } catch (err) { console.error('User details error:', err); res.status(500).send('Unable to load user details.'); }
});

// Create New User
router.post('/create', isAuth, async (req, res) => {
  const { username, password, role } = req.body;
  try {
    // Map role name to role_id
    const [roleRows] = await db.query('SELECT role_id FROM roles WHERE role_name = ?', [role]);
    const roleId = roleRows.length > 0 ? roleRows[0].role_id : 3; // Default to Employee

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    await db.query(
      'INSERT INTO users (username, password_hash, role_id, status) VALUES (?, ?, ?, ?)',
      [username, passwordHash, roleId, 'Active']
    );
    res.redirect('/users');
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to create user account');
  }
});

// Password reset requests (admin only)
const adminOnly = (req, res, next) => normalizeRole(req.session && req.session.role) === 'admin' ? next() : res.status(403).send('Only an administrator can decide password reset requests.');
const backToUsers = (res, kind, text) => res.redirect('/users?' + kind + '=' + encodeURIComponent(text));

router.post('/reset-requests/:id/approve', isAuth, adminOnly, async (req, res) => {
  try {
    const out = await PR.approve(parseInt(req.params.id, 10), Number(req.session.userId || req.session.user_id));
    if (out.error) return backToUsers(res, 'error', out.error);
    await logAudit(req, 'Users', `Approved password reset for ${out.username}; temporary password issued`, 'Approve');
    backToUsers(res, 'msg', `Approved. ${out.username} can now sign in with the temporary password ${out.temporaryPassword} and will be asked to choose a new one.`);
  } catch (err) { console.error('Approve password reset error:', err); backToUsers(res, 'error', 'Unable to approve the request.'); }
});

router.post('/reset-requests/:id/reject', isAuth, adminOnly, async (req, res) => {
  try {
    const out = await PR.reject(parseInt(req.params.id, 10), Number(req.session.userId || req.session.user_id), req.body && req.body.reason);
    if (out.error) return backToUsers(res, 'error', out.error);
    await logAudit(req, 'Users', `Rejected password reset request for ${out.username}`, 'Reject');
    backToUsers(res, 'msg', `Request from ${out.username} rejected.`);
  } catch (err) { console.error('Reject password reset error:', err); backToUsers(res, 'error', 'Unable to reject the request.'); }
});

module.exports = router;