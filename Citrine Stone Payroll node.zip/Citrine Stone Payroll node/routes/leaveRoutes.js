'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const { normalizeRole } = require('../middleware/rbac');
const { ensureMiddleware, HR_VISIBLE } = require('../lib/approvalFlow');
router.use(requireAuth);
router.use(ensureMiddleware(db));
const q = s => '`' + String(s).replace(/`/g, '``') + '`';
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const validDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v||'')) && !Number.isNaN(Date.parse(`${v}T00:00:00`));
async function cols(table) { const [r] = await db.query('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?',[table]); return new Set(r.map(x=>x.COLUMN_NAME)); }
async function actor(req) {
  const uid = Number(req.session.userId || req.session.user_id || 0);
  const role = normalizeRole(req.session.role);
  if (role === 'employee') {
    const [r] = await db.query('SELECT e.employee_id,e.department_id FROM users u JOIN employee e ON e.employee_id=u.employee_id WHERE u.user_id=? LIMIT 1',[uid]);
    return { uid, role, employee: r[0] || null, departments: r[0] ? [Number(r[0].department_id)] : [] };
  }
  if (role === 'admin') return { uid, role, employee: null, departments: null };
  const col = role === 'hr' ? 'hr_user_id' : 'supervisor_user_id';
  const [r] = await db.query(`SELECT department_id FROM department WHERE ${q(col)}=?`,[uid]);
  return { uid, role, employee: null, departments: r.map(x=>Number(x.department_id)) };
}
function deny(res) { return res.status(403).send('Forbidden: you are not authorized to access this leave request.'); }
async function audit(req, action, detail) {
  try {
    const [ts] = await db.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('audit_log','audit_logs','activity_logs','activity_log','system_logs')");
    const table = ts[0] && ts[0].TABLE_NAME; if (!table) return;
    const c = await cols(table), data = {};
    const put=(names,v)=>{const k=names.find(x=>c.has(x));if(k)data[k]=v;};
    put(['user_id','performed_by'],Number(req.session.userId||req.session.user_id||0)); put(['username','user_name','actor'],String(req.session.username||''));
    put(['module','module_name','category'],'Leave'); put(['action','action_type','event'],action); put(['description','details','message','activity'],detail); put(['created_at','logged_at','timestamp'],new Date()); put(['outcome','result'],'Success');
    const keys=Object.keys(data); if(keys.length) await db.query(`INSERT INTO ${q(table)} (${keys.map(q).join(',')}) VALUES (${keys.map(()=>'?').join(',')})`,keys.map(k=>data[k]));
  } catch(e) { console.warn('Leave audit logging:',e.message); }
}
async function loadLeaves(req) {
  const a=await actor(req); if(!['admin','hr','supervisor'].includes(a.role)) return {a,leaves:[]};
  const c=await cols('leave_request');
  // Supervisors see every request from their department; HR only sees what a supervisor has forwarded (or already decided).
  const inDepts = `e.department_id IN (${a.departments && a.departments.length?a.departments.map(()=>'?').join(','):'NULL'})`;
  const where = a.role==='admin' ? '' : (a.role==='hr' ? ` WHERE ${inDepts} AND ${HR_VISIBLE('l')}` : ` WHERE ${inDepts}`);
  const reviewerCol = c.has('approved_by') ? 'approved_by' : (c.has('reviewed_by') ? 'reviewed_by' : null);
  const reviewerJoin = reviewerCol ? ` LEFT JOIN users u ON u.user_id=l.${q(reviewerCol)} ` : '';
  const reviewerSelect = (reviewerCol ? 'u.username AS reviewer_name' : "NULL AS reviewer_name") + ', su.username AS supervisor_name';
  const [leaves]=await db.query(`SELECT l.*, e.first_name,e.last_name,e.department_id,d.name AS department_name, ${reviewerSelect} FROM leave_request l JOIN employee e ON e.employee_id=l.employee_id LEFT JOIN department d ON d.department_id=e.department_id ${reviewerJoin} LEFT JOIN users su ON su.user_id=l.supervisor_id ${where} ORDER BY l.leave_id DESC LIMIT 500`,a.role==='admin'?[]:a.departments);
  return {a,leaves};
}
router.get('/', requireAuth, async (req,res)=>{
  try { const {a,leaves}=await loadLeaves(req); if(!['admin','hr','supervisor'].includes(a.role)) return deny(res);
    res.render('leave/index',{leaves,user:req.session,path:'/leave',role:a.role,message:req.query.message||''});
  } catch(e){console.error('Leave list:',e);res.status(500).send('Unable to load leave requests.');}
});
router.post('/action/:id', requireAuth, async(req,res)=>{
  const conn=await db.getConnection();
  try {
    const a=await actor(req); if(!['admin','hr','supervisor'].includes(a.role)) return deny(res);
    const id=Number(req.params.id); if(!Number.isInteger(id)||id<1) return res.status(404).send('Leave request not found.');
    const status=String(req.body.status||''); const rejection=String(req.body.rejection_reason||'').trim(); const payType=String(req.body.pay_type||'');
    if(!['Approved','Rejected'].includes(status)) return res.status(400).send('Invalid leave action.');
    if(status==='Rejected'&&!rejection) return res.status(400).send('A rejection reason is required.');
    if(status==='Approved'&&!['Paid','Unpaid'].includes(payType)) return res.status(400).send('Select whether this approved leave is Paid or Unpaid.');
    if(a.role==='supervisor') return res.status(403).send('Supervisors may review and coordinate requests but cannot finalize approval or rejection.');
    await conn.beginTransaction();
    const [rows]=await conn.query('SELECT * FROM leave_request WHERE leave_id=? FOR UPDATE',[id]); if(!rows.length){await conn.rollback();return res.status(404).send('Leave request not found.');}
    const leave=rows[0];
    if(a.role!=='admin') { const [scope]=await conn.query('SELECT department_id FROM employee WHERE employee_id=?',[leave.employee_id]); if(!scope.length||!a.departments.includes(Number(scope[0].department_id))){await conn.rollback();return deny(res);} }
    if(String(leave.status).toLowerCase()!=='pending'){await conn.rollback();return res.status(409).send('Only pending leave requests can be reviewed.');}
    // HR can only decide requests the supervisor has forwarded. Admin may override and the audit log records it.
    if(a.role==='hr'&&leave.supervisor_status!=='Endorsed'){await conn.rollback();return res.status(409).send('This request has not been endorsed by the supervisor yet.');}
    const overridden=a.role==='admin'&&leave.supervisor_status!=='Endorsed';
    if(status==='Approved') {
      const [overlap]=await conn.query("SELECT leave_id FROM leave_request WHERE employee_id=? AND status='Approved' AND leave_id<>? AND start_date<=? AND end_date>=? LIMIT 1",[leave.employee_id,id,leave.end_date,leave.start_date]);
      if(overlap.length){await conn.rollback();return res.status(409).send('This request overlaps an existing approved leave.');}
    }
    const c=await cols('leave_request'), sets=['status=?'], vals=[status];
    if(c.has('approved_by')){sets.push('approved_by=?');vals.push(a.uid);} if(c.has('approved_at'))sets.push('approved_at=NOW()');
    if(c.has('reviewed_by')){sets.push('reviewed_by=?');vals.push(a.uid);} if(c.has('reviewed_at'))sets.push('reviewed_at=NOW()');
    if(c.has('rejection_reason')){sets.push('rejection_reason=?');vals.push(status==='Rejected'?rejection:null);} else if(c.has('remarks')){sets.push('remarks=?');vals.push(status==='Rejected'?rejection:null);}
    if(c.has('pay_type')){sets.push('pay_type=?');vals.push(status==='Approved'?payType:null);}
    vals.push(id); await conn.query(`UPDATE leave_request SET ${sets.join(',')} WHERE leave_id=?`,vals);
    await conn.commit(); await audit(req,status,`Leave request #${id} ${status.toLowerCase()} for employee #${leave.employee_id}${overridden?' (admin override, not endorsed by supervisor)':''}${status==='Rejected'?'; Reason: '+rejection:''}`);
    res.redirect('/leave?message='+encodeURIComponent(`Leave request ${status.toLowerCase()}.`));
  } catch(e){try{await conn.rollback();}catch{} console.error('Leave action:',e);res.status(500).send('Unable to update leave request.');}
  finally{conn.release();}
});
router.post('/endorse/:id', async(req,res)=>{
  const conn=await db.getConnection();
  try {
    const a=await actor(req); if(a.role!=='supervisor') return deny(res);
    const id=Number(req.params.id); if(!Number.isInteger(id)||id<1) return res.status(404).send('Leave request not found.');
    const decision=String(req.body.decision||''); const remarks=String(req.body.remarks||'').trim().slice(0,1000);
    if(!['Endorse','Reject'].includes(decision)) return res.status(400).send('Invalid supervisor action.');
    if(decision==='Reject'&&!remarks) return res.status(400).send('A reason is required when rejecting a request.');
    await conn.beginTransaction();
    const [rows]=await conn.query('SELECT l.*,e.department_id FROM leave_request l JOIN employee e ON e.employee_id=l.employee_id WHERE l.leave_id=? FOR UPDATE',[id]);
    if(!rows.length){await conn.rollback();return res.status(404).send('Leave request not found.');}
    const leave=rows[0];
    if(!a.departments.includes(Number(leave.department_id))){await conn.rollback();return deny(res);}
    if(String(leave.status).toLowerCase()!=='pending'||leave.supervisor_status!=='Pending'){await conn.rollback();return res.status(409).send('This request has already been reviewed.');}
    if(decision==='Endorse') {
      await conn.query("UPDATE leave_request SET supervisor_status='Endorsed',supervisor_id=?,supervisor_at=NOW(),supervisor_remarks=? WHERE leave_id=?",[a.uid,remarks||null,id]);
    } else {
      const c=await cols('leave_request'), sets=["status='Rejected'","supervisor_status='Rejected'",'supervisor_id=?','supervisor_at=NOW()','supervisor_remarks=?'], vals=[a.uid,remarks];
      if(c.has('rejection_reason')){sets.push('rejection_reason=?');vals.push(remarks);} else if(c.has('remarks')){sets.push('remarks=?');vals.push(remarks);}
      vals.push(id); await conn.query(`UPDATE leave_request SET ${sets.join(',')} WHERE leave_id=?`,vals);
    }
    await conn.commit();
    await audit(req,decision==='Endorse'?'Endorsed':'Rejected',`Supervisor ${decision==='Endorse'?'endorsed (forwarded to HR)':'rejected'} leave request #${id}${remarks?'; Note: '+remarks:''}`);
    res.redirect('/leave?message='+encodeURIComponent(decision==='Endorse'?'Request endorsed and forwarded to HR.':'Request rejected.'));
  } catch(e){try{await conn.rollback();}catch{} console.error('Leave endorse:',e);res.status(500).send('Unable to record supervisor review.');}
  finally{conn.release();}
});
module.exports=router;
