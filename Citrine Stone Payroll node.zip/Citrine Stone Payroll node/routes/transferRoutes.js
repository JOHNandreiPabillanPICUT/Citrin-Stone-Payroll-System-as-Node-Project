'use strict';
/* Staff side of department transfers (mounted at /departments/transfers): supervisor review, then HR final approval. */
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const T = require('../lib/transfers');
const E = require('../lib/employment');
const { logAudit } = require('../lib/audit');

const back = (res, kind, text) => res.redirect('/departments/transfers?' + kind + '=' + encodeURIComponent(text));
const nameOf = (r) => [r.first_name, r.last_name].filter(Boolean).join(' ');

router.use(requireAuth);

router.get('/', async (req, res) => {
  try {
    const actor = await T.actorFor(req);
    if (!['admin', 'hr', 'supervisor'].includes(actor.role)) return res.status(403).send('Forbidden.');
    const all = await T.listForStaff(actor);
    const filter = String(req.query.status || '');
    const rows = all.filter((r) => !filter || (filter === 'open' ? T.OPEN.includes(r.status) : r.status === filter));
    for (const r of rows) {
      r.employee_name = nameOf(r);
      r.employment = E.describeEmployment(r);
      /* Admin, supervisor and HR all see the attendance record as soon as the request is filed (live figures while it is open;
         the snapshot HR reviewed once it is decided). */
      if (T.OPEN.includes(r.status) || !r.attendance_snapshot) r.attendance = await T.attendanceSummary(r.employee_id);
      else { try { r.attendance = JSON.parse(r.attendance_snapshot); } catch (e) { r.attendance = await T.attendanceSummary(r.employee_id); } }
    }
    const count = (s) => all.filter((r) => r.status === s).length;
    res.render('department/transfers', {
      title: 'Transfer Requests', path: '/departments', user: req.session, actor, rows, filter,
      stats: { supervisor: count('Pending Supervisor'), hr: count('Pending HR'), approved: count('Approved'), rejected: count('Rejected') },
      statusBadge: E.statusBadge, attendanceDays: T.ATTENDANCE_DAYS,
      message: String(req.query.msg || ''), error: String(req.query.error || ''),
    });
  } catch (err) { console.error('Transfer list error:', err); res.status(500).send('Unable to load transfer requests. See the Node.js terminal for details.'); }
});

async function describe(requestId) {
  const [r] = await db.query(`SELECT t.request_id, e.first_name, e.last_name, fd.name AS from_name, td.name AS to_name
    FROM employee_transfer_request t JOIN employee e ON e.employee_id = t.employee_id
    LEFT JOIN department fd ON fd.department_id = t.from_department_id LEFT JOIN department td ON td.department_id = t.to_department_id
    WHERE t.request_id = ?`, [requestId]);
  return r[0] ? `${nameOf(r[0])} (${r[0].from_name} to ${r[0].to_name})` : `request #${requestId}`;
}

router.post('/:id/supervisor', async (req, res) => {
  try {
    const actor = await T.actorFor(req); const id = parseInt(req.params.id, 10);
    const decision = req.body.decision === 'approve' ? 'approve' : 'reject';
    const out = await T.supervisorDecide(actor, id, decision, req.body.remarks);
    if (out.error) return back(res, 'error', out.error);
    await logAudit(req, 'Department Transfer', `Supervisor ${out.approve ? 'approved and forwarded to HR' : 'rejected'} transfer #${id}: ${await describe(id)}`, out.approve ? 'Approve' : 'Reject');
    back(res, 'msg', out.approve ? 'Request approved and forwarded to HR.' : 'Request rejected.');
  } catch (err) { console.error('Transfer supervisor decision error:', err); res.status(500).send('Unable to save the decision.'); }
});

router.post('/:id/hr', async (req, res) => {
  try {
    const actor = await T.actorFor(req); const id = parseInt(req.params.id, 10);
    const out = await T.hrDecide(actor, id, { ...req.body, decision: req.body.decision === 'approve' ? 'approve' : 'reject' });
    if (out.error) return back(res, 'error', out.error);
    await logAudit(req, 'Department Transfer', `HR ${out.approve ? 'gave final approval to' : 'rejected'} transfer #${id}: ${await describe(id)}`, out.approve ? 'Approve' : 'Reject');
    back(res, 'msg', out.approve ? 'Transfer approved. The employee has been moved to the new department.' : 'Transfer rejected.');
  } catch (err) { console.error('Transfer HR decision error:', err); res.status(500).send('Unable to save the decision.'); }
});

module.exports = router;