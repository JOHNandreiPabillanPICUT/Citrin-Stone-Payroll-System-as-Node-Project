'use strict';
/* Staff side of department transfers (mounted at /departments/transfers): supervisor review, then HR final approval. */
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const requireAuth = require('../middleware/requireAuth');
const T = require('../lib/transfers');
const E = require('../lib/employment');
const { logAudit } = require('../lib/audit');

/* Status tiles shown on the page: [value, label]. */
const STATUS_FILTERS = [['', 'All'], ['open', 'Open'], ['Pending Supervisor', 'Supervisor stage'], ['Pending HR', 'HR stage'], ['Approved', 'Approved'], ['Rejected', 'Rejected'], ['Cancelled', 'Cancelled']];
const cleanStatus = (v) => { v = String(v || ''); return STATUS_FILTERS.some((f) => f[0] === v) ? v : ''; };
const cleanDept = (v) => { v = String(v || ''); return v === 'all' || /^\d+$/.test(v) ? v : ''; };
const matchesStatus = (r, f) => !f || (f === 'open' ? T.OPEN.includes(r.status) : r.status === f);
const deptKey = (r) => String(r.from_department_id || 0);
/* Builds /departments/transfers?status=..&dept=.. so a click on a tile keeps the other selection. */
const link = (status, dept, extra) => {
  const q = [];
  if (status) q.push('status=' + encodeURIComponent(status));
  if (dept) q.push('dept=' + encodeURIComponent(dept));
  if (extra) q.push(extra);
  return '/departments/transfers' + (q.length ? '?' + q.join('&') : '');
};
/* After a decision, go back to the same department / status the reviewer was looking at. */
const back = (req, res, kind, text) => res.redirect(link(cleanStatus(req.body && req.body.status), cleanDept(req.body && req.body.dept), kind + '=' + encodeURIComponent(text)));
const nameOf = (r) => [r.first_name, r.last_name].filter(Boolean).join(' ');

router.use(requireAuth);

router.get('/', async (req, res) => {
  try {
    const actor = await T.actorFor(req);
    if (!['admin', 'hr', 'supervisor'].includes(actor.role)) return res.status(403).send('Forbidden.');
    const all = await T.listForStaff(actor);
    const filter = cleanStatus(req.query.status);
    const dept = cleanDept(req.query.dept); /* '' = nothing chosen yet, 'all' = every department, otherwise a department_id (0 = no department) */

    /* Department squares: one per department that has any request; the number follows the status filter. */
    const byDept = new Map();
    for (const r of all) {
      const k = deptKey(r);
      if (!byDept.has(k)) byDept.set(k, { id: k, name: r.from_name || 'No department', total: 0, open: 0 });
      if (matchesStatus(r, filter)) {
        const d = byDept.get(k); d.total++;
        if (T.OPEN.includes(r.status)) d.open++;
      }
    }
    const deptTiles = [...byDept.values()].sort((a, b) => (a.id === '0') - (b.id === '0') || a.name.localeCompare(b.name));
    const allDept = { id: 'all', name: 'All departments', total: all.filter((r) => matchesStatus(r, filter)).length, open: all.filter((r) => matchesStatus(r, filter) && T.OPEN.includes(r.status)).length };

    /* Status squares: counts are for the chosen department (or everything if none is chosen). */
    const scope = all.filter((r) => !dept || dept === 'all' || deptKey(r) === dept);
    const statusTiles = STATUS_FILTERS.map((f) => ({ value: f[0], label: f[1], count: scope.filter((r) => matchesStatus(r, f[0])).length }));

    /* Employees are only listed after a department square is clicked. */
    const rows = dept ? scope.filter((r) => matchesStatus(r, filter)) : [];
    for (const r of rows) {
      r.employee_name = nameOf(r);
      r.employment = E.describeEmployment(r);
      /* Admin, supervisor and HR all see the attendance record as soon as the request is filed (live figures while it is open;
         the snapshot HR reviewed once it is decided). Only worked out for the employees on screen. */
      if (T.OPEN.includes(r.status) || !r.attendance_snapshot) r.attendance = await T.attendanceSummary(r.employee_id);
      else { try { r.attendance = JSON.parse(r.attendance_snapshot); } catch (e) { r.attendance = await T.attendanceSummary(r.employee_id); } }
    }
    const count = (s) => all.filter((r) => r.status === s).length;
    const selectedDept = dept === 'all' ? allDept : byDept.get(dept) || null;
    res.render('department/transfers', {
      title: 'Transfer Requests', path: '/departments', user: req.session, actor, rows, filter, dept, link,
      deptTiles, allDept, statusTiles, selectedDeptName: selectedDept ? selectedDept.name : '',
      stats: { supervisor: count('Pending Supervisor'), hr: count('Pending HR'), approved: count('Approved'), rejected: count('Rejected') },
      statusBadge: E.statusBadge, attendanceDays: T.ATTENDANCE_DAYS,
      message: String(req.query.msg || ''), error: String(req.query.error || ''),
    });
  } catch (err) { console.error('Transfer list error:', err); res.status(500).send('Unable to load transfer requests. See the Node.js terminal for details.'); }
});

async function describe(requestId) {
  const [r] = await db.query(`SELECT t.request_id, e.first_name, e.last_name, fd.name AS from_name, td.name AS to_name
    FROM employee_transfer_request t JOIN employee e ON e.employee_id = t.employee_id
    LEFT JOIN department fd ON fd.department_id = t.from_department_id LEFT JOIN department td ON td.department_id = t.to_department_id
    WHERE t.request_id = ?`, [requestId]);
  return r[0] ? `${nameOf(r[0])} (${r[0].from_name} to ${r[0].to_name})` : `request #${requestId}`;
}

router.post('/:id/supervisor', async (req, res) => {
  try {
    const actor = await T.actorFor(req); const id = parseInt(req.params.id, 10);
    const decision = req.body.decision === 'approve' ? 'approve' : 'reject';
    const out = await T.supervisorDecide(actor, id, decision, req.body.remarks);
    if (out.error) return back(req, res, 'error', out.error);
    await logAudit(req, 'Department Transfer', `Supervisor ${out.approve ? 'approved and forwarded to HR' : 'rejected'} transfer #${id}: ${await describe(id)}`, out.approve ? 'Approve' : 'Reject');
    back(req, res, 'msg', out.approve ? 'Request approved and forwarded to HR.' : 'Request rejected.');
  } catch (err) { console.error('Transfer supervisor decision error:', err); res.status(500).send('Unable to save the decision.'); }
});

router.post('/:id/hr', async (req, res) => {
  try {
    const actor = await T.actorFor(req); const id = parseInt(req.params.id, 10);
    const out = await T.hrDecide(actor, id, { ...req.body, decision: req.body.decision === 'approve' ? 'approve' : 'reject' });
    if (out.error) return back(req, res, 'error', out.error);
    await logAudit(req, 'Department Transfer', `HR ${out.approve ? 'gave final approval to' : 'rejected'} transfer #${id}: ${await describe(id)}`, out.approve ? 'Approve' : 'Reject');
    back(req, res, 'msg', out.approve ? 'Transfer approved. The employee has been moved to the new department.' : 'Transfer rejected.');
  } catch (err) { console.error('Transfer HR decision error:', err); res.status(500).send('Unable to save the decision.'); }
});

module.exports = router;