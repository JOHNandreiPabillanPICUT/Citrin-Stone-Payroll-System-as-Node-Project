'use strict';

const express = require('express');
const session = require('express-session');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback_secret_key',
    resave: false,
    saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use((req, res, next) => {
    res.locals.user = req.session || {};
    res.locals.path = req.path;
    next();
});

// Accounts created with a temporary password must set their own before using the system.
app.use((req, res, next) => {
    const sess = req.session;
    if (sess && (sess.userId || sess.user_id) && sess.must_change_password) {
        const allowed = ['/auth/change-password', '/auth/logout'];
        if (!allowed.includes(req.path)) return res.redirect('/auth/change-password');
    }
    next();
});

const { rbac, canAccess, normalizeRole, homeFor } = require('./middleware/rbac');
app.locals.stripIds = require('./lib/displayText').stripIds;
app.locals.canAccess = canAccess;
app.locals.normalizeRole = normalizeRole;
app.locals.fmtDate = d => { if (!d) return '—'; const x = new Date(d); return isNaN(x) ? String(d) : x.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' }); };
app.locals.fmtTime = t => { if (!t) return '—'; const m = /^(\d{2}):(\d{2})/.exec(String(t)); if (!m) return String(t); const h = +m[1]; return ((h % 12) || 12) + ':' + m[2] + ' ' + (h >= 12 ? 'PM' : 'AM'); };
app.locals.peso = n => '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
app.locals.badge = st => { const v = String(st || '').toLowerCase(); return 'inline-flex rounded-full px-3 py-1 text-xs font-semibold ' + (['approved', 'present', 'processed'].includes(v) ? 'bg-green-100 text-green-800' : ['rejected', 'absent'].includes(v) ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'); };
app.use(rbac);

// Administrator badge: number of password-reset requests waiting on the Users page / sidebar.
app.use(async (req, res, next) => {
    res.locals.pendingResets = 0;
    try {
        const s = req.session;
        if (req.method === 'GET' && s && (s.userId || s.user_id) && normalizeRole(s.role) === 'admin' && !req.path.startsWith('/events')) {
            res.locals.pendingResets = await require('./lib/passwordReset').pendingCount();
        }
    } catch (e) { /* the badge is optional; never block a page because of it */ }
    next();
});

const requireAuth = require('./middleware/requireAuth');
const realtime = require('./lib/realtime');

const authRoutes = require('./routes/authRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const attendanceRoutes = require('./routes/attendance');
const payrollRoutes = require('./routes/payroll');
const leaveRoutes = require('./routes/leaveRoutes');
const payslipRoutes = require('./routes/payslipRoutes');
const departmentRoutes = require('./routes/departmentRoutes');
const userRoutes = require('./routes/userRoutes');
const ledgerRoutes = require('./routes/ledgerRoutes');
const auditRoutes = require('./routes/auditRoutes');
const archiveRoutes = require('./routes/archiveRoutes');
const overtimeRoutes = require('./routes/overtimeRoutes');
const loanRoutes = require('./routes/loanRoutes');
const myRoutes = require('./routes/myRoutes');

// ---- Live updates ---------------------------------------------------------
// 1) Every HTML page rendered for a logged-in user gets /js/live.js, which listens for changes.
app.use((req, res, next) => {
    const render = res.render.bind(res);
    res.render = (view, options, callback) => {
        if (typeof options === 'function') { callback = options; options = undefined; }
        render(view, options, (err, html) => {
            if (callback) return callback(err, html);
            if (err) return next(err);
            const s = req.session;
            if (s && (s.userId || s.user_id) && !s.must_change_password) {
                const i = html.lastIndexOf('</body>');
                if (i !== -1) html = html.slice(0, i) + '<script src="/js/live.js" defer></script>' + html.slice(i);
            }
            res.send(html);
        });
    };
    next();
});
// 2) Any successful change (POST/PUT/PATCH/DELETE) anywhere tells every open page to refresh itself.
app.use((req, res, next) => {
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !req.path.startsWith('/auth')) {
        res.on('finish', () => { if (res.statusCode < 400) realtime.broadcast({ path: req.path }); });
    }
    next();
});
app.get('/events', requireAuth, (req, res) => realtime.subscribe(req, res));

app.get('/login', (req, res) => {
    return res.redirect('/auth/login');
});

app.use('/auth', authRoutes);

app.get('/', (req, res) => {
    const authenticated = Boolean(
        req.session && (req.session.userId || req.session.user_id)
    );

    return res.redirect(authenticated ? homeFor(req.session.role) : '/auth/login');
});

app.get('/dashboard', requireAuth, async (req, res) => {
    // Dashboard widgets read the existing schema and gracefully fall back to
    // empty values when an optional module/table has not been configured.
    const db = require('./config/database');
    const qid = (value) => '`' + String(value).replace(/`/g, '``') + '`';
    const tableNames = async () => {
        const [rows] = await db.query("SELECT TABLE_NAME AS name FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'");
        return rows.map(row => row.name);
    };
    const columnsFor = async (table) => {
        const [rows] = await db.query('SELECT COLUMN_NAME AS name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [table]);
        return rows.map(row => row.name);
    };
    const findTable = (names, available) => names.find(name => available.includes(name));
    const findColumn = (cols, names) => names.find(name => cols.includes(name));
    const safe = async (fn, fallback) => { try { return await fn(); } catch (error) { console.warn('Dashboard optional widget:', error.message); return fallback; } };
    const today = new Date();
    const todaySql = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;

    const data = await safe(async () => {
        const tables = await tableNames();
        const result = {
            today: today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }),
            activeEmployees: 0, presentToday: 0, pendingLeave: 0, pendingOvertime: 0,
            recentEmployees: [], recentAttendance: [], latestPayroll: null
        };

        const employeeTable = findTable(['employee', 'employees'], tables);
        let empCols = [];
        if (employeeTable) {
            empCols = await columnsFor(employeeTable);
            const empId = findColumn(empCols, ['employee_id','id','emp_id']);
            const first = findColumn(empCols, ['first_name','firstname','given_name']);
            const last = findColumn(empCols, ['last_name','lastname','surname']);
            const status = findColumn(empCols, ['status','employee_status']);
            if (empId) {
                const where = status ? `WHERE COALESCE(${qid(status)}, 'Active') NOT IN ('Archived','Inactive','Terminated')` : '';
                const [[count]] = await db.query(`SELECT COUNT(*) AS total FROM ${qid(employeeTable)} ${where}`);
                result.activeEmployees = Number(count.total || 0);
                if (first && last) {
                    const code = findColumn(empCols, ['employee_code','emp_code','employee_no']);
                    const [rows] = await db.query(`SELECT ${qid(empId)} AS employee_id, ${qid(first)} AS first_name, ${qid(last)} AS last_name${code ? ', '+qid(code)+' AS employee_code' : ''}${status ? ', '+qid(status)+' AS status' : ''} FROM ${qid(employeeTable)} ${where} ORDER BY ${qid(empId)} DESC LIMIT 5`);
                    result.recentEmployees = rows;
                }
            }
        }

        const attendanceTable = findTable(['attendance','attendances'], tables);
        if (attendanceTable) {
            const cols = await columnsFor(attendanceTable);
            const dateCol = findColumn(cols, ['work_date','date','attendance_date']);
            const statusCol = findColumn(cols, ['status','attendance_status']);
            const empKey = findColumn(cols, ['employee_id','emp_id']);
            const inCol = findColumn(cols, ['time_in','timein','clock_in']);
            const outCol = findColumn(cols, ['time_out','timeout','clock_out']);
            const attId = findColumn(cols, ['attendance_id','id','record_id']);
            if (dateCol && statusCol) {
                const [[count]] = await db.query(`SELECT COUNT(*) AS total FROM ${qid(attendanceTable)} WHERE DATE(${qid(dateCol)}) = ? AND LOWER(COALESCE(${qid(statusCol)},'')) IN ('present','late','undertime','on time','on-time')`, [todaySql]);
                result.presentToday = Number(count.total || 0);
            }
            if (dateCol && empKey && attId) {
                const joinOk = employeeTable && empCols.includes(findColumn(empCols,['employee_id','id','emp_id'])) && empKey === findColumn(empCols,['employee_id','id','emp_id']);
                if (joinOk) {
                    const eId = findColumn(empCols,['employee_id','id','emp_id']);
                    const first = findColumn(empCols,['first_name','firstname','given_name']);
                    const last = findColumn(empCols,['last_name','lastname','surname']);
                    if (first && last) {
                        const [rows] = await db.query(`SELECT a.${qid(dateCol)} AS work_date, ${statusCol ? 'a.'+qid(statusCol) : "'Recorded'"} AS status${inCol ? ', a.'+qid(inCol)+' AS time_in' : ', NULL AS time_in'}${outCol ? ', a.'+qid(outCol)+' AS time_out' : ', NULL AS time_out'}, e.${qid(first)} AS first_name, e.${qid(last)} AS last_name FROM ${qid(attendanceTable)} a LEFT JOIN ${qid(employeeTable)} e ON a.${qid(empKey)} = e.${qid(eId)} ORDER BY a.${qid(dateCol)} DESC, a.${qid(attId)} DESC LIMIT 5`);
                        result.recentAttendance = rows;
                    }
                }
            }
        }

        const leaveTable = findTable(['leave_request','leave_requests','leave_application','leave_applications'], tables);
        if (leaveTable) {
            const cols = await columnsFor(leaveTable); const status = findColumn(cols,['status','approval_status']);
            if (status) { const [[count]] = await db.query(`SELECT COUNT(*) AS total FROM ${qid(leaveTable)} WHERE LOWER(${qid(status)}) = 'pending'`); result.pendingLeave = Number(count.total || 0); }
        }
        const otTable = findTable(['overtime_request','overtime_requests','overtime','overtime_application'], tables);
        if (otTable) {
            const cols = await columnsFor(otTable); const status = findColumn(cols,['status','approval_status']);
            if (status) { const [[count]] = await db.query(`SELECT COUNT(*) AS total FROM ${qid(otTable)} WHERE LOWER(${qid(status)}) = 'pending'`); result.pendingOvertime = Number(count.total || 0); }
        }
        const payrollTable = findTable(['payroll_run','payroll_runs','payroll'], tables);
        if (payrollTable) {
            const cols = await columnsFor(payrollTable); const id = findColumn(cols,['payroll_run_id','payroll_id','id']);
            if (id) { const [rows] = await db.query(`SELECT * FROM ${qid(payrollTable)} ORDER BY ${qid(id)} DESC LIMIT 1`); result.latestPayroll = rows[0] || null; }
        }
        return result;
    }, {
        today: today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }),
        activeEmployees: 0, presentToday: 0, pendingLeave: 0, pendingOvertime: 0,
        recentEmployees: [], recentAttendance: [], latestPayroll: null
    });

    return res.render('dashboard', { title: 'Dashboard', user: req.session.user || req.session, ...data });
});

app.use('/my', myRoutes);
app.use('/employees', employeeRoutes);
app.use('/attendance', attendanceRoutes);
app.use('/payroll', payrollRoutes);
app.use('/leave', leaveRoutes);
app.use('/payslips', payslipRoutes);
app.use('/departments/transfers', require('./routes/transferRoutes'));
app.use('/departments', departmentRoutes);
app.use('/users', userRoutes);
app.use('/ledger', ledgerRoutes);
app.use('/audit', auditRoutes);
app.use('/archive', archiveRoutes);
app.use('/overtime', overtimeRoutes);
app.use('/loans', loanRoutes);

app.use((req, res) => {
    return res.status(404).send(`Cannot GET ${req.originalUrl}`);
});

app.use((err, req, res, next) => {
    console.error('Unhandled application error:', err.stack || err);

    if (res.headersSent) {
        return next(err);
    }

    return res.status(500).send('Internal Server Error');
});

app.listen(PORT, () => {
    require('./lib/employeeCode').ensureSchema().catch(err => console.warn('Employee codes were not prepared:', err.message));
    require('./lib/employment').startScheduler(); /* adds date_hired / transfer table if missing and promotes anyone who reached six months */
    console.log(`Citrine Stone Payroll Node server running on http://localhost:${PORT}`);

    // Start-up housekeeping. Both are idempotent and a failure here never stops the server.
    const db = require('./config/database');
    require('./lib/departmentPresets').seedPresetDepartments(db)
        .catch(err => console.warn('Preset departments were not added:', err.message));
    require('./lib/loans').ensureSchema(db)
        .catch(err => console.warn('Loans tables were not prepared:', err.message));
});