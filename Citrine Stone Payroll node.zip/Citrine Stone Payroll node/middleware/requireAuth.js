'use strict';

function requireAuth(req, res, next) {
    if (!req.session) {
        return res.redirect('/auth/login');
    }

    const isAuthenticated = Boolean(
        req.session.userId ||
        req.session.user_id ||
        req.session.user
    );

    if (!isAuthenticated) {
        return res.redirect('/auth/login');
    }

    return next();
}

module.exports = requireAuth;