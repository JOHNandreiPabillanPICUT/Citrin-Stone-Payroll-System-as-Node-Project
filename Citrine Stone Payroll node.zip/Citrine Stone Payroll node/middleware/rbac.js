'use strict';
/*
 * Role-based access control for the four-role model: Admin, HR, Supervisor, Employee.
 * Route-level gate (which modules a role may open). Row-level scoping (own record,
 * assigned department) is applied inside each module.
 */
const ROLES = ['admin', 'hr', 'supervisor', 'employee'];

function normalizeRole(value) {
  const r = String(value || '').trim().toLowerCase();
  if (r === 'administrator') return 'admin';
  return ROLES.includes(r) ? r : 'employee'; // unknown roles get the lowest privilege
}

// Longest matching prefix wins.
const STAFF = ['admin', 'hr', 'supervisor'];
const RULES = [
  ['/events', ['admin', 'hr', 'supervisor', 'employee']], // live-update stream
  ['/my', ['employee']],
  ['/dashboard', STAFF],
  ['/users', ['admin']],
  ['/audit', ['admin']],
  ['/archive', ['admin', 'hr']],
  ['/payroll', ['admin', 'hr']],
  ['/payslips', ['admin', 'hr']],
  ['/departments', STAFF],
  ['/employees', STAFF],
  ['/attendance/scanner', ['admin', 'hr']],
  ['/attendance/scan', ['admin', 'hr']],
  ['/attendance', STAFF],
  ['/leave', STAFF],
  ['/overtime', STAFF],
  ['/loans', STAFF],
  ['/ledger', STAFF]
];
const OPEN = ['/auth', '/login'];

function canAccess(role, path) {
  const r = normalizeRole(role);
  const p = String(path || '/');
  if (p === '/' || OPEN.some(o => p === o || p.startsWith(o + '/'))) return true;
  let best = null;
  for (const rule of RULES) {
    if ((p === rule[0] || p.startsWith(rule[0] + '/')) && (!best || rule[0].length > best[0].length)) best = rule;
  }
  if (!best) return r !== 'employee'; // unlisted paths: staff may pass through (404s), employees may not
  return best[1].includes(r);
}

function homeFor(role) { return normalizeRole(role) === 'employee' ? '/my/payslip' : '/dashboard'; }

function rbac(req, res, next) {
  const s = req.session;
  if (!s || !(s.userId || s.user_id)) return next(); // authentication is handled elsewhere
  if (canAccess(s.role, req.path)) return next();
  if (req.method === 'GET' && !req.xhr && !String(req.headers.accept || '').includes('application/json')) {
    if (normalizeRole(s.role) === 'employee') return res.redirect('/my/payslip');
    return res.status(403).send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Access denied</title></head><body style="font-family:Arial,sans-serif;padding:48px"><h2>Access denied</h2><p>Your role (${String(s.role || 'unknown').replace(/[<>&]/g, '')}) does not have permission to open this page.</p><p><a href="${homeFor(s.role)}">Back to home</a></p></body></html>`);
  }
  return res.status(403).json({ ok: false, message: 'You do not have permission to perform this action.' });
}

module.exports = { rbac, canAccess, normalizeRole, homeFor, ROLES };