function requireAuth(req, res, next) {
    if (
        req.session &&
        (
            req.session.userId ||
            req.session.user_id ||
            req.session.user
        )
    ) {
        return next();
    }

    return res.redirect('/auth/login');
}

module.exports = requireAuth;