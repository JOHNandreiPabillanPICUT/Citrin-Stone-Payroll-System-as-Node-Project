// The loan tables may already exist in the older (PHP) shape. ensureSchema must add the columns the Node code
// uses, carry old values over, and relax legacy NOT NULL columns it never writes. Fake DB: checks logic, not MySQL syntax.
const assert = require('assert');
const loans = require('../lib/loans.js');

const col = (type, { nullable = false, def = null, extra = '' } = {}) => ({ t: type.split('(')[0], ct: type, nullable, def, extra });
const T = {
  loan_request: {
    loan_id: col('int(11)', { extra: 'auto_increment' }), employee_id: col('int(11)'), loan_type: col("enum('Loan','Cash Advance')"),
    amount_requested: col('decimal(12,2)'), installments_requested: col('tinyint(4)', { def: '1' }), purpose: col('varchar(500)', { nullable: true, def: 'NULL' }),
    status: col("enum('Pending','Approved')", { def: 'Pending' }), requested_by: col('int(11)', { nullable: true }), requested_at: col('datetime'),
    installments: col('tinyint(4)', { nullable: true }), decided_by: col('int(11)', { nullable: true }), decided_at: col('datetime', { nullable: true }),
    rejection_reason: col('varchar(500)', { nullable: true }), released_by: col('int(11)', { nullable: true }), released_at: col('datetime', { nullable: true }),
  },
  loan_schedule: {
    schedule_id: col('int(11)', { extra: 'auto_increment' }), loan_id: col('int(11)'), installment_no: col('tinyint(4)'), due_date: col('date'),
    amount_due: col('decimal(12,2)'), amount_paid: col('decimal(12,2)', { def: '0.00' }), status: col("enum('Pending','Paid')", { def: 'Pending' }), paid_run_id: col('int(11)', { nullable: true }),
  },
  loan_repayment: {
    repayment_id: col('int(11)', { extra: 'auto_increment' }), loan_id: col('int(11)'), schedule_id: col('int(11)'), employee_id: col('int(11)'),
    payroll_run_id: col('int(11)', { nullable: true }), amount: col('decimal(12,2)'), balance_after: col('decimal(12,2)'), paid_at: col('datetime'), recorded_by: col('int(11)', { nullable: true }),
  },
  employee: { employee_id: col('int'), employment_status: col('varchar(20)', { def: 'Regular' }) },
  department: { department_id: col('int'), hr_user_id: col('int', { nullable: true }), supervisor_user_id: col('int', { nullable: true }) },
};
const log = [];
const db = {
  async query(sql, p = []) {
    const s = sql.replace(/\s+/g, ' ').trim(); log.push(s);
    if (/^CREATE TABLE IF NOT EXISTS/.test(s)) return [[]];
    if (/FROM INFORMATION_SCHEMA.TABLES/.test(s)) return [[]];
    if (/IS_NULLABLE = 'NO'/.test(s)) {
      return [Object.entries(T[p[0]]).filter(([, c]) => !c.nullable && c.def === null && !/auto_increment/.test(c.extra)).map(([n, c]) => ({ n, t: c.t, ct: c.ct }))];
    }
    if (/FROM INFORMATION_SCHEMA.COLUMNS/.test(s)) return [Object.keys(T[p[0]]).map((n) => ({ n }))];
    let m;
    if ((m = /^ALTER TABLE `(\w+)` ADD COLUMN `(\w+)` (.*)$/.exec(s))) { T[m[1]][m[2]] = col('x', { nullable: !/NOT NULL/.test(m[3]), def: /DEFAULT/.test(m[3]) ? 'd' : null }); return [{}]; }
    if ((m = /^ALTER TABLE `(\w+)` MODIFY COLUMN `(\w+)` (\S+) (.*)$/.exec(s))) { const c = T[m[1]][m[2]]; c.nullable = /^NULL/.test(m[4]); c.def = /DEFAULT/.test(m[4]) && !/DEFAULT NULL/.test(m[4]) ? 'd' : null; return [{}]; }
    return [{ affectedRows: 0 }];
  },
};

(async () => {
  await loans.ensureSchema(db);
  const has = (t, c) => assert.ok(T[t][c], `${t}.${c} should exist`);
  for (const c of ['category', 'limit_amount', 'amount', 'preferred_installments', 'purpose', 'filed_by', 'reviewed_by', 'reviewed_at', 'review_remarks', 'created_at', 'updated_at']) has('loan_request', c);
  has('loan_schedule', 'employee_id'); has('loan_schedule', 'paid_at');
  const mustInsert = (t, written) => { for (const [n, c] of Object.entries(T[t])) if (!written.includes(n) && !c.nullable && c.def === null && !/auto_increment/.test(c.extra)) assert.fail(`${t}.${n} is NOT NULL without default: an INSERT would fail`); };
  mustInsert('loan_request', ['employee_id', 'loan_type', 'amount', 'status']);
  mustInsert('loan_schedule', ['loan_id', 'employee_id', 'installment_no', 'due_date', 'amount_due', 'status']);
  mustInsert('loan_repayment', ['loan_id', 'schedule_id', 'employee_id', 'amount']);
  const sql = log.join('\n');
  assert.ok(/UPDATE `loan_request` SET `created_at` = `requested_at`/.test(sql), 'created_at should be carried over from requested_at');
  assert.ok(/UPDATE `loan_request` SET `amount` = `amount_requested`/.test(sql), 'amount should be carried over from amount_requested');
  assert.ok(/UPDATE loan_schedule s JOIN loan_request l/.test(sql), 'schedule.employee_id should be backfilled');
  console.log('loans legacy schema test passed');
})().catch((e) => { console.error(e); process.exit(1); });
