'use strict';
const assert = require('assert');
const P = require('../lib/loanPolicy');
const { PRESET_DEPARTMENTS, isPreset } = require('../lib/departmentPresets');

/* ---- category tiers ---- */
assert.strictEqual(P.categoryFor('Probationary', 'employee').label, 'Non-regular employee (probationary)');
assert.strictEqual(P.categoryFor('Probationary', 'hr').key, 'non_regular');          // HR tier is for REGULAR HR only
assert.strictEqual(P.categoryFor('Probationary', 'supervisor').key, 'non_regular');
assert.strictEqual(P.categoryFor('Regular', 'employee').key, 'regular');
assert.strictEqual(P.categoryFor('Regular', null).key, 'regular');                    // no login account
assert.strictEqual(P.categoryFor('Regular', 'hr').key, 'hr');
assert.strictEqual(P.categoryFor('Regular', 'supervisor').key, 'supervisor');
assert.strictEqual(P.categoryFor(undefined, 'employee').key, 'regular');              // existing rows default to Regular

/* ---- the limit table exactly as proposed ---- */
const lim = (s, r, t) => P.limitFor(P.categoryFor(s, r), t);
assert.strictEqual(lim('Probationary', 'employee', 'Cash Advance'), 1500);
assert.strictEqual(lim('Probationary', 'employee', 'Loan'), 0);
assert.strictEqual(lim('Regular', 'employee', 'Cash Advance'), 3000);
assert.strictEqual(lim('Regular', 'employee', 'Loan'), 5000);
assert.strictEqual(lim('Regular', 'hr', 'Cash Advance'), 5000);
assert.strictEqual(lim('Regular', 'hr', 'Loan'), 10000);
assert.strictEqual(lim('Regular', 'supervisor', 'Cash Advance'), 5000);
assert.strictEqual(lim('Regular', 'supervisor', 'Loan'), 10000);

/* ---- request checks ---- */
const reg = P.categoryFor('Regular', 'employee'); const prob = P.categoryFor('Probationary', 'employee');
assert.ok(P.checkRequest({ category: reg, type: 'Cash Advance', amount: '3,000', installments: 6, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 3000.01, installments: 1, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 1000, installments: 7, used: 0 }).ok);   // CA max 6
assert.ok(P.checkRequest({ category: reg, type: 'Loan', amount: 5000, installments: 24, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Loan', amount: 5000, installments: 25, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: prob, type: 'Loan', amount: 100, installments: 1, used: 0 }).ok);          // not eligible
assert.match(P.checkRequest({ category: prob, type: 'Loan', amount: 100, installments: 1, used: 0 }).errors[0], /not eligible/);
assert.ok(P.checkRequest({ category: prob, type: 'Cash Advance', amount: 1500, installments: 1, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: prob, type: 'Cash Advance', amount: 1500.5, installments: 1, used: 0 }).ok);
// the limit counts what is already committed, so small requests cannot be stacked past it
assert.ok(P.checkRequest({ category: reg, type: 'Cash Advance', amount: 1000, installments: 1, used: 2000 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 1000.01, installments: 1, used: 2000 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 1, installments: 1, used: 3000 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 0, installments: 1, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 'abc', installments: 1, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: -5, installments: 1, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Cash Advance', amount: 100, installments: 1.5, used: 0 }).ok);
assert.ok(!P.checkRequest({ category: reg, type: 'Gift', amount: 100, installments: 1, used: 0 }).ok);
// loan and cash advance are counted separately
assert.ok(P.checkRequest({ category: reg, type: 'Loan', amount: 5000, installments: 12, used: 0 }).ok);

/* ---- schedule maths ---- */
assert.deepStrictEqual(P.splitInstallments(1000, 3), [333.34, 333.33, 333.33]);
assert.strictEqual(P.round2(P.splitInstallments(5000, 24).reduce((a, b) => a + b, 0)), 5000);
assert.deepStrictEqual(P.splitInstallments(3000, 1), [3000]);
// first cutoff = the 15th: released on/before the 15th starts this month, after the 15th starts next month
assert.deepStrictEqual(P.dueDates('2026-11-02', 3), ['2026-11-15', '2026-12-15', '2027-01-15']);
assert.deepStrictEqual(P.dueDates('2026-11-15', 1), ['2026-11-15']);
assert.deepStrictEqual(P.dueDates('2026-11-16', 2), ['2026-12-15', '2027-01-15']);
assert.deepStrictEqual(P.dueDates('2026-12-20', 2), ['2027-01-15', '2027-02-15']);   // year rollover
assert.strictEqual(P.dueDates('2026-01-01', 24).pop(), '2027-12-15');
assert.deepStrictEqual(P.dueDates('2026-11-02', 2, 20), ['2026-11-20', '2026-12-20']);

/* ---- preset departments ---- */
assert.strictEqual(PRESET_DEPARTMENTS.length, 8);
assert.ok(isPreset('  corn  mill '));
assert.ok(isPreset('Finished Goods Department (FG)'));
assert.ok(!isPreset('Human Resources'));

console.log('loanPolicy tests passed');
