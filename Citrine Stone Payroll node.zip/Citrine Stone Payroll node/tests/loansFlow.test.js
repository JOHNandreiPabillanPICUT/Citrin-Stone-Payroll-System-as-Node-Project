// Control-flow test of lib/loans.js (limits, approval rules, schedule, payroll hooks) against a tiny in-memory fake DB.
// It does not check MySQL syntax; run the app against your database for that.
const assert = require('assert');
const loans = require('../lib/loans.js');
const state = { loans: [], sched: [], repay: [], nextLoan: 1, nextSched: 1, log: [] };
const EMP = { employee_id: 3, employee_code: 'LIM-FG-0001', first_name: 'John', last_name: 'Andre', department_id: 2, employee_status: 'Active', employment_status: 'Regular', department_name: 'FG', role_name: 'employee' };
function q(sql, p = []) {
  const s = sql.replace(/\s+/g, ' ').trim(); state.log.push(s.slice(0, 60));
  if (/^SELECT employee_id FROM employee .* FOR UPDATE/.test(s)) return [[{ employee_id: 3 }]];
  if (/FROM employee e LEFT JOIN department d/.test(s)) return [[EMP]];
  if (/^SELECT l.loan_type, SUM/.test(s)) {
    const out = {};
    for (const l of state.loans.filter(l => l.employee_id === p[0] && ['Pending', 'Approved', 'Released'].includes(l.status))) {
      const v = l.status === 'Released' ? state.sched.filter(x => x.loan_id === l.loan_id && x.status === 'Pending').reduce((a, x) => a + x.amount_due, 0) : l.amount;
      out[l.loan_type] = (out[l.loan_type] || 0) + v;
    }
    return [Object.entries(out).map(([loan_type, committed]) => ({ loan_type, committed }))];
  }
  if (/^INSERT INTO loan_request/.test(s)) { const l = { loan_id: state.nextLoan++, employee_id: p[0], loan_type: p[1], category: p[2], limit_amount: p[3], amount: +p[4], preferred_installments: p[5], purpose: p[6], status: 'Pending', filed_by: p[7], department_id: 2 }; state.loans.push(l); return [{ insertId: l.loan_id }]; }
  if (/^SELECT l.\*, e.department_id FROM loan_request l .* FOR UPDATE/.test(s)) { const l = state.loans.find(l => l.loan_id === p[0]); return [l ? [l] : []]; }
  if (/^SELECT 1 FROM department WHERE department_id = \? AND hr_user_id/.test(s)) return [p[1] === 9 ? [{ 1: 1 }] : []];
  if (/^UPDATE loan_request SET status='Rejected'/.test(s)) { Object.assign(state.loans.find(l => l.loan_id === p[2]), { status: 'Rejected', reviewed_by: p[0] }); return [{ affectedRows: 1 }]; }
  if (/^UPDATE loan_request SET status='Approved'/.test(s)) { Object.assign(state.loans.find(l => l.loan_id === p[3]), { status: 'Approved', installments: p[0], reviewed_by: p[1] }); return [{ affectedRows: 1 }]; }
  if (/^SELECT pay_cutoff_day/.test(s)) return [[{ pay_cutoff_day: 15 }]];
  if (/^INSERT INTO loan_schedule/.test(s)) { state.sched.push({ schedule_id: state.nextSched++, loan_id: p[0], employee_id: p[1], installment_no: p[2], due_date: p[3], amount_due: +p[4], status: 'Pending' }); return [{}]; }
  if (/^UPDATE loan_request SET status='Released'/.test(s)) { Object.assign(state.loans.find(l => l.loan_id === p[2]), { status: 'Released', installments: p[0] }); return [{ affectedRows: 1 }]; }
  if (/FROM loan_schedule s JOIN loan_request l/.test(s)) return [state.sched.filter(x => x.employee_id === p[0] && x.status === 'Pending' && state.loans.find(l => l.loan_id === x.loan_id).status === 'Released' && x.due_date <= p[1]).map(x => ({ ...x, loan_type: state.loans.find(l => l.loan_id === x.loan_id).loan_type }))];
  if (/^UPDATE loan_schedule SET status='Paid'/.test(s)) { const x = state.sched.find(x => x.schedule_id === p[0] && x.status === 'Pending'); if (x) x.status = 'Paid'; return [{ affectedRows: x ? 1 : 0 }]; }
  if (/^SELECT loan_id, employee_id, amount_due FROM loan_schedule/.test(s)) return [[state.sched.find(x => x.schedule_id === p[0])]];
  if (/^INSERT INTO loan_repayment/.test(s)) { state.repay.push({ loan_id: p[0], schedule_id: p[1], amount: +p[4], run: p[3] }); return [{}]; }
  if (/^SELECT COUNT\(\*\) AS n FROM loan_schedule WHERE loan_id/.test(s)) return [[{ n: state.sched.filter(x => x.loan_id === p[0] && x.status === 'Pending').length }]];
  if (/^UPDATE loan_request SET status='Completed'/.test(s)) { state.loans.find(l => l.loan_id === p[0]).status = 'Completed'; return [{}]; }
  throw new Error('UNHANDLED SQL: ' + s);
}
const conn = { query: async (s, p) => q(s, p), beginTransaction: async () => {}, commit: async () => {}, rollback: async () => {}, release: () => {} };
const db = { query: async (s, p) => q(s, p), getConnection: async () => conn };
(async () => {
  let r = await loans.createRequest(db, { employeeId: 3, type: 'Cash Advance', amount: '3,000', installments: 3, purpose: 'x', filedBy: 5 });
  assert.ok(r.ok, JSON.stringify(r)); const id = r.loanId;
  r = await loans.createRequest(db, { employeeId: 3, type: 'Cash Advance', amount: '1', installments: 1, filedBy: 5 });
  assert.ok(!r.ok && /available|limit/.test(r.errors.join()), 'limit must count the pending 3,000: ' + JSON.stringify(r.errors));
  r = await loans.createRequest(db, { employeeId: 3, type: 'Loan', amount: 5001, installments: 12, filedBy: 5 });
  assert.ok(!r.ok);
  r = await loans.createRequest(db, { employeeId: 3, type: 'Loan', amount: 5000, installments: 12, filedBy: 5 });
  assert.ok(r.ok, 'loan counted separately from cash advance');
  const hr9 = { role: 'hr', uid: 9, empId: 40 }, admin = { role: 'admin', uid: 1, empId: 0 };
  // can't decide own / filed-by-you / not-your-department / supervisor
  assert.ok(!(await loans.decide(db, { role: 'admin', uid: 5, empId: 0 }, id, { action: 'approve' })).ok, 'filer cannot decide');
  assert.ok(!(await loans.decide(db, { role: 'admin', uid: 1, empId: 3 }, id, { action: 'approve' })).ok, 'cannot decide own');
  assert.ok(!(await loans.decide(db, { role: 'hr', uid: 8, empId: 41 }, id, { action: 'approve' })).ok, 'other dept HR');
  assert.ok(!(await loans.decide(db, { role: 'supervisor', uid: 9, empId: 41 }, id, { action: 'approve' })).ok, 'supervisor cannot decide');
  r = await loans.decide(db, hr9, id, { action: 'approve', installments: '7' }); assert.ok(!r.ok, 'CA max 6 installments');
  r = await loans.decide(db, hr9, id, { action: 'approve', installments: '3', remarks: 'ok' }); assert.ok(r.ok, JSON.stringify(r));
  assert.ok(!(await loans.decide(db, hr9, id, { action: 'reject' })).ok, 'already decided');
  assert.ok(!(await loans.release(db, { role: 'hr', uid: 8, empId: 41 }, id)).ok);
  r = await loans.release(db, admin, id); assert.ok(r.ok, JSON.stringify(r));
  assert.deepStrictEqual(state.sched.map(x => x.amount_due), [1000, 1000, 1000]);
  assert.ok(!(await loans.release(db, admin, id)).ok, 'cannot release twice');
  assert.strictEqual((await loans.committedByType(db, 3))['Cash Advance'], 3000, 'released unpaid still counts');
  const due1 = await loans.dueInstallments(db, 3, '2999-01-01'); assert.strictEqual(due1.length, 3);
  const none = await loans.dueInstallments(db, 3, '2000-01-01'); assert.strictEqual(none.length, 0);
  assert.ok(await loans.recordRepayment(db, due1[0].schedule_id, 11, 1));
  assert.ok(!(await loans.recordRepayment(db, due1[0].schedule_id, 11, 1)), 'never charged twice');
  assert.strictEqual((await loans.committedByType(db, 3))['Cash Advance'], 2000);
  await loans.recordRepayment(db, due1[1].schedule_id, 12, 1); await loans.recordRepayment(db, due1[2].schedule_id, 13, 1);
  assert.strictEqual(state.loans.find(l => l.loan_id === id).status, 'Completed');
  assert.strictEqual((await loans.committedByType(db, 3))['Cash Advance'], 0);
  console.log('flow test passed; repayments:', state.repay.length);
})().catch(e => { console.error("FLOW FAILED:", e.stack); process.exit(1); });
