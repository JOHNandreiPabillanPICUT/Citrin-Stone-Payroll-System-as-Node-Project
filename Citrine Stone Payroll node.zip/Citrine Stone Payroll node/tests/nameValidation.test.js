'use strict';
const assert = require('assert');
const { validatePersonName } = require('../lib/nameValidation');

const bad = (first, last, why) => {
  const r = validatePersonName(first, last);
  assert.ok(Object.keys(r.errors).length > 0, `should REJECT "${first}" "${last}"${why ? ' (' + why + ')' : ''}`);
};
const good = (first, last) => {
  const r = validatePersonName(first, last);
  assert.deepStrictEqual(r.errors, {}, `should ACCEPT "${first}" "${last}" but got ${JSON.stringify(r.errors)}`);
};

/* ---- the specific person ---------------------------------------------------- */
bad('Mark', 'Salas', 'blocked person');
bad('mark', 'SALAS', 'case');
bad('  Mark  ', ' Salas ', 'spaces');
bad('Mark Anthony', 'Salas', 'with middle name');
bad('Salas', 'Mark', 'swapped fields');
bad('Mar\u043a', 'Salas', 'Cyrillic look-alike letter');
bad('MarkSalas', 'X', 'run together');
good('Marc', 'Salas');
good('Mark', 'Salazar');
good('Mark', 'Salcedo');

/* ---- ordinary words ("the, happy, dog, tree") --------------------------------- */
bad('The', 'Santos');
bad('Happy', 'Reyes');
bad('Dog', 'Cruz');
bad('Juan', 'Tree');
bad('Dogs', 'Garcia', 'plural');
bad('Banana', 'Lim');
bad('Pizza', 'Tan');
bad('Aso', 'Cruz', 'Tagalog for dog');
bad('Masaya', 'Reyes', 'Tagalog for happy');
bad('Hello', 'World');

/* ---- fictional / fantasy / anime / cartoon / placeholder --------------------- */
bad('Naruto', 'Uzumaki');
bad('Son', 'Goku');
bad('Luffy', 'Santos');
bad('Harry', 'Potter');
bad('Hermione', 'Granger');
bad('Luke', 'Skywalker');
bad('Darth', 'Vader');
bad('Tony', 'Stark');
bad('Eren', 'Yeager');
bad('Light', 'Yagami');
bad('Mickey', 'Mouse');
bad('Santa', 'Claus');
bad('Juan', 'Dela Cruz', 'classic placeholder');
bad('John', 'Doe');
bad('Elon', 'Musk', 'celebrity');
bad('Pikachu', 'Santos');
bad('Dragon', 'Slayer');
bad('Test', 'User');
bad('Admin', 'Admin');
bad('Asdf', 'Qwerty');
bad('Hahaha', 'Lol');
bad('Unknown', 'Person');
bad('HarryPotter', 'X', 'run together');

/* ---- offensive language, slurs, Tagalog / Cebuano ---------------------------- */
bad('Fuck', 'Santos');
bad('Fuuuck', 'Santos', 'stretched');
bad('F u c k', 'Santos', 'spaced out');
bad('Fu', 'Ck', 'split across fields');
bad('Juan', 'Bitch');
bad('Shit', 'Head');
bad('Ass', 'Hole');
bad('A s s', 'Cruz');
bad('Putangina', 'Mo');
bad('Gago', 'Reyes');
bad('Tanga', 'Cruz');
bad('Bobo', 'Santos');
bad('Yawa', 'Cruz', 'Cebuano');
bad('Pisti', 'Reyes', 'Cebuano');
bad('Nigga', 'Santos');
bad('Chink', 'Santos');
bad('Satan', 'Lim');

/* ---- gibberish / formatting -------------------------------------------------- */
bad('Aaaaron', 'Cruz', '3 repeated letters');
bad('Bcdfgh', 'Cruz', 'no vowels');
bad('Ababab', 'Cruz', 'two-letter loop');
bad('Juan', 'Juan', 'same in both boxes');
bad('J', 'Cruz', 'single loose letter');
bad('Juan--Carlos', 'Cruz', 'double hyphen');
bad('Juan-', 'Cruz', 'trailing hyphen');
bad('Maria Ana Luisa Sofia Elena', 'Cruz', 'too many words');
bad('De La', 'De Los', 'particles only');

/* ---- REAL names that must still pass (false-positive guard) ------------------ */
good('Maria Cristina', 'Santos');
good('Ma. Luisa', 'De La Cruz');
good('Jose', 'Rizal');
good('Juan', 'Cruz');
good('Kevin', 'Ng');
good('Bryan', 'Co');
good('Jasmine', 'Sy');
good('Christian', 'Tan');
good('Angelica', 'Lim Ket Kai');
good('Ana Marie', "O'Brien");
good('Jean-Luc', 'Dubois');
good('José', 'Peña');
good('Cassandra', 'Hancock');
good('Christian', 'Dickson');
good('Hellen', 'Peacock');
good('Matthew', 'Cumming');
good('Assunta', 'Bassett');
good('Scott', 'Titus');
good('Grace', 'Hope');
good('Joy', 'Faith');
good('Princess', 'Reyes');
good('Angel', 'Baker');
good('Honey', 'Cook');
good('Sunshine', 'Lovely');
good('Rowena', 'Hunter');
good('Levi', 'Cruz');
good('Harry', 'Santos');
good('Mary', 'Poppins-Reyes');
good('Chin', 'Kai');
good('Wertheim', 'Wertz');
good('Anna', 'Nana');
good('Lolo', 'Lim');
good('Marilou', 'Yap');
good('Emmanuel', 'Dela Peña');
good('Rodel', 'Abellanosa');
good('Cyrus', 'Lynn');

/* ---- violations: only policy breaks are reported for the audit log ----------- */
assert.deepStrictEqual(validatePersonName('Juan--X', 'Cruz').violations, [], 'format problems are not audit-worthy');
assert.ok(validatePersonName('Mark', 'Salas').violations.includes('blocked'));
assert.ok(validatePersonName('Fuck', 'You').violations.includes('offensive'));

/* messages never echo the offending word */
const msg = Object.values(validatePersonName('Fuck', 'Santos').errors).join(' ');
assert.ok(!/fuck/i.test(msg), 'error message must not repeat the blocked word');

console.log('nameValidation tests passed');
