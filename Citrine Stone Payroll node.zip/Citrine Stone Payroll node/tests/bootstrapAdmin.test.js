'use strict';
const assert = require('assert');
const bcrypt = require('bcryptjs');
const B = require('../lib/bootstrapAdmin');

/* tiny in-memory stand-in for the MySQL pool */
function fakeDb({ users = [], roles = [], hasTables = true } = {}) {
  const st = { users: [...users], roles: [...roles], tables: hasTables ? new Set(['users', 'roles']) : new Set(), insertedUser: null };
  const ucols = ['user_id', 'username', 'password_hash', 'role_id', 'status', 'must_change_password', 'employee_id'];
  return { st, async query(sql, p = []) {
    const s = sql.replace(/\s+/g, ' ').trim();
    if (/FROM INFORMATION_SCHEMA.TABLES/.test(s)) return [st.tables.has(p[0]) ? [{ 1: 1 }] : []];
    if (/^CREATE TABLE (roles|users)/.test(s)) { st.tables.add(s.match(/^CREATE TABLE (\w+)/)[1]); return [{}]; }
    if (/FROM INFORMATION_SCHEMA.COLUMNS/.test(s)) return [ucols.map((n) => ({ n }))];
    if (/^SELECT COUNT\(\*\) AS n FROM users/.test(s)) return [[{ n: st.users.length }]];
    if (/^SELECT COUNT\(\*\) AS n FROM roles/.test(s)) return [[{ n: st.roles.length }]];
    if (/FROM roles WHERE LOWER\(role_name\)/.test(s)) return [st.roles.filter((r) => /^admin(istrator)?$/i.test(r.role_name))];
    if (/^INSERT INTO roles \(role_id, role_name\)/.test(s)) { st.roles.push({ role_id: 1, role_name: 'Admin' }, { role_id: 2, role_name: 'HR' }, { role_id: 3, role_name: 'Employee' }, { role_id: 4, role_name: 'Supervisor' }); return [{}]; }
    if (/^INSERT INTO roles \(role_name\)/.test(s)) { st.roles.push({ role_id: 9, role_name: 'Admin' }); return [{ insertId: 9 }]; }
    if (/^INSERT INTO users/.test(s)) {
      if (st.users.length) return [{ affectedRows: 0 }];
      const f = s.match(/INSERT INTO users \((.*?)\) SELECT/)[1].split(',').map((x) => x.trim().replace(/`/g, ''));
      st.insertedUser = Object.fromEntries(f.map((k, i) => [k, p[i]])); st.users.push(st.insertedUser); return [{ affectedRows: 1 }];
    }
    if (/^SELECT username, must_change_password FROM users/.test(s)) return [st.users.slice(0, 2)];
    throw new Error('UNHANDLED SQL: ' + s);
  } };
}

(async () => {
  // empty system -> one admin, forced password change, real bcrypt hash of the default password
  let db = fakeDb();
  let r = await B.ensureAdminUser(db);
  assert.ok(r.created && r.username === 'admin');
  assert.strictEqual(db.st.users.length, 1);
  assert.strictEqual(db.st.insertedUser.must_change_password, 1);
  assert.strictEqual(db.st.insertedUser.role_id, 1);
  assert.ok(await bcrypt.compare(B.DEFAULT_PASSWORD, db.st.insertedUser.password_hash));
  assert.ok(await B.pendingFirstRun(db), 'login page shows the first-run hint');
  // running again changes nothing
  r = await B.ensureAdminUser(db); assert.ok(!r.created); assert.strictEqual(db.st.users.length, 1);
  // once the admin has changed the password the hint disappears
  db.st.users[0].must_change_password = 0; assert.strictEqual(await B.pendingFirstRun(db), null);

  // existing users -> never touched
  db = fakeDb({ users: [{ username: 'someone', must_change_password: 0 }], roles: [{ role_id: 1, role_name: 'Admin' }] });
  r = await B.ensureAdminUser(db); assert.ok(!r.created); assert.strictEqual(db.st.users.length, 1);
  assert.strictEqual(await B.pendingFirstRun(db), null);

  // roles table already has an Administrator role under another id -> reused
  db = fakeDb({ roles: [{ role_id: 7, role_name: 'Administrator' }] });
  await B.ensureAdminUser(db); assert.strictEqual(db.st.insertedUser.role_id, 7);

  // roles exist but no Admin -> Admin role is added
  db = fakeDb({ roles: [{ role_id: 3, role_name: 'Employee' }] });
  await B.ensureAdminUser(db); assert.strictEqual(db.st.insertedUser.role_id, 9);

  // missing tables are created
  db = fakeDb({ hasTables: false });
  r = await B.ensureAdminUser(db); assert.ok(r.created); assert.ok(db.st.tables.has('users') && db.st.tables.has('roles'));
  console.log('bootstrap admin tests passed');
})().catch((e) => { console.error('BOOTSTRAP FAILED:', e.stack); process.exit(1); });
