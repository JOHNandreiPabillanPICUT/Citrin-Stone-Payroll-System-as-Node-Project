const assert = require('assert');
const { deriveStatus } = require('../lib/attendanceStatus');
const past = { isToday: false, dayClosed: true, nowMin: 0 };
const d = (timeIn, timeOut, extra = {}) => deriveStatus({ timeIn, timeOut, scans: [], ...past, ...extra });

// Present: in on/before 07:00, out at/after 16:00
let r = d('06:58:00', '16:02:00');
assert.deepStrictEqual([r.status, r.lateMinutes, r.undertimeMinutes, r.regularHours], ['Present', 0, 0, 8]);
// Late: after 07:00
r = d('07:32:21', '17:03:57');
assert.deepStrictEqual([r.status, r.lateMinutes, r.undertimeMinutes], ['Late', 32, 0]);
// Undertime: out before 16:00 (lunch hour is not counted as missed time)
r = d('07:00:00', '15:00:00');
assert.deepStrictEqual([r.status, r.lateMinutes, r.undertimeMinutes], ['Undertime', 0, 60]);
r = d('07:00:00', '11:30:00');
assert.strictEqual(r.undertimeMinutes, 180 + 30 /* 11:30-12:00 + 13:00-16:00 */ );
// Late wins over Undertime but both minutes are kept for payroll
r = d('08:30:00', '12:00:00');
assert.deepStrictEqual([r.status, r.lateMinutes, r.undertimeMinutes], ['Late', 90, 180]);
// manual row, finished day, never timed out -> Abandoned
r = d('03:26:02', null);
assert.strictEqual(r.status, 'Abandoned');
// no time in on a finished day -> Absent; today before closing -> undecided (null)
assert.strictEqual(d(null, null).status, 'Absent');
assert.strictEqual(d(null, null, { isToday: true, dayClosed: false, nowMin: 600 }).status, null);
// today, still working, no time-out yet -> not abandoned
assert.strictEqual(d('07:00:00', null, { isToday: true, dayClosed: false, nowMin: 600 }).status, 'Present');
// scan log: left for lunch and never came back -> Abandoned
const sc = (...t) => t.map(([type, h, m = 0]) => ({ scan_type: type, scan_time: `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:00` }));
r = deriveStatus({ timeIn: '07:00:00', timeOut: null, scans: sc(['IN', 7], ['LUNCH_OUT', 11, 55]), isToday: true, dayClosed: false, nowMin: 13 * 60 + 10 });
assert.strictEqual(r.status, 'Abandoned');
// scan log: full clean day -> Present
r = deriveStatus({ timeIn: '06:58:00', timeOut: '16:01:00', scans: sc(['IN', 6, 58], ['AM_BREAK', 9, 5], ['LUNCH_OUT', 11, 55], ['LUNCH_IN', 12, 55], ['PM_BREAK', 15, 5], ['OUT', 16, 1]), ...past });
assert.strictEqual(r.status, 'Present');
// full DATETIME values (QR scans) are understood too
assert.strictEqual(d('2026-11-03 07:10:00', '2026-11-03 16:00:00').status, 'Late');
console.log('attendanceStatus tests passed');
