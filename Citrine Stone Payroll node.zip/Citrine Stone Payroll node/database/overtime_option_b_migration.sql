-- Citrine Stone Payroll Node: Option B Department Overtime Workflow
-- Back up gaisano_payroll_milestone before running this migration.
-- Run this in phpMyAdmin > select gaisano_payroll_milestone > SQL.

CREATE TABLE IF NOT EXISTS overtime_department_request (
  request_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  department_id INT NOT NULL,
  work_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  total_hours DECIMAL(5,2) NOT NULL,
  reason TEXT NOT NULL,
  slots_needed INT NOT NULL,
  status ENUM('pending_assignment','assigned','confirmed','rejected') NOT NULL DEFAULT 'pending_assignment',
  created_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  assigned_by INT NULL,
  assigned_at DATETIME NULL,
  confirmed_by INT NULL,
  confirmed_at DATETIME NULL,
  supervisor_remarks TEXT NULL,
  rejected_by INT NULL,
  rejected_at DATETIME NULL,
  rejection_reason TEXT NULL,
  payroll_status ENUM('Not Processed','Processed') NOT NULL DEFAULT 'Not Processed',
  payroll_run_id INT NULL,
  INDEX idx_ot_dept_req_department (department_id),
  INDEX idx_ot_dept_req_status (status),
  INDEX idx_ot_dept_req_date (work_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS overtime_department_assignment (
  assignment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL,
  employee_id INT NOT NULL,
  assigned_by INT NULL,
  assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  seen_at DATETIME NULL,
  UNIQUE KEY uq_ot_assignment_employee (request_id, employee_id),
  INDEX idx_ot_assignment_employee (employee_id),
  INDEX idx_ot_assignment_request (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Note:
-- Existing overtime_request rows remain intact.
-- Confirmed department overtime requests are materialized into overtime_request
-- as Approved / Not Processed rows so the existing payroll selection can pick them up.
