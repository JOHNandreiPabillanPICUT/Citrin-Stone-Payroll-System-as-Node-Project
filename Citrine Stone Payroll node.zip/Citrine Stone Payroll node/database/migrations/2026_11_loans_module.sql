-- Loans & Cash Advances module + preset departments.
-- OPTIONAL: the app runs all of this itself (idempotent, additive only) the first time it starts or the page is opened.
-- Run by hand only if you prefer to prepare the database yourself.

ALTER TABLE employee ADD COLUMN employment_status VARCHAR(20) NOT NULL DEFAULT 'Regular';  -- skip if the column already exists
ALTER TABLE department ADD COLUMN hr_user_id INT NULL;            -- skip if already present
ALTER TABLE department ADD COLUMN supervisor_user_id INT NULL;    -- skip if already present

CREATE TABLE IF NOT EXISTS loan_request (
  loan_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  loan_type ENUM('Cash Advance','Loan') NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT '',
  limit_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  amount DECIMAL(12,2) NOT NULL,
  preferred_installments INT NOT NULL DEFAULT 1,
  installments INT NULL,
  purpose TEXT NULL,
  status ENUM('Pending','Approved','Released','Rejected','Completed') NOT NULL DEFAULT 'Pending',
  filed_by INT NULL,
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  review_remarks TEXT NULL,
  released_by INT NULL,
  released_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_loan_employee (employee_id),
  INDEX idx_loan_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS loan_schedule (
  schedule_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  loan_id INT NOT NULL,
  employee_id INT NOT NULL,
  installment_no INT NOT NULL,
  due_date DATE NOT NULL,
  amount_due DECIMAL(12,2) NOT NULL,
  status ENUM('Pending','Paid') NOT NULL DEFAULT 'Pending',
  paid_at DATETIME NULL,
  UNIQUE KEY uq_loan_installment (loan_id, installment_no),
  INDEX idx_sched_due (employee_id, status, due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS loan_repayment (
  repayment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  loan_id INT NOT NULL,
  schedule_id INT NOT NULL,
  employee_id INT NOT NULL,
  payroll_run_id INT NULL,
  amount DECIMAL(12,2) NOT NULL,
  recorded_by INT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_repay_schedule (schedule_id),
  INDEX idx_repay_run (payroll_run_id, employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Preset departments (each is added only if no department of that name exists)
INSERT INTO department (name)
SELECT v.name FROM (
  SELECT 'Finished Goods Department (FG)' AS name UNION ALL SELECT 'Packaging Materials Department'
  UNION ALL SELECT 'Coconut Processing Department' UNION ALL SELECT 'Corn Brand Department'
  UNION ALL SELECT 'Filling Department' UNION ALL SELECT 'Corn Mill'
  UNION ALL SELECT 'General Store Department' UNION ALL SELECT 'Maintenance Department'
) v WHERE NOT EXISTS (SELECT 1 FROM department d WHERE LOWER(d.name) = LOWER(v.name));
