-- Citrine Stone Leave Module enhancement
-- Review your existing leave_request columns before running. Add only columns
-- that do not already exist in your database (MySQL versions differ in support
-- for ADD COLUMN IF NOT EXISTS).
ALTER TABLE leave_request
  ADD COLUMN date_submitted DATETIME NULL,
  ADD COLUMN pay_type ENUM('Paid','Unpaid','Pending Policy Review') NOT NULL DEFAULT 'Pending Policy Review',
  ADD COLUMN reviewed_by INT NULL,
  ADD COLUMN reviewed_at DATETIME NULL,
  ADD COLUMN rejection_reason VARCHAR(1000) NULL;

-- Recommended integrity index. Check for existing duplicate indexes first.
CREATE INDEX idx_leave_employee_dates_status
  ON leave_request (employee_id, status, start_date, end_date);
