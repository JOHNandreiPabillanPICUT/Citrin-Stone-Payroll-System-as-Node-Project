-- OPTIONAL: the app does all of this automatically the next time it starts (lib/employeeCode.js).
-- Run it by hand in phpMyAdmin only if you want the column right now. Skip any line that says "Duplicate column".
ALTER TABLE employee ADD COLUMN employee_code VARCHAR(40) NULL;
ALTER TABLE users    ADD COLUMN employee_code VARCHAR(40) NULL AFTER employee_id;
ALTER TABLE users    ADD UNIQUE KEY uq_users_employee_code (employee_code);

-- copy existing employee codes onto the matching user accounts
UPDATE users u JOIN employee e ON e.employee_id = u.employee_id
   SET u.employee_code = e.employee_code
 WHERE e.employee_code IS NOT NULL AND e.employee_code <> '';
