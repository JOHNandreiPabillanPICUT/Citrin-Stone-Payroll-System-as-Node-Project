-- Supervisor -> HR approval stage for leave and overtime, plus the attendance scan log.
-- The app applies these automatically on first use; run by hand only if you prefer.
-- Skip any ADD COLUMN that already exists in your database.

ALTER TABLE leave_request
  ADD COLUMN supervisor_status ENUM('Pending','Endorsed','Rejected') NOT NULL DEFAULT 'Pending',
  ADD COLUMN supervisor_id INT NULL,
  ADD COLUMN supervisor_at DATETIME NULL,
  ADD COLUMN supervisor_remarks VARCHAR(1000) NULL;
UPDATE leave_request SET supervisor_status='Endorsed' WHERE LOWER(status) <> 'pending';

ALTER TABLE overtime_request
  ADD COLUMN supervisor_status ENUM('Pending','Endorsed','Rejected') NOT NULL DEFAULT 'Pending',
  ADD COLUMN supervisor_id INT NULL,
  ADD COLUMN supervisor_at DATETIME NULL,
  ADD COLUMN supervisor_remarks VARCHAR(1000) NULL;
UPDATE overtime_request SET supervisor_status='Endorsed' WHERE LOWER(status) <> 'pending';

CREATE TABLE IF NOT EXISTS attendance_scan (
  scan_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  work_date DATE NOT NULL,
  scan_type ENUM('IN','AM_BREAK','LUNCH_OUT','LUNCH_IN','PM_BREAK','OUT') NOT NULL,
  scan_time TIME NOT NULL,
  is_late TINYINT(1) NOT NULL DEFAULT 0,
  scanned_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_scan_day_type (employee_id, work_date, scan_type),
  INDEX idx_scan_date (work_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
