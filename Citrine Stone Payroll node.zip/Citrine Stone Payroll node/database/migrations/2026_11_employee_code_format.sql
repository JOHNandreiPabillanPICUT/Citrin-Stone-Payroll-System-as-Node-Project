-- OPTIONAL. Rewrites EXISTING employee codes (e.g. LIM-FG-0001) to the new DEPT-EMP-001 format.
-- New employees already get the new format automatically; you only need this for the older rows.
-- NOTE: printed QR badges encode the old code, so reprint badges after running this.
-- Make a backup first. Department segment = text in "(...)" at the end of the department name,
-- e.g. "Finished Goods Department (FG)" -> FG ; otherwise the old middle segment is kept.
UPDATE employee e
JOIN (
  SELECT employee_id,
         UPPER(SUBSTRING_INDEX(SUBSTRING_INDEX(employee_code, '-', 2), '-', -1)) AS dept,
         ROW_NUMBER() OVER (PARTITION BY UPPER(SUBSTRING_INDEX(SUBSTRING_INDEX(employee_code, '-', 2), '-', -1)) ORDER BY employee_id) AS seq
  FROM employee
  WHERE employee_code REGEXP '^[A-Za-z0-9]+-[A-Za-z0-9]+-[0-9]+$'
) x ON x.employee_id = e.employee_id
SET e.employee_code = CONCAT(x.dept, '-EMP-', LPAD(x.seq, 3, '0'));
