-- Department transfers + six-month regularization.
-- The app applies this automatically on first start; run by hand only if you prefer.
-- Skip any ADD COLUMN that already exists.
ALTER TABLE employee
  ADD COLUMN date_hired DATE NULL,
  ADD COLUMN employment_status VARCHAR(20) NULL,
  ADD COLUMN regularization_date DATE NULL;

-- existing employees: earliest salary effective date is the best available hire date
UPDATE employee e SET e.date_hired = (SELECT MIN(bs.effective_date) FROM basic_salary bs WHERE bs.employee_id = e.employee_id) WHERE e.date_hired IS NULL;

CREATE TABLE IF NOT EXISTS employee_transfer_request (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL, from_department_id INT NOT NULL, to_department_id INT NOT NULL,
  reason TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending Supervisor',
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  supervisor_user_id INT NULL, supervisor_decision VARCHAR(12) NULL, supervisor_remarks TEXT NULL, supervisor_at DATETIME NULL,
  hr_user_id INT NULL, hr_decision VARCHAR(12) NULL, hr_remarks TEXT NULL, hr_at DATETIME NULL,
  attendance_reviewed TINYINT(1) NOT NULL DEFAULT 0, performance_rating TINYINT NULL, performance_notes TEXT NULL,
  attendance_snapshot TEXT NULL, completed_at DATETIME NULL,
  KEY idx_transfer_employee (employee_id), KEY idx_transfer_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
