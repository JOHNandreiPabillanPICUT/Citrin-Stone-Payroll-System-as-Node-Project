const assert = require('assert');
const P = require('./lib/payrollPeriod');
const C = require('./lib/payrollCalc');

// pay date = end + 5, Sunday -> Saturday
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-15'))), '2026-11-20'); // Fri (matches screenshot)
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-30'))), '2026-12-05'); // Sat (matches screenshot)
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-10-31'))), '2026-11-05'); // Thu (PHP comment example)
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-01'))), '2026-11-06');
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-07'))), '2026-11-12');
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-11'))), '2026-11-16'); // Mon
assert.strictEqual(P.weekdayName(P.parseYmd('2026-11-16')), 'Monday');
// a Sunday landing: Nov 10 + 5 = Nov 15 (Sunday) -> Sat Nov 14
assert.strictEqual(P.fmt(P.payDateFor(P.parseYmd('2026-11-10'))), '2026-11-14');

// semi-monthly = ONE 15-day run: start + 14 days, 50% share, pay date end + 5 (never Sunday)
let r = P.validatePeriodRange('Semi-monthly', '2026-11-01', '2026-11-15', { cutoff_day: 15 });
assert(r.ok && r.segments.length === 1 && r.warning === '');
assert.deepStrictEqual(r.segments.map(s => [s.period_start, s.period_end, s.pay_date, s.share]), [['2026-11-01','2026-11-15','2026-11-20',0.5]]);
r = P.validatePeriodRange('Semi-monthly', '2026-11-16', '2026-11-30', { cutoff_day: 15 });
assert(r.ok && r.segments[0].pay_date === '2026-12-05');
assert.strictEqual(P.halfMonthEndYmd('2026-12-05'), '2026-12-19');
assert.strictEqual(P.halfMonthEndYmd('2026-02-20'), '2026-03-06');
assert(!P.validatePeriodRange('Semi-monthly', '2026-11-01', '2026-11-30', {}).ok);   // a whole month is no longer allowed
assert(!P.validatePeriodRange('Semi-monthly', '2026-11-01', '2026-11-10', {}).ok);

// full month + Weekly = 5 payrolls whose shares add to exactly 1
r = P.validatePeriodRange('Weekly', '2026-11-01', '2026-11-30', {});
assert(r.ok && r.segments.length === 5);
assert.strictEqual(P.round(r.segments.reduce((a, s) => a + s.factor, 0), 6), 1);
assert.strictEqual(r.segments[4].period_start + r.segments[4].period_end, '2026-11-292026-11-30');

// single weekly payroll keeps 25% (factor null) and Oct 16-22 (Gaisano's existing runs)
r = P.validatePeriodRange('Weekly', '2026-10-16', '2026-10-22', {});
assert(r.segments.length === 1 && r.segments[0].factor === null && r.segments[0].share === 0.25 && r.warning === '');

// odd single range warns, >31 and end<start blocked
r = P.validatePeriodRange('Weekly', '2026-11-01', '2026-11-03', {});
assert(r.ok && r.warning.includes('not the usual Weekly period'));
assert(!P.validatePeriodRange('Monthly', '2026-11-01', '2026-12-05', {}).ok);
assert(!P.validatePeriodRange('Monthly', '2026-11-10', '2026-11-01', {}).ok);

// monthly: starts on 5th -> expected 4th of next month
r = P.validatePeriodRange('Monthly', '2026-10-05', '2026-11-04', {});
assert(r.ok && r.warning === '' && r.segments.length === 1 && r.segments[0].share === 1);

// semi-monthly = exactly 15 days from the start (end is calculated), ONE payroll per run
for (const [a, b] of [['2026-12-01','2026-12-03'], ['2026-12-01','2026-12-31'], ['2026-12-16','2026-12-31'], ['2026-12-10','2026-12-09'], ['2026-10-10','2026-11-20']]) {
  assert.strictEqual(P.validatePeriodRange('Semi-monthly', a, b, {}).ok, false, a + ' to ' + b + ' must be blocked');
}
for (const [a, b] of [['2026-12-01','2026-12-15'], ['2026-12-16','2026-12-30'], ['2026-12-10','2026-12-24'], ['2026-12-25','2027-01-08'], ['2028-02-15','2028-02-29']]) {
  r = P.validatePeriodRange('Semi-monthly', a, b, {});
  assert(r.ok && r.segments.length === 1 && r.warning === '', a + ' to ' + b + ' must pass');
  assert(r.segments[0].share === 0.5 && r.segments[0].period_start === a && r.segments[0].period_end === b);
}
r = P.validatePeriodRange('Semi-monthly', '2026-10-10', '2026-10-31', {});
assert(r.ok === false && /exactly 15 days/.test(r.error));

// government deductions: the run that ends on the last day of the month is the 2nd payment
let t = C.deductionTiming({ pay_frequency: 'Semi-monthly', period_start: '2026-11-01', period_end: '2026-11-15' });
assert(t.cutoff === 'first' && t.loans && !t.government);
t = C.deductionTiming({ pay_frequency: 'Semi-monthly', period_start: '2026-11-16', period_end: '2026-11-30' });
assert(t.cutoff === 'second' && !t.loans && t.government);

// period containing
const sch = { frequency: 'Semi-monthly', cutoff_day: 15, week_start: 1 };
assert.strictEqual(P.periodContaining(sch, '2026-11-02').period_end, '2026-11-15');
assert.strictEqual(P.periodContaining({ ...sch, frequency: 'Weekly' }, '2026-11-04').period_start, '2026-11-02');

// formatDate fixes the JS Date string bug from the screenshot
assert.strictEqual(P.formatDate(new Date(2026, 9, 16)), 'Oct 16, 2026');
assert.strictEqual(P.formatDate('2026-10-22'), 'Oct 22, 2026');

// deductions
assert.strictEqual(C.sss(15000, 0.5), 375);
assert.strictEqual(C.philhealth(15000, 0.5), 187.5);
assert.strictEqual(C.pagibig(15000, 0.5), 50);
assert.strictEqual(C.dailyRateFor(15000), 575.08);
assert.strictEqual(C.runPayFactor({ pay_factor: null, pay_frequency: 'Weekly' }), 0.25);
assert.strictEqual(C.runPayFactor({ pay_factor: '0.3', pay_frequency: 'Weekly' }), 0.3);

// overtime: approved 2h 17:00-19:00, worked until 18:30 -> 1.5h; no time-out -> 0
assert.strictEqual(C.eligibleOvertimeHours({ work_date: '2026-11-02', hours: 2, start_time: '17:00:00', end_time: '19:00:00', time_in: '08:00:00', time_out: '18:30:00', status: 'Present' }), 1.5);
assert.strictEqual(C.eligibleOvertimeHours({ work_date: '2026-11-02', hours: 2, time_in: '08:00:00', time_out: null, status: 'Present' }), 0);
assert.strictEqual(C.eligibleOvertimeHours({ work_date: '2026-11-02', hours: 2, time_in: '08:00:00', time_out: '18:00:00', status: 'Absent' }), 0);

// staffing message text identical to PHP
assert.strictEqual(C.departmentStaffingMessage({ department_name: 'FG', missing: ['HR / Timekeeper', 'Supervisor'] }),
  'Payroll cannot be processed: the FG department has no assigned HR / Timekeeper and no assigned Supervisor. Assign both positions in Departments, then try again.'); // identical to screenshot
console.log('all period/calc tests passed');

// deduction timing: loans on the first cutoff, government + tax on the second (semi-monthly)
const t1 = C.deductionTiming({ pay_frequency: 'Semi-monthly', period_end: '2026-11-15' });
assert(t1.loans === true && t1.government === false && t1.cutoff === 'first');
const t2 = C.deductionTiming({ pay_frequency: 'Semi-monthly', period_end: '2026-11-30' });
assert(t2.loans === false && t2.government === true && t2.cutoff === 'second');
assert.strictEqual(C.deductionTiming({ pay_frequency: 'Semi-monthly', period_end: '2028-02-29' }).cutoff, 'second');
assert.strictEqual(C.deductionTiming({ pay_frequency: 'Semi-monthly', period_end: '2026-10-20' }).cutoff, 'first');
const t3 = C.deductionTiming({ pay_frequency: 'Monthly', period_end: '2026-11-30' });
assert(t3.loans && t3.government && t3.cutoff === null);
console.log('deduction timing tests passed');

// ids never shown in audit / archive text
const { stripIds } = require('./lib/displayText');
assert.strictEqual(stripIds('Posted (finalized) payroll run #5 (12 employees)'), 'Posted (finalized) payroll run (12 employees)');
assert.strictEqual(stripIds('Created 2 Semi-monthly payroll run(s) #5, #6 (department #3, coverage 2026-12-01 to 2026-12-31)'), 'Created 2 Semi-monthly payroll run(s) (coverage 2026-12-01 to 2026-12-31)');
assert.strictEqual(stripIds('Employee #4'), 'Employee');
assert.strictEqual(stripIds('Overtime request #12'), 'Overtime request');
assert(!/#\d/.test(stripIds('Leave request #7 approved for employee #4')));
console.log('id stripping tests passed');
