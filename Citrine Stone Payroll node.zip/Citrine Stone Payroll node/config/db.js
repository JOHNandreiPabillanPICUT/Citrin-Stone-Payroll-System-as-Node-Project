/*
 * Citrine Stone Payroll Node - MySQL database pool
 * Uses the existing .env variables. Does not create or alter tables.
 */
'use strict';

const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || process.env.MYSQL_HOST || 'localhost',
  port: Number(process.env.DB_PORT || process.env.MYSQL_PORT || 3306),
  user: process.env.DB_USER || process.env.MYSQL_USER || 'root',
  password: process.env.DB_PASSWORD ?? process.env.MYSQL_PASSWORD ?? '',
  database: process.env.DB_NAME || process.env.MYSQL_DATABASE || 'citrin_stone_database',
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT || 10),
  queueLimit: 0,
  charset: 'utf8mb4'
});

/*
 * Compatibility helpers expected by the supplied server.js:
 *   await db.scalar('SELECT 1')
 * Standard mysql2/promise methods (query, execute, getConnection) are also available.
 */
pool.scalar = async function scalar(sql, params = []) {
  const [rows] = await pool.query(sql, params);
  if (!rows || !rows.length) return null;
  const first = rows[0];
  return first[Object.keys(first)[0]];
};

module.exports = pool;
